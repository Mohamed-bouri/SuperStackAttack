import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Stack;
import java.util.Vector;
import javax.bluetooth.DataElement;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.L2CAPConnection;
import javax.bluetooth.L2CAPConnectionNotifier;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;
import javax.microedition.io.Connection;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import javax.wireless.messaging.BinaryMessage;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.TextMessage;

/**
 * Multiplayer and online: BluetoothLink (2-player Bluetooth), BluetoothPoller (polls it), SmsMessenger (SMS), HttpClient (HTTP / high scores).
 */
final class BluetoothLink implements DiscoveryListener, Runnable {
   protected StackAttack a;
   protected Object[] b;
   public DataInputStream[] c;
   public DataOutputStream[] d;
   protected Connection e;
   protected Thread f;
   public String[] g;
   public byte[][] h;
   public String i;
   public int j;
   public String[][] k;
   public boolean[] l;
   public boolean[] m;
   public int n;
   public boolean o;
   protected BluetoothPoller p;
   protected LocalDevice q;
   protected DiscoveryAgent r;
   protected Stack s;
   protected int t;
   protected Vector u;
   protected final UUID v;
   // $FF: synthetic field
   private final StackAttack w;

   public BluetoothLink(StackAttack var1, StackAttack var2) {
      this.w = var1;
      this.a = null;
      this.b = new Object[8];
      this.c = new DataInputStream[8];
      this.d = new DataOutputStream[8];
      this.g = new String[8];
      this.h = new byte[8][3];
      this.i = "";
      this.j = -1;
      this.k = new String[8][2];
      this.l = new boolean[8];
      this.m = new boolean[8];
      this.p = new BluetoothPoller(this.w, this);
      this.s = new Stack();
      this.t = 0;
      this.u = new Vector();
      this.v = new UUID("9a15db017b914ace927b86e5fe64c059", false);
      this.a = var2;
      this.i = "SuperStackAttack";

      for(int var3 = 0; var3 < 8; ++var3) {
         this.m[var3] = false;
         this.l[var3] = false;
      }

      this.n = 99;
      this.A(1);
   }

   public void run() {
      try {
         while(this.e != null) {
            Object var2 = null;
            if (this.e instanceof L2CAPConnectionNotifier) {
               var2 = ((L2CAPConnectionNotifier)this.e).acceptAndOpen();
            }

            if (this.e instanceof StreamConnectionNotifier) {
               var2 = ((StreamConnectionNotifier)this.e).acceptAndOpen();
            }

            if (var2 != null) {
               this.A(var2, false);
            }
         }
      } catch (Exception var3) {
      }

   }

   public void A(int var1) {
      int var3 = this.w.y;

      try {
         this.a.A(13, var3, (Object)null, (String)null);
         switch (var3) {
            case 65796:
               try {
                  this.r.cancelInquiry(this);
               } catch (Exception var4) {
               }
               break;
            case 1048833:
               if (this.e != null) {
                  this.e.close();
                  this.e = null;
               }

               this.f = null;
         }

         this.w.y = var1;
         this.a.A(12, var1, (Object)null, (String)null);
         switch (var1) {
            case 2:
               this.A(32, this.j, 30, 0, (byte[])null);
         }

         switch (var1) {
            case 1:
               this.q = LocalDevice.getLocalDevice();
               this.r = this.q.getDiscoveryAgent();
               break;
            case 65794:
               this.A(65796);
               break;
            case 65795:
            case 65797:
               this.B();
               break;
            case 65796:
               this.r.startInquiry(10390323, this);
               break;
            case 1048833:
               String var2 = "btspp://localhost:" + this.v.toString() + ";name=" + "StackAttack4";
               this.e = Connector.open(var2);
               this.q.setDiscoverable(10390323);

               for(int var6 = 0; var6 < 8; ++var6) {
                  this.b[var6] = null;
                  this.g[var6] = null;
                  this.c[var6] = null;
                  this.d[var6] = null;
               }

               this.g[0] = this.w.x.i;
               this.b[0] = null;
               this.j = 0;
               this.f = new Thread(this);
               this.f.start();
               if (this.p == null) {
                  this.p = new BluetoothPoller(this.w, this);
               }
         }
      } catch (Exception var5) {
         this.a.A(14, 0, var5, (String)null);
      }

   }

   public void A() {
      this.A(32, this.j, 30, 0, (byte[])null);
      this.A(2);
      this.A(0);
   }

   protected void B() {
      if (!this.s.empty()) {
         try {
            RemoteDevice var1 = (RemoteDevice)this.s.pop();
            this.t = this.r.searchServices(new int[]{0, 1, 4, 256}, new UUID[]{new UUID("1101", true)}, var1, this);
            this.u.addElement(new Integer(this.t));
         } catch (Exception var3) {
            this.a.A(14, 0, var3, (String)null);
         }
      } else {
         try {
            switch (this.w.y) {
               case 65795:
                  this.A(65796);
                  break;
               case 65797:
                  boolean var2 = false;

                  for(int var5 = 0; var5 < 8; ++var5) {
                     if (this.b[var5] != null) {
                        var2 = true;
                        break;
                     }
                  }

                  this.w.y = 65539;
                  this.a.A(var2 ? 2 : 1, 0, (Object)null, (String)null);
            }
         } catch (Exception var4) {
            this.a.A(14, 0, var4, (String)null);
         }
      }

   }

   public void deviceDiscovered(RemoteDevice var1, DeviceClass var2) {
      try {
         if ((var2.getMajorDeviceClass() & 512) != 0) {
            this.s.push(var1);
         }
      } catch (Exception var3) {
      }

   }

   public void inquiryCompleted(int var1) {
      if (var1 != 5) {
         this.w.y = 65539;
         this.A(65797);
      }

   }

   public void servicesDiscovered(int var1, ServiceRecord[] var2) {
      try {
         for(int var4 = 0; var4 < var2.length; ++var4) {
            DataElement var7 = var2[var4].getAttributeValue(256);
            String var3 = (String)(var7 == null ? "<no name>" : var7.getValue());
            var7 = var2[var4].getAttributeValue(1);
            Enumeration var9 = (Enumeration)(var7 == null ? null : var7.getValue());
            if (var3 != null && var9 != null && var3.equals("StackAttack4")) {
               int var12 = -1;

               for(int var10 = 0; var10 < 8; ++var10) {
                  if (this.b[var10] == null) {
                     var12 = var10;
                     break;
                  }
               }

               if (var12 != -1) {
                  this.b[var12] = var2[var4];

                  String var11;
                  try {
                     var11 = var2[var4].getHostDevice().getFriendlyName(true);
                  } catch (Exception var5) {
                     var11 = "<unknown>";
                  }

                  this.a.A(3, var12, var2[var4], var11);
               }
               break;
            }
         }
      } catch (Exception var6) {
      }

   }

   public void serviceSearchCompleted(int var1, int var2) {
      this.B();
   }

   public boolean A(Object var1, boolean var2) {
      DataInputStream var6 = null;
      DataOutputStream var5 = null;
      byte var4 = -1;

      try {
         if (var2) {
            var4 = 0;

            for(byte var3 = 0; var3 < 8; ++var3) {
               this.b[var3] = null;
               this.c[var3] = null;
               this.d[var3] = null;
            }

            this.A(65541);
         } else {
            for(byte var17 = 1; var17 < 8; ++var17) {
               if (this.b[var17] == null) {
                  var4 = var17;
                  break;
               }
            }

            if (var4 == -1) {
               ((Connection)var1).close();
               return false;
            }
         }

         if (var1 instanceof ServiceRecord) {
            try {
               String var10 = ((ServiceRecord)var1).getConnectionURL(0, false);
               var1 = Connector.open(var10);
            } catch (Exception var8) {
               throw var8;
            }
         }

         if (var1 instanceof StreamConnection) {
            StreamConnection var18 = (StreamConnection)var1;
            var6 = var18.openDataInputStream();
            var5 = var18.openDataOutputStream();
         }

         if (var4 == -1) {
            return false;
         } else {
            this.c[var4] = var6;
            this.d[var4] = var5;
            this.b[var4] = var1;
            byte[] var11 = null;
            if (!var2) {
               byte[] var13 = new byte[5];
               var13[4] = var4;
               this.A(var4, this.w.x.j, 21, 1, var13);

               for(byte var21 = 0; var21 < 8; ++var21) {
                  if (this.g[var21] != null) {
                     try {
                        ByteArrayOutputStream var19 = new ByteArrayOutputStream();
                        DataOutputStream var14 = new DataOutputStream(var19);
                        var14.writeUTF(this.g[var21]);
                        var11 = var19.toByteArray();
                        var14.close();
                     } catch (Exception var7) {
                     }

                     int var20 = 8 + var11.length;
                     var13 = new byte[var20 + 4];
                     var13[4] = var21;
                     System.arraycopy(this.h[var21], 0, var13, 5, 3);
                     var13[8] = (byte)(var11.length & 255);
                     var13[9] = (byte)(var11.length >>> 8 & 255);
                     var13[10] = (byte)(var11.length >>> 16 & 255);
                     var13[11] = (byte)(var11.length >>> 24 & 255);
                     System.arraycopy(var11, 0, var13, 12, var11.length);
                     this.A(var4, this.w.x.j, 23, var20, var13);
                  }
               }
            }

            long var16 = System.currentTimeMillis();
            var11 = new byte[12];
            var11[4] = (byte)((int)(var16 & 255L));
            var11[5] = (byte)((int)(var16 >>> 8 & 255L));
            var11[6] = (byte)((int)(var16 >>> 16 & 255L));
            var11[7] = (byte)((int)(var16 >>> 24 & 255L));
            var11[8] = (byte)((int)(var16 >>> 32 & 255L));
            var11[9] = (byte)((int)(var16 >>> 40 & 255L));
            var11[10] = (byte)((int)(var16 >>> 48 & 255L));
            var11[11] = (byte)((int)(var16 >>> 56 & 255L));
            this.A(var4, this.w.x.j, 10, 8, var11);
            if (this.p == null) {
               this.p = new BluetoothPoller(this.w, this);
            }

            return true;
         }
      } catch (Exception var9) {
         this.a.A(14, 0, var9, (String)null);
         return false;
      }
   }

   public void C() {
      byte var6 = 8;

      while(true) {
         --var6;
         if (var6 < 0) {
            return;
         }

         if (this.b[var6] != null) {
            DataInputStream var5 = this.c[var6];

            try {
               while(true) {
                  byte[] var4 = new byte[48];
                  if (this.b[var6] instanceof L2CAPConnection) {
                     L2CAPConnection var2 = (L2CAPConnection)this.b[var6];
                     if (!var2.ready()) {
                        break;
                     }

                     var2.receive(var4);
                  }

                  if (this.b[var6] instanceof StreamConnection) {
                     if (var5.available() == 0) {
                        break;
                     }

                     short var3 = var5.readShort();
                     short var10 = var5.readShort();
                     var4 = new byte[4 + var10];

                     for(int var1 = 0; var1 < var10; var1 += var5.read(var4, var1 + 4, var10 - var1)) {
                     }

                     var4[0] = (byte)(var3 & 255);
                     var4[1] = (byte)(var3 >>> 8 & 255);
                     var4[2] = (byte)(var10 & 255);
                     var4[3] = (byte)(var10 >>> 8 & 255);
                  }

                  short var11 = (short)((var4[0] + 256) % 256 | (var4[1] + 256) % 256 << 8);
                  short var9 = (short)((var4[2] + 256) % 256 | (var4[3] + 256) % 256 << 8);
                  if (var11 == 0) {
                     break;
                  }

                  this.A(var11, var6, var9, var4);
               }
            } catch (IOException var7) {
               this.A(var6, this.j, 30, 0, (byte[])null);
            } catch (Exception var8) {
            }
         }
      }
   }

   public void A(int var1, int var2, int var3, byte[] var4) {
      if (var1 < 256) {
         switch (var1) {
            case 20:
               try {
                  var1 = (var4[5] + 256) % 256 | (var4[6] + 256) % 256 << 8 | (var4[7] + 256) % 256 << 16 | (var4[8] + 256) % 256 << 24;
                  ByteArrayInputStream var16 = new ByteArrayInputStream(var4, 9, var1);
                  DataInputStream var17 = new DataInputStream(var16);
                  this.g[var2] = var17.readUTF();
                  var17.close();
               } catch (Exception var8) {
               }

               this.a.A(10, var2, (Object)null, this.g[var2]);
               byte[] var30 = new byte[42];
               var30[4] = (byte)var2;
               System.arraycopy(this.h[var2], 0, var30, 5, 3);

               try {
                  var4 = null;

                  try {
                     ByteArrayOutputStream var28 = new ByteArrayOutputStream();
                     DataOutputStream var18 = new DataOutputStream(var28);
                     var18.writeUTF(this.g[var2]);
                     var4 = var28.toByteArray();
                     var18.close();
                  } catch (Exception var6) {
                  }

                  var30[8] = (byte)(var4.length & 255);
                  var30[9] = (byte)(var4.length >>> 8 & 255);
                  var30[10] = (byte)(var4.length >>> 16 & 255);
                  var30[11] = (byte)(var4.length >>> 24 & 255);
                  System.arraycopy(var4, 0, var30, 12, var4.length);
               } catch (Exception var7) {
               }

               this.A(64, this.w.x.j, 23, 38, var30);
               break;
            case 21:
               this.j = var4[4];
               byte[] var27 = null;

               try {
                  ByteArrayOutputStream var24 = new ByteArrayOutputStream();
                  DataOutputStream var13 = new DataOutputStream(var24);
                  var13.writeUTF(this.i);
                  var27 = var24.toByteArray();
                  var13.close();
               } catch (Exception var9) {
               }

               byte[] var14 = new byte[var27.length + 5 + 4];
               var14[4] = (byte)this.j;
               var14[5] = (byte)(var27.length & 255);
               var14[6] = (byte)(var27.length >>> 8 & 255);
               var14[7] = (byte)(var27.length >>> 16 & 255);
               var14[8] = (byte)(var27.length >>> 24 & 255);
               System.arraycopy(var27, 0, var14, 9, var27.length);
               this.A(0, this.w.x.j, 20, var27.length + 5, var14);
               this.a.y = 65536;
               this.a.A(11, 0, (Object)null, (String)null);
               break;
            case 22:
               this.a.A(6, 0, (Object)null, (String)null);
               break;
            case 23:
               var3 = var4[4];
               System.arraycopy(var4, 5, this.h[var3], 0, 3);

               try {
                  var2 = (var4[8] + 256) % 256 | (var4[9] + 256) % 256 << 8 | (var4[10] + 256) % 256 << 16 | (var4[11] + 256) % 256 << 24;
                  ByteArrayInputStream var22 = new ByteArrayInputStream(var4, 12, var2);
                  DataInputStream var23 = new DataInputStream(var22);
                  this.g[var3] = var23.readUTF();
                  var23.close();
               } catch (Exception var10) {
               }

               if (var1 == 23) {
                  this.a.A(8, var3, (Object)null, this.g[var3]);
               }
               break;
            case 24:
               var2 = (short)var4[4];
               String var12 = this.g[var2];
               this.g[var2] = null;
               this.a.A(9, var2, (Object)null, var12);
               break;
            case 30:
               this.A(var2, this.w.x.j, 30, 0, (byte[])null);
               break;
            case 40:
               byte var5 = var4[4];
               var3 = var4[5];
               var2 = (short)((var4[6] + 256) % 256 | (var4[7] + 256) % 256 << 8);
               var1 = (short)((var4[8] + 256) % 256 | (var4[9] + 256) % 256 << 8);
               System.arraycopy(var4, 6, var4, 0, var4.length - 6);
               this.A(var5, var3, var2, var1, var4);
         }
      } else {
         this.a.A(var1, var2, var3, var4);
      }

   }

   public void A(int var1, int var2, int var3, int var4, byte[] var5) {
      try {
         if (var5 == null) {
            var5 = new byte[4];
         }

         var5[0] = (byte)(var3 & 255);
         var5[1] = (byte)(var3 >>> 8 & 255);
         var5[2] = (byte)(var4 & 255);
         var5[3] = (byte)(var4 >>> 8 & 255);
         if ((var1 & 4096) != 0) {
            byte[] var6 = new byte[var5.length + 6 + 4];
            if (var4 > 0) {
               System.arraycopy(var5, 0, var6, 6, var5.length);
            }

            var5 = var6;
            var3 = 40;
            var4 += 6;
            var6[0] = 40;
            var6[1] = 0;
            var6[2] = (byte)(var4 & 255);
            var6[3] = (byte)(var4 >>> 8 & 255);
            var6[4] = (byte)(var1 & 255);
            var6[5] = (byte)this.j;
            var1 = 0;
         }

         if ((var1 & 240) != 0) {
            int var12 = 8;

            while(true) {
               --var12;
               if (var12 < 0) {
                  break;
               }

               if ((var1 != 32 || var12 != var2) && (this.b[var12] != null || var12 == this.j)) {
                  this.A(var12, this.w.x.j, var3, var4, var5);
               }
            }
         } else if (var1 == this.j) {
            this.A((short)var3, (byte)this.j, (short)var4, var5);
         } else if (this.b[var1] != null) {
            if (this.b[var1] instanceof L2CAPConnection) {
               ((L2CAPConnection)this.b[var1]).send(var5);
            }

            if (this.b[var1] instanceof StreamConnection) {
               DataOutputStream var10 = this.d[var1];
               var10.writeShort((short)var3);
               var10.writeShort((short)var4);
               if (var4 > 0) {
                  var10.write(var5, 4, var4);
               }

               var10.flush();
            }
         }
      } catch (Exception var9) {
         if (var3 != 30) {
            this.A(var1, this.j, 30, 0, (byte[])null);
         }
      }

      try {
         switch (var3) {
            case 30:
               if (var1 >= 0 && var1 < 8) {
                  try {
                     if (this.c[var1] != null) {
                        this.c[var1].close();
                        this.c[var1] = null;
                     }

                     if (this.d[var1] != null) {
                        this.d[var1].close();
                        this.d[var1] = null;
                     }

                     if (this.b[var1] != null) {
                        ((Connection)this.b[var1]).close();
                     }
                  } catch (Exception var7) {
                  }

                  this.b[var1] = null;
                  this.g[var1] = null;
                  if ((this.w.y & 1048576) != 0) {
                     byte[] var11 = new byte[5];
                     var11[4] = (byte)var1;
                     this.A(64, this.j, 24, 1, var11);
                  } else if ((this.w.y & 65536) != 0) {
                     this.a.A(5, 0, (Object)null, this.g[0]);
                  }
               }
         }
      } catch (Exception var8) {
      }

   }

   public void A(int var1, int var2, String var3) {
      byte[] var6 = null;

      try {
         ByteArrayOutputStream var5 = new ByteArrayOutputStream();
         DataOutputStream var4 = new DataOutputStream(var5);
         var4.writeUTF(var3);
         var6 = var5.toByteArray();
         var4.close();
      } catch (Exception var7) {
      }

      byte[] var8 = new byte[var6.length + 5 + 4];
      var8[4] = (byte)var2;
      var8[5] = (byte)(var6.length & 255);
      var8[6] = (byte)(var6.length >>> 8 & 255);
      var8[7] = (byte)(var6.length >>> 16 & 255);
      var8[8] = (byte)(var6.length >>> 24 & 255);
      System.arraycopy(var6, 0, var8, 9, var6.length);
      this.A(4096 | var1, this.w.x.j, 500, var6.length + 1, var8);
   }

   public boolean D() {
      boolean var2 = false;
      if (this.w.x.l[0] && Integer.parseInt(this.w.x.k[0][1]) == 64) {
         this.A(32, this.j, StackAttack.A(this.w)[31][0]);
         var2 = true;
      } else {
         for(int var1 = 0; var1 < 8; ++var1) {
            if (this.w.x.l[var1]) {
               this.A((byte)Integer.parseInt(this.w.x.k[var1][1]), this.j, StackAttack.A(this.w)[31][0]);
               var2 = true;
            }
         }
      }

      return var2;
   }
}

final class BluetoothPoller extends Thread {
   protected BluetoothLink a;

   public BluetoothPoller(StackAttack var1, BluetoothLink var2) {
      this.a = var2;
      ((Thread)this).start();
   }

   public void run() {
      try {
         for(; this.a != null && this.a.a != null && this.a.a.y != 0; this.a.C()) {
            try {
               Thread.sleep(25L);
            } catch (Exception var1) {
            }
         }
      } catch (Exception var2) {
      }

      this.a.p = null;
   }
}

class SmsMessenger {
   private int a = 0;
   private int b = 0;
   private int c;
   private Vector d = new Vector();
   private Vector e = new Vector();
   private Vector f = new Vector();
   private String g = "";
   private String h = "";
   private Vector i = new Vector();
   private String[] j = new String[]{"text/plain", "", "text/plain", "image/png", "image/bmp", "image/gif"};
   private String[] k = new String[]{".txt", ".bin", ".txt", ".png", ".bmp", ".gif", ".jpg"};
   private String l = "";

   SmsMessenger(Object var1) {
   }

   public void A(int var1) {
      this.b |= var1;
   }

   public boolean B(int var1) {
      return (this.b & var1) > 0;
   }

   public void C(int var1) {
      this.c = var1;
   }

   public int A() {
      return this.c;
   }

   public void A(String var1) {
      this.g = var1;
   }

   public String B() {
      return this.g;
   }

   public void B(String var1) {
      this.h = var1;
   }

   private void A(Vector var1, String var2) {
      boolean var3 = false;

      for(int var4 = 0; var4 < var1.size(); ++var4) {
         if (((String)var1.elementAt(var4)).compareTo(var2) == 0) {
            var3 = true;
            break;
         }
      }

      if (!var3) {
         var1.addElement(var2);
      }

   }

   public void C(String var1) {
      if (var1.length() != 0) {
         this.A(this.d, var1);
      }

   }

   public void A(int var1, Object var2) {
      if (this.c != 1 || this.i.size() <= 0) {
         if (this.c != 1 || var1 < 1) {
            Object[] var3 = new Object[]{new Integer(var1), var2, this.j[var1], this.k[var1]};
            if (var1 == 2 || var1 == 3) {
               var1 = ((String)var2).indexOf(46);
               String var5 = ((String)var2).substring(var1 + 1);
               var3[3] = "";
               if (var5.compareTo("png") == 0) {
                  var3[2] = "image/png";
                  var3[3] = ".png";
               } else if (var5.compareTo("bmp") == 0) {
                  var3[2] = "image/bmp";
                  var3[3] = ".bmp";
               } else if (var5.compareTo("gif") == 0) {
                  var3[2] = "image/gif";
                  var3[3] = ".gif";
               } else if (var5.compareTo("mid") == 0) {
                  var3[2] = "image/mid";
                  var3[3] = ".mid";
               } else if (var5.compareTo("jpg") == 0) {
                  var3[2] = "image/jpeg";
                  var3[3] = ".jpg";
               } else {
                  var3[2] = "text/plain";
               }
            }

            this.i.addElement(var3);
         }
      }
   }

   public void C() {
      this.i.removeAllElements();
   }

   public int D(String var1) {
      byte var4 = 0;
      MessageConnection var3 = null;

      try {
         var3 = (MessageConnection)Connector.open(var1);
         TextMessage var13 = (TextMessage)var3.newMessage("text");
         var13.setPayloadText(this.g + " " + this.h);
         var3.send(var13);
      } catch (Exception var11) {
         var4 = -1;
      } finally {
         if (var3 != null) {
            try {
               var3.close();
            } catch (Exception var10) {
            }
         }

      }

      return var4;
   }

   public int A(String var1, byte[] var2) {
      byte var4 = 0;
      MessageConnection var3 = null;

      try {
         var3 = (MessageConnection)Connector.open(var1);
         BinaryMessage var13 = (BinaryMessage)var3.newMessage("binary");
         var13.setPayloadData(var2);
         var3.send(var13);
      } catch (Exception var11) {
         var4 = -1;
      } finally {
         if (var3 != null) {
            try {
               var3.close();
            } catch (Exception var10) {
            }
         }

      }

      return var4;
   }

   private int D() {
      int var1 = -1;

      for(int var3 = 0; var3 < this.d.size(); ++var3) {
         String var2 = "sms://" + this.d.elementAt(var3);
         if (this.i.size() > 0) {
            Object[] var4 = (Object[])this.i.elementAt(0);
            if (((Integer)var4[0]).equals(new Integer(1))) {
               var1 = this.A(var2, (byte[])var4[1]);
            } else {
               var1 = this.D(var2);
            }
         } else {
            var1 = this.D(var2);
         }
      }

      return var1;
   }

   private int E() {
      return 0;
   }

   public int F() {
      this.a = -1;
      if (this.d.size() == 0) {
         return -1;
      } else {
         switch (this.c) {
            case 1:
               this.a = this.D();
               break;
            case 2:
               this.a = this.E();
         }

         return this.a;
      }
   }

   public void G() {
      this.a = 0;
      this.c = -1;
      this.b = 0;
      this.g = "";
      this.h = "";
      this.d.removeAllElements();
      this.e.removeAllElements();
      this.f.removeAllElements();
      this.i.removeAllElements();
      this.l = "";
   }

   public String H() {
      return this.l;
   }

   public int I() {
      return this.a;
   }
}

class HttpClient {
   public int a;
   private String b = "";
   private String c = "";
   private String d = "";
   private int e;
   private StringBuffer f;
   private byte[] g;

   HttpClient(String var1, int var2) {
      this.d = var1;
      this.g = new byte[]{(byte)(var2 & 255), (byte)(var2 >>> 8 & 255), (byte)(var2 >>> 16 & 255), (byte)(var2 >>> 24 & 255)};
   }

   public void A() {
   }

   public void A(String var1) {
      this.b = var1;
      this.c = this.E(this.b);
   }

   public String B() {
      return this.b;
   }

   public void A(int var1) {
      this.e = var1;
   }

   public String C() {
      return this.f.toString();
   }

   public int D() {
      this.a = -1;

      try {
         this.a = this.F(this.c);
         if (this.a != 0) {
            return -1;
         }

         String var2 = this.f.toString();
         if (var2 != null) {
            if (var2.indexOf("alternative nick") != -1) {
               int var1 = var2.indexOf(58);
               if (var1 != -1) {
                  this.b = this.C(var2.substring(var1 + 1));
               }

               this.a = 1;
            } else if (var2.indexOf("registration successful") != -1) {
               this.a = 0;
            }
         }
      } catch (Exception var3) {
         (new StringBuffer()).append("Exception ").append(var3).toString();
         this.a = -2;
      }

      return this.a;
   }

   public String B(String var1) {
      String var8 = "";
      boolean var7 = true;
      String var6 = "";
      String[] var5 = new String[4];
      String[] var4 = new String[4];
      if (var1 != null) {
         if (var1.length() == 66 || var1.length() == 122 || var1.length() == 178) {
            StringBuffer var3 = new StringBuffer();
            int var2 = var1.length();
            var3.append(var1.substring(0, var2));

            for(int var10 = var2; var10 < 234; ++var10) {
               var3.append("0");
            }

            var1 = new String(var3);
         }

         if (var1.length() == 234) {
            var6 = String.valueOf(Integer.parseInt(var1.substring(2, 10), 16));

            for(int var15 = 0; var15 < 4; ++var15) {
               var5[var15] = this.C(var1.substring(10 + var15 * 56, 10 + var15 * 56 + 48));
               var4[var15] = String.valueOf(Integer.parseInt(var1.substring(58 + var15 * 56, 58 + var15 * 56 + 8), 16));
            }

            var7 = false;
         }
      }

      if (!var7) {
         var8 = "" + StackAttack.E(214) + " " + var6 + "\n\n" + StackAttack.E(200) + "\n\n";

         for(int var9 = 0; var9 < 4; ++var9) {
            var1 = var8 + StackAttack.E(135) + " ";
            var1 = var1 + var5[var9];
            var1 = var1 + "\n" + StackAttack.E(162) + " ";
            var1 = var1 + var4[var9];
            var8 = var1 + "\n\n";
         }
      }

      return var8;
   }

   public byte[] B(int var1) {
      byte[] var2 = new byte[4];

      for(int var3 = 3; var3 >= 0; --var3) {
         var2[var3] = (byte)(var1 & 255);
         var1 >>= 8;
      }

      return var2;
   }

   public int E() throws Exception {
      if (this.b == null) {
         return -1;
      } else {
         byte[] var1 = this.B(this.e);
         var1[0] = (byte)(var1[0] ^ (this.g[3] + 256) % 256);
         var1[1] = (byte)(var1[1] ^ (this.g[2] + 256) % 256);
         var1[2] = (byte)(var1[2] ^ (this.g[1] + 256) % 256);
         var1[3] = (byte)(var1[3] ^ (this.g[0] + 256) % 256);
         String var3 = this.A(this.b, var1);
         int var2 = this.F(var3);
         return var2;
      }
   }

   private String C(String var1) {
      StringBuffer var2 = new StringBuffer();

      for(int var3 = 0; var3 < var1.length(); var3 += 4) {
         var2.append((char)Integer.parseInt(var1.substring(var3 + 0, var3 + 4), 16));
      }

      return var2.toString().trim();
   }

   private byte[] D(String var1) {
      char[] var2 = var1.toCharArray();
      byte[] var4 = new byte[var2.length * 2];

      for(int var3 = 0; var3 < var2.length; ++var3) {
         var4[var3 * 2 + 0] = (byte)(var2[var3] >> 8 & 255);
         var4[var3 * 2 + 1] = (byte)(var2[var3] & 255);
      }

      return var4;
   }

   private String A(byte[] var1) {
      StringBuffer var2 = new StringBuffer();

      for(int var3 = 0; var3 < var1.length; ++var3) {
         var2.append(Integer.toHexString((var1[var3] & 240) >> 4));
         var2.append(Integer.toHexString(var1[var3] & 15));
      }

      return var2.toString();
   }

   private String A(String var1, byte[] var2) {
      return "http://139.23.38.140/hs/hs.asp?imei=" + System.getProperty("device.imei").trim() + "&" + "nick=" + this.A(this.D(var1)) + "&" + "appid=" + this.d + "&" + "hs=" + this.A(var2);
   }

   private String E(String var1) {
      String var2 = "http://139.23.38.140/hs/user.asp?imei=" + System.getProperty("device.imei").trim() + "&" + "nick=" + this.A(this.D(var1)) + "&" + "appid=" + this.d + "&" + "mcc=" + System.getProperty("device.MCC").trim() + "&" + "mnc=" + System.getProperty("device.MNC").trim();
      return var2;
   }

   private int F(String var1) throws Exception {
      HttpConnection var3 = null;
      InputStream var2 = null;

      try {
         var3 = (HttpConnection)Connector.open(var1);
         var2 = var3.openInputStream();
         var3.getType();
         int var7 = (int)var3.getLength();
         if (var7 > 0) {
            byte[] var4 = new byte[var7];
            var2.read(var4);
            this.f = new StringBuffer(new String(var4));
         } else {
            this.f = new StringBuffer();

            while((var7 = var2.read()) != -1) {
               if (this.f.length() < 100) {
                  this.f.append((char)var7);
               }
            }
         }
      } finally {
         if (var2 != null) {
            var2.close();
         }

         if (var3 != null) {
            var3.close();
         }

      }

      return 0;
   }
}
