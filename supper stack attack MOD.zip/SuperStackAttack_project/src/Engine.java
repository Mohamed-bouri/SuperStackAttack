import com.vodafone.util.ImageEncoder;
import java.io.OutputStream;
import javax.microedition.io.Connection;
import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.lcdui.game.Sprite;

/**
 * Rendering and loop: GameCanvasLoop (canvas + frame loop), SpriteEngine (sprite slots and drawing), SpriteSheet (image set), SpriteState (one sprite).
 */
class GameCanvasLoop extends GameCanvas implements Runnable {
   private StackAttack a;
   public int b;
   public int c;
   public boolean d;
   public boolean e;
   Thread f = null;
   private long g;
   private long h;
   int i;

   public GameCanvasLoop(StackAttack var1, int var2, int var3) {
      super(false);
      var1.sprites.a = ((GameCanvas)this).getGraphics();
      this.a = var1;
      this.b = var2;
      this.c = var3;
      ((Canvas)this).setFullScreenMode(true);
   }

   public int A() {
      return this.i;
   }

   public void A(boolean var1, boolean var2) {
      if (this.f != null) {
         this.d = false;
         this.e = false;

         try {
            try {
               Thread.sleep(100L);
            } catch (Exception var3) {
            }
         } catch (Exception var4) {
         }
      }

      this.d = var1;
      this.e = var2;
      this.f = new Thread(this);
      this.f.start();
   }

   public void paint(Graphics var1) {
      super.paint(var1);
   }

   protected void keyPressed(int var1) {
      this.i = var1;
      if ((this.c & 4096) != 0) {
         this.a.M(var1);
      }

   }

   protected void keyRepeated(int var1) {
      this.i = var1;
      if ((this.c & 4096) != 0) {
         this.a.M(var1);
      }

   }

   protected void keyReleased(int var1) {
      if ((this.c & 4096) != 0) {
         this.i = 0;
         this.a.N(var1);
      } else {
         this.c = 4;
         synchronized(this) {
            this.notifyAll();
         }
      }

   }

   public void run() {
      if ((this.c & 4096) == 0) {
         synchronized(this) {
            this.a.A(this.a.sprites.a);
            ((GameCanvas)this).flushGraphics();

            try {
               this.wait((long)this.b);
            } catch (Exception var3) {
            }
         }

         this.a.B(this.c | 1024, false);
      } else {
         do {
            if (this.e) {
               this.a.L();
               this.a.A(this.a.sprites.a);
               ((GameCanvas)this).flushGraphics();
            }

            this.g = System.currentTimeMillis() - this.h;
            if (this.g < this.a.fA) {
               try {
                  Thread.sleep(this.a.fA - this.g);
               } catch (Exception var5) {
               }
            }

            this.h = System.currentTimeMillis();
         } while(this.d);
      }

   }

   public void hideNotify() {
      this.a.B();
   }

   public void showNotify() {
      this.a.C();
   }
}

class SpriteEngine {
   Graphics a = null;
   Image b = null;
   SpriteSheet[] c = new SpriteSheet[18];
   SpriteState[] d = new SpriteState[162];
   int e = 0;
   SpriteState[] f = new SpriteState[162];
   int g = 0;
   public int h = 0;
   public int i = 0;

   public void A() {
      try {
         this.b = Image.createImage(240, 320);
      } catch (Exception var1) {
      }

   }

   public void B() {
      this.a.setColor(0);
      this.a.fillRect(0, 0, 240, 320);
   }

   public int A(SpriteSheet var1) {
      int var3 = 0;

      int var2;
      for(var2 = this.c.length; var3 < var2; ++var3) {
         if (this.c[var3] == null) {
            this.c[var3] = var1;
            break;
         }
      }

      if (var3 >= var2) {
         var3 = -1;
      }

      return var3;
   }

   public void A(int var1) {
      if (var1 != -1) {
         this.c[var1] = null;
      }
   }

   public SpriteState C() {
      SpriteState var4 = null;
      SpriteState[] var3 = this.f;
      if (this.g > 0) {
         int var2 = 0;

         for(int var1 = var3.length; var2 < var1; ++var2) {
            if (var3[var2] != null) {
               var4 = var3[var2];
               var3[var2] = null;
               --this.g;
               break;
            }
         }
      }

      if (var4 == null) {
         var4 = new SpriteState();
      }

      var4.a = 0;
      var4.b = 0;
      var4.c = 0;
      var4.d = 0;
      var4.e = 0;
      var4.f = 0;
      var4.g = 0;
      var4.h = 0;
      return var4;
   }

   public int A(SpriteState var1) {
      int var4 = 0;
      SpriteState[] var3 = this.d;

      int var2;
      for(var2 = this.d.length; var4 < var2; ++var4) {
         if (var3[var4] == null) {
            var3[var4] = var1;
            ++this.e;
            break;
         }
      }

      if (var4 >= var2) {
         var4 = -1;
      }

      return var4;
   }

   public int B(int var1) {
      if (var1 == -1) {
         return -1;
      } else {
         int var4 = 0;
         SpriteState[] var3 = this.f;

         int var2;
         for(var2 = var3.length; var4 < var2; ++var4) {
            if (var3[var4] == null) {
               var3[var4] = this.d[var1];
               this.d[var1] = null;
               --this.e;
               ++this.g;
               break;
            }
         }

         if (var4 >= var2) {
            var4 = -1;
         }

         return var4;
      }
   }

   public void C(int var1) {
      SpriteState[] var4 = this.f;
      int var3 = var4.length;
      int var2 = 0;

      while(this.g < var1 + 1) {
         if (var2 < var3) {
            if (var4[var2] == null) {
               var4[var2] = new SpriteState();
               ++this.g;
            } else {
               ++var2;
            }
         }
      }

   }

   public void D(int var1) {
      this.a.setColor(var1);
      this.a.fillRect(0, 0, 240, 320);
   }

   public void A(int var1, int var2, int var3) {
      this.h = var1;
      this.i = var2;
      this.h *= -1;
      this.i *= -1;
   }

   boolean A(SpriteSheet var1, int var2, int var3) {
      return var2 <= 240 && var2 + var1.g >= 0 && var3 <= 320 && var3 + var1.h >= 0;
   }

   void A(SpriteSheet var1, SpriteState var2, int var3, int var4, int var5) {
      Graphics var6 = this.a;
      Sprite var9 = (Sprite)var1.b[var2.d];
      int var7 = var2.f / var1.d[var2.e][3];
      var7 = var2.e * var1.e + var7;
      if (var7 >= 0 && var7 < var9.getRawFrameCount()) {
         var9.setFrame(var7);
         var9.setRefPixelPosition(var3, var4);
         var9.paint(var6);
      }

   }

   void B(SpriteSheet var1) {
      int var3 = 0;

      for(boolean var2 = true; var3 < var1.b.length; ++var3) {
         Image var4 = (Image)var1.b[var3];
         if (var4 != null) {
            if (var2) {
               if (var1.e == 0) {
                  var1.g = var4.getWidth();
               } else {
                  var1.g = var4.getWidth() / var1.e;
               }

               if (var1.d.length == 0) {
                  var1.h = var4.getHeight();
               } else {
                  var1.h = var4.getHeight() / var1.d.length;
               }

               var2 = false;
            }

            var1.b[var3] = new Sprite(var4, var1.g, var1.h);
         }
      }

   }

   public void E(int var1) {
      SpriteState var4 = this.d[var1];
      int var3 = var4.b;
      int var2 = var4.c;
      if ((var4.h & 1) != 0) {
         var3 += this.h;
         var2 += this.i;
      }

      SpriteSheet var5 = this.c[var4.a];
      switch (var5.a) {
         case 0:
            if ((var4.h & 4) != 0) {
               if (this.A(var5, var3, var2)) {
                  this.A(var5, var4, var3, var2, 0);
               }
            } else {
               this.A(var5, var4, var3, var2, 0);
            }
         case 1:
         case 2:
         default:
      }
   }

   void C(SpriteSheet var1) {
      switch (var1.a) {
         case 0:
            this.B(var1);
         case 1:
         case 2:
         default:
      }
   }

   int D(SpriteSheet var1) {
      int var2 = 0;
      switch (var1.a) {
         case 0:
            var2 = var1.g;
            break;
         case 3:
            var2 = 0;
      }

      return var2;
   }

   int E(SpriteSheet var1) {
      int var2 = 0;
      switch (var1.a) {
         case 0:
            var2 = var1.h;
            break;
         case 3:
            var2 = 0;
      }

      return var2;
   }

   void B(SpriteSheet var1, int var2, int var3) {
      var1.a = var2;
      var1.b = new Object[var3];
      var1.c = new int[var3];
   }

   public void A(SpriteSheet var1, int var2, int var3, int var4, Image var5) {
      switch (var1.a) {
         case 0:
            var1.b[var2] = var5;
            var1.c[var2] = var3;
         case 1:
         default:
      }
   }

   public void A(SpriteSheet var1, int[][] var2) {
      var1.d = var2;

      for(int var3 = 0; var3 < var2.length; ++var3) {
         int var4 = var1.d[var3][1] * var1.d[var3][2];
         var1.f += var4;
         if (var4 > var1.e) {
            var1.e = var4;
         }
      }

   }

   public void A(StackAttack var1, String var2) {
      var1.i.paint(this.b.getGraphics());

      try {
         String var3 = "file:///" + "fs/MyStuff/Pictures/" + "SuperStackAttack" + "/" + "";
         var2 = "file:///" + "fs/MyStuff/Pictures/" + "SuperStackAttack" + "/" + "abc" + "." + "png";
         byte[] var10 = null;

         try {
            ImageEncoder var4 = ImageEncoder.createEncoder(0);
            var10 = var4.encodeOffscreen(this.b, 0, 0, this.b.getWidth(), this.b.getHeight());
         } catch (Exception var6) {
         }

         if (var10 != null) {
            Object var12 = null;

            try {
               StackAttack.E(var3);
               FileConnection var13 = (FileConnection)Connector.open(var2, 3);
               if (!var13.exists()) {
                  var13.create();
               }

               if (var13 != null) {
                  OutputStream var9 = var13.openOutputStream();
                  var9.write(var10);
                  var9.close();
               }

               var13.close();
            } catch (Exception var7) {
               if (var12 != null) {
                  try {
                     ((Connection)var12).close();
                  } catch (Exception var5) {
                  }
               }
            }
         }
      } catch (Exception var8) {
      }

   }

   SpriteEngine(StackAttack var1) {
   }
}

class SpriteSheet {
   public int a = 0;
   public Object[] b = null;
   public int[] c = null;
   public int[][] d = (int[][])null;
   public int e = 0;
   public int f = 0;
   public int g = 0;
   public int h = 0;
}

class SpriteState {
   public int a = 0;
   public int b = 0;
   public int c = 0;
   public int d = 0;
   public int e = 0;
   public int f = 0;
   public int g = 0;
   public int h = 0;
}
