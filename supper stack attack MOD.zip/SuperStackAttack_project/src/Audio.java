import java.io.InputStream;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import javax.microedition.media.control.VolumeControl;

/**
 * Sound: SoundManager (sound table, MIDI players, volume) and SoundStartThread (starts a sound without blocking the game).
 *  Sound table row: {id, file index, preload, keep loaded, type (6 = midi), loops (-1 = forever), -, async start, priority}.
 */
class SoundManager {
   private byte[][] a = new byte[][]{{0, 0, 1, 1, 6, 0, 0, 0, 0}, {1, 1, 1, 1, 6, 0, 0, 0, 0}, {2, 2, 1, 1, 6, 0, 0, 0, 0}, {3, 3, 1, 1, 6, 0, 0, 0, 0}, {4, 4, 1, 1, 6, 0, 0, 0, 0}, {5, 5, 1, 1, 6, 0, 0, 0, 0}, {6, 6, 1, 1, 6, 0, 0, 0, 0}, {7, 7, 1, 1, 6, 0, 0, 0, 0}, {8, 8, 1, 1, 6, 0, 0, 0, 0}, {9, 9, 1, 1, 6, 0, 0, 0, 0}, {11, 11, 1, 1, 6, 0, 0, 0, 0}, {12, 12, 1, 1, 6, 0, 0, 0, 0}, {(byte)Config.SPLASH_SOUND_ID, 0, 1, 1, 6, 0, 0, 0, (byte)(Config.SPLASH_INTERRUPTS_SOUNDS ? 1 : 0)}};
   Object[] b;
   private int c;
   private int d;

   public SoundManager() {
      this.b = new Object[this.a.length];

      for(int var1 = 0; var1 < this.a.length; ++var1) {
         if (this.a[var1][2] == 1) {
            this.F(var1);
         }
      }

   }

   public void A(int var1) {
      if (StackAttack.o[1] > 0) {
         this.c = this.H(var1);
         if (this.c >= 0) {
            for(int var2 = 0; var2 < this.b.length; ++var2) {
               if (this.a[var2][8] < this.a[this.c][8]) {
                  this.B(var2);
               }
            }

            if (this.a[this.c][7] == 1) {
               (new SoundStartThread(this)).start();
            } else if (this.a[this.c][2] == 1) {
               this.G(this.c);
            } else {
               this.F(this.c);
               this.G(this.c);
            }

         }
      }
   }

   public void B(int var1) {
      var1 = this.H(var1);
      if (var1 >= 0) {
         this.E(var1);
      }
   }

   public void C(int var1) {
      this.D(var1);
   }

   private void D(int var1) {
   }

   private void E(int var1) {
      switch (this.a[var1][4]) {
         case 6:
         case 7:
         case 10:
            if (this.b[var1] != null) {
               Player var3 = (Player)this.b[var1];

               try {
                  var3.stop();
                  var3.setMediaTime(0L);
               } catch (Exception var2) {
               }
            }
         default:
      }
   }

   private void F(int var1) {
      if (this.b[var1] == null) {
         String var2 = null;
         String var3 = null;
         switch (this.a[var1][4]) {
            case 6:
               var2 = ".mid";
               var3 = "audio/midi";
               break;
            case 7:
               var2 = ".iml";
               var3 = "audio/imelody";
               break;
            case 10:
               var2 = ".amr";
               var3 = "audio/amr";
         }

         if (this.b[var1] == null && var2 != null && var3 != null) {
            String var6 = this.a[var1][0] == Config.SPLASH_SOUND_ID ? Config.SPLASH_FILE : "/s/" + this.a[var1][1] + var2;
            InputStream var5 = this.getClass().getResourceAsStream(var6);

            try {
               this.b[var1] = Manager.createPlayer(var5, var3);
               if (this.b[var1] != null) {
                  ((Player)this.b[var1]).prefetch();
               }
            } catch (Exception var4) {
            }

         }
      }
   }

   private void G(int var1) {
      switch (this.a[var1][4]) {
         case 6:
         case 7:
         case 10:
            if (this.b[var1] != null) {
               Player var3 = (Player)this.b[var1];
               if (var3.getState() == 300 && (this.b[this.d] == null || ((Player)this.b[this.d]).getState() != 400)) {
                  if (this.a[var1][5] < 0) {
                     var3.setLoopCount(-1);
                  } else {
                     var3.setLoopCount(this.a[var1][5] + 1);
                  }

                  try {
                     try {
                        var3.setMediaTime(0L);
                     } catch (Exception var4) {
                     }

                     VolumeControl var2 = (VolumeControl)var3.getControl("VolumeControl");
                     var2.setLevel(StackAttack.o[1]);
                     var3.start();
                     this.d = var1;
                  } catch (Exception var5) {
                  }

                  if (this.a[var1][3] == 0) {
                     this.b[var1] = null;
                  }
               }
            }
         default:
      }
   }

   private int H(int var1) {
      for(int var2 = 0; var2 < this.a.length; ++var2) {
         if (this.a[var2][0] == var1) {
            return var2;
         }
      }

      return -1;
   }

   // $FF: synthetic method
   static byte[][] A(SoundManager var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static int B(SoundManager var0) {
      return var0.c;
   }

   // $FF: synthetic method
   static void A(SoundManager var0, int var1) {
      var0.G(var1);
   }

   // $FF: synthetic method
   static void B(SoundManager var0, int var1) {
      var0.F(var1);
   }
}

class SoundStartThread extends Thread {
   // $FF: synthetic field
   private final SoundManager a;

   SoundStartThread(SoundManager var1) {
      this.a = var1;
   }

   public void run() {
      if (SoundManager.A(this.a)[SoundManager.B(this.a)][2] == 1) {
         SoundManager.A(this.a, SoundManager.B(this.a));
      } else {
         SoundManager.B(this.a, SoundManager.B(this.a));
         SoundManager.A(this.a, SoundManager.B(this.a));
      }

   }
}
