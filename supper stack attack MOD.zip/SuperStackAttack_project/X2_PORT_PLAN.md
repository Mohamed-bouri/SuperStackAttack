# 2x port (480x640): plan and status

The game is built for 240x320. Facts measured from the code (grep counts are approximate):

* Board geometry is clean: every box, player and explosion is drawn at `va + (col*8 - xOffset) * 3` / `wa - ((row+1)*8 - yOffset) * 3`.
  Game logic runs in units of 8 per cell; the literal `3` makes a cell 24 px (`cellSize = 24`). Logic does not depend on pixels.
* Frame sizes are not stored anywhere: a sprite sheet's frame = image size / grid (grid counts are in the code), so 2x art adapts by itself.
* Almost everything is drawn through `SpriteEngine` (only 4 `drawImage`, 7 `drawString`, 13 `fillRect` calls in the whole game).
* Pixel positions that DO need scaling: about 45 lines mentioning 240/320, about 27 sprite x/y literal assignments (HUD, score digits,
  bars), the HUD routine `R()`, 35 `Spacer(...)` calls in the LCDUI menus, 1 `Font.getFont`, the raw RGB overlay buffers (`eb`, `cb`, `db`)
  and the 3D screens (charsel / wait).
* The 3D models load `blue.png red.png yellow.png box_black.png rotating_plate.png textur_02.png` by name, so those scale by replacing the PNGs
  (power-of-two sizes are kept: 32 -> 64, 64 -> 128).

## Phases

| # | What | Status |
|---|------|--------|
| 1 | 2x art tree `art_x2/` (named, ready to edit) + builder to `res_x2/` + 32-bit pack size table in the loader (the 2x background is 73 KB, the old limit was 32 KB) + safe `skip()` | done, loader tested on 1x and 2x packs |
| 2 | `Config.SCALE`: board and entity math (`* 3` -> `* 3 * SCALE`, `-24`, `va`, `wa`, `sa`, `ta`), screen constants 240/320 | next |
| 3 | HUD and numbers (`R()` and the sprite x/y literals), background tiling | |
| 4 | Menus: `Spacer` sizes and font choice | |
| 5 | 3D screens and RGB overlay buffers | |
| 6 | Test at 480x640 (J2ME Loader or KEmulator with the screen set to 480x640), then tune | |

Until phase 2 is done, `res_x2` gives a wrongly laid out game: the art is doubled but the code still places it for 240x320.
Keep using `res/` for the playable 1x build.

## Quick alternative with no code change

Emulators can scale the 240x320 game up (nearest or bilinear filter). That gives a bigger window but not new detail.
The phase 2 to 5 work is what lets your hand-made 2x art show up as real extra detail.

## Art rules for 2x

* Keep every image's number `NN` and the 2x size in `list.txt` (a sprite sheet must stay exactly twice as wide and tall).
* Indexed PNG with transparency keeps files small; full-colour PNG also works.
* Photos/backgrounds are JPEG; any size is fine now (the pack switches to 32-bit sizes automatically).
