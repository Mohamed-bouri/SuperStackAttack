#!/usr/bin/env python3
"""
artx2.py - make and build the 2x (480x640) art set.

  python3 tools/artx2.py upscale            # art/ (1x sources) + res/ loose images  ->  art_x2/   (named, 2x, ready to edit)
  python3 tools/artx2.py build              # art_x2/ + non-image files of res/       ->  res_x2/   (runtime tree, packs rebuilt)
  options:  --method scale2x|nearest|lanczos   (default: scale2x for pixel art, lanczos for photos/JPEG)

art_x2/ layout (edit these files, keep each image's index number NN and its 2x size):
  art_x2/default/NN_name.png   images of res/default/i.p      (boxes, bombs, power-ups, workers, explosions, HUD, backgrounds)
  art_x2/shared/NN_name.png    images of res/i.p              (logos, digit fonts, icons, panels)
  art_x2/loose/...             loose files: skin textures (default/), 3D textures, splash, about image
Names after NN_ are free labels; only the number and extension matter to the packer.
"""
import os, re, sys, struct, shutil, io
import numpy as np
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import ipack

DEFAULT_NAMES = {0:'arrow_down_yellow',1:'bg_dock_large',2:'bomb_grey',3:'bomb_red',4:'bomb_green',5:'bomb_blue',6:'bomb_yellow',
 7:'bombs_color_strip',8:'hud_head_blue',9:'hud_head_blue_dead',10:'hud_head_green',11:'hud_head_green_dead',
 12:'worker_blue_sheet',13:'worker_green_sheet',14:'worker_red_sheet',15:'arrow_lift_sheet',
 16:'box_grey',17:'box_red',18:'box_green',19:'box_blue',20:'box_yellow',21:'boxes_color_strip',
 22:'explosion_grey',23:'explosion_red',24:'explosion_green',25:'explosion_yellow',26:'explosion_blue',
 27:'hud_head_yellow',28:'hud_head_yellow_dead',29:'hud_icon_29',30:'hud_head_green2',31:'hud_head_green2_dead',32:'hud_head_red',33:'hud_head_red_dead',
 34:'box_steel_crate',35:'effect_strip_lines',36:'powerup_type13',37:'powerup_type14',38:'powerup_type15',39:'powerup_type16',40:'powerup_type17',41:'powerup_type18',
 42:'bg_dock_small',43:'bar_vertical_a',44:'bar_vertical_b'}
SHARED_NAMES = {0:'icon_cross',1:'icon_check',2:'icon_zoom_a',3:'icon_zoom_b',4:'icon_small_a',5:'icon_small_b',6:'icon_small_c',7:'icon_small_d',
 8:'camera_sheet',9:'font_digits_small',10:'logo_handygames',11:'hourglass_sheet',12:'panel_white_large',13:'icon_heart',14:'panel_white_small',
 15:'font_digits_large',16:'logo_siemens'}
# loose files: (relative path in res/, action)   action: 'x2' = upscale, 'keep' = copy unchanged
LOOSE = [('default/0portrait_blue.png','x2'),('default/0portrait_grn.png','x2'),('default/0portrait_red.png','x2'),
 ('default/1portrait_blue.png','x2'),('default/1portrait_grn.png','x2'),('default/1portrait_red.png','x2'),
 ('default/blue.png','x2'),('default/red.png','x2'),('default/yellow.png','x2'),
 ('blue.png','x2'),('red.png','x2'),('yellow.png','x2'),('box_black.png','x2'),('rotating_plate.png','x2'),
 ('r.png','x2'),('m.gif','x2'),('s.jpg','x2'),('icon.png','keep'),('textur_02.png','keep')]

def scale2x_idx(a):
    """Scale2x/EPX on a 2D array of comparable values (indices or packed RGBA ints)."""
    h, w = a.shape; p = np.pad(a, 1, mode='edge')
    A = p[0:h, 1:w+1]; B = p[1:h+1, 2:w+2]; C = p[1:h+1, 0:w]; D = p[2:h+2, 1:w+1]; P = a
    o = np.empty((h*2, w*2), dtype=a.dtype)
    o[0::2, 0::2] = np.where((C == A) & (C != D) & (A != B), A, P)
    o[0::2, 1::2] = np.where((A == B) & (A != C) & (B != D), B, P)
    o[1::2, 0::2] = np.where((D == C) & (D != B) & (C != A), C, P)
    o[1::2, 1::2] = np.where((B == D) & (B != A) & (D != C), D, P)
    return o

def upscale_image(path, out, method):
    im = Image.open(path); is_jpeg = im.format == 'JPEG'
    m = method or ('lanczos' if is_jpeg else 'scale2x')
    w, h = im.size
    if m == 'lanczos' or (is_jpeg and method is None):
        r = im.convert('RGB').resize((w*2, h*2), Image.LANCZOS); r.save(out, quality=90, optimize=True); return
    if m == 'nearest':
        r = im.resize((w*2, h*2), Image.NEAREST)
    else:
        if im.mode == 'P':
            r = Image.fromarray(scale2x_idx(np.array(im)), 'P'); r.putpalette(im.getpalette())
            if 'transparency' in im.info: r.info['transparency'] = im.info['transparency']
        else:
            rgba = np.array(im.convert('RGBA')); packed = rgba.view(np.uint32).reshape(rgba.shape[:2])
            r = Image.fromarray(scale2x_idx(packed).view(np.uint8).reshape(h*2, w*2, 4), 'RGBA')
    kw = {'optimize': True}
    if im.mode == 'P' and 'transparency' in im.info: kw['transparency'] = im.info['transparency']
    if out.lower().endswith('.gif'): r.save(out, **({'transparency': im.info['transparency']} if 'transparency' in im.info else {}))
    else: r.save(out, **kw)

def upscale(method):
    out = os.path.join(ROOT, 'art_x2'); shutil.rmtree(out, ignore_errors=True)
    rows = []
    for pack, names, src in (('default', DEFAULT_NAMES, 'art/default'), ('shared', SHARED_NAMES, 'art/shared')):
        os.makedirs(f'{out}/{pack}', exist_ok=True)
        for f in sorted(os.listdir(os.path.join(ROOT, src))):
            m = re.fullmatch(r'(\d+)\.(png|jpg)', f)
            if not m: continue
            i = int(m.group(1)); name = f'{i:02d}_{names.get(i, "image")}.{m.group(2)}'
            s = os.path.join(ROOT, src, f); d = f'{out}/{pack}/{name}'
            upscale_image(s, d, method)
            rows.append((pack, name, Image.open(s).size, Image.open(d).size, os.path.getsize(s), os.path.getsize(d)))
    for rel, act in LOOSE:
        s = os.path.join(ROOT, 'res', rel); d = os.path.join(out, 'loose', rel); os.makedirs(os.path.dirname(d), exist_ok=True)
        if act == 'x2': upscale_image(s, d, method)
        else: shutil.copy(s, d)
        rows.append(('loose', rel + ('' if act == 'x2' else '  (kept 1x)'), Image.open(s).size, Image.open(d).size, os.path.getsize(s), os.path.getsize(d)))
    with open(f'{out}/list.txt', 'w') as f:
        f.write('%-8s %-34s %-10s %-10s %8s %8s\n' % ('group', 'file', '1x', '2x', 'bytes1x', 'bytes2x'))
        for r in rows: f.write('%-8s %-34s %-10s %-10s %8d %8d\n' % (r[0], r[1], '%dx%d' % r[2], '%dx%d' % r[3], r[4], r[5]))
    big = [r for r in rows if r[0] != 'loose' and r[5] > 32767]
    print('upscaled %d images -> art_x2/' % len(rows))
    if big: print('NOTE: %d pack image(s) exceed 32767 bytes, the pack uses the 32-bit size table: %s' % (len(big), ', '.join(r[1] for r in big)))

def build():
    art = os.path.join(ROOT, 'art_x2'); dst = os.path.join(ROOT, 'res_x2'); shutil.rmtree(dst, ignore_errors=True)
    base = os.path.join(ROOT, 'res')
    for dp, dn, fn in os.walk(base):                     # copy everything that is not an image
        rel = os.path.relpath(dp, base); os.makedirs(os.path.join(dst, rel), exist_ok=True)
        for f in fn:
            full = os.path.join(dp, f)
            if f.lower().endswith(('.png', '.gif', '.jpg')) or f == 'i.p': continue
            shutil.copy(full, os.path.join(dst, rel, f))
    for pack, out in (('default', 'default/i.p'), ('shared', 'i.p')):
        ipack.pack(os.path.join(art, pack), os.path.join(dst, out))
    for dp, dn, fn in os.walk(os.path.join(art, 'loose')):
        rel = os.path.relpath(dp, os.path.join(art, 'loose'))
        for f in fn:
            os.makedirs(os.path.join(dst, rel), exist_ok=True); shutil.copy(os.path.join(dp, f), os.path.join(dst, rel, f))
    print('built res_x2/')

if __name__ == '__main__':
    a = sys.argv[1:]; method = a[a.index('--method')+1] if '--method' in a else None
    if a and a[0] == 'upscale': upscale(method)
    elif a and a[0] == 'build': build()
    else: print(__doc__)
