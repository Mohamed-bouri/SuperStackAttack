# Super Stack Attack (J2ME) - source project

Cleaned-up, annotated source of the game with the bug fixes and the new splash-sound option.

## Layout

```
src/StackAttack.java   MIDlet + all game logic (Config, StackAttack, StateThread)
src/Engine.java        canvas/frame loop, sprite engine, sprite sheet, sprite
src/Audio.java         sound table, MIDI players, async sound start
src/Network.java       Bluetooth 2-player, SMS, HTTP
art/                   unpacked source images of the two i.p packs (edit these, then repack with tools/ipack.py)
res/                   everything that goes into the jar (images, .p data, lang/, s/*.mid, splash.mid)
lib/j2me-stubs.jar     J2ME API signatures to compile against (not packaged into the game)
MANIFEST.MF            MIDlet descriptor
build.sh / build.bat   one-command build
dist/                  prebuilt jars
```

## Installing next to the original game

The phone identifies an app by `MIDlet-Name` + `MIDlet-Vendor` in `MANIFEST.MF`. This project uses `Super Stack Attack MOD` / `SSA Mod` (menu label `Stack Attack MOD`, version 2.5.1), so it installs as a separate app and does not replace the original. Change those lines to rename it again. It keeps its own save data and high scores, because each installed app has its own storage.

## Build

1. Install a JDK (8 or newer).
2. Run `./build.sh` (Windows: `build.bat`). Output: `dist/SuperStackAttack_unpreverified.jar`.
3. For real phones (CLDC preverification) also download ProGuard 7.x and run
   `PROGUARD_JAR=/path/to/proguard.jar ./build.sh` (Windows: `set PROGUARD_JAR=...` first).
   Output: `dist/SuperStackAttack.jar`.

IDE: open the folder in IntelliJ IDEA (or Eclipse / VS Code), mark `src` as sources, add `lib/j2me-stubs.jar` as a library. Use `--release 8` or lower.
Test on KEmulator nnmod (PC), J2ME Loader (Android) or FreeJ2ME.

## Editing the art (res/default/i.p and res/i.p)

These are image packs, not single pictures: a size table followed by 45 (default) or 17 (shared) PNG/JPEG images.

```
python3 tools/ipack.py unpack res/default/i.p art/default    # -> 00.png ... 44.png, list.txt
(edit the PNGs in any image editor, keep the same file names and image sizes)
python3 tools/ipack.py pack art/default res/default/i.p
./build.sh
```
Keep each image's width and height (sprite sheets are cut into fixed frames), stay under 32767 bytes per image, and prefer 8-bit indexed PNG with transparency for old phones.

## Splash sound option

Edit the `Config` class at the top of `src/StackAttack.java`, then rebuild:

| Option | Default | Meaning |
|---|---|---|
| `SPLASH_ON_ROW_CLEAR` | true | play the splash when a whole bottom row is cleared |
| `SPLASH_ON_COLOR_MATCH` | true | play the splash when 3+ same-colour boxes are destroyed |
| `SPLASH_FILE` | `/splash.mid` | resource path of the sound (file is `res/splash.mid`) |
| `SPLASH_SOUND_ID` | 13 | slot in the sound table (original sounds use 0..12) |
| `SPLASH_INTERRUPTS_SOUNDS` | true | cut other sounds so the splash is always heard |

`res/splash.mid` is a short placeholder (0.75 s, splash cymbal plus sparkle) generated for this project. Replace it with your own MIDI under the same name. The splash respects the game's sound volume setting (silent when sound is off), and a missing file is ignored safely.

## Bug fixes (search the source for `FIX n`)

1. `executeQueuedStep`: second jump step moved into occupied cells, orphaning boxes (boxes piling on the head without hitting him).
2. `respawnPlayer`: leaked one explosion sprite per death.
3. `movePlayer` (head-butt): explosion had no sprite (probable cause of empty boxes).
4. `respawnPlayer`: full-column branch freed the wrong cell.
5. `collectNeighbours`: read past the top row.

## Name map (obfuscated -> readable)

Only names that could be renamed with certainty were renamed. Anything still short (`A`, `B`, `var13`) is a decompiler name that is ambiguous (overloads) or not understood yet. Strings such as the Bluetooth service name `StackAttack4` were left unchanged on purpose, so multiplayer stays compatible with the original game.

**Classes:** `A` -> `SoundStartThread`, `B` -> `BluetoothLink`, `C` -> `BluetoothPoller`, `D` -> `GameCanvasLoop`, `E` -> `SpriteSheet`, `F` -> `SpriteState`, `G` -> `SoundManager`, `H` -> `StateThread`, `I` -> `SmsMessenger`, `J` -> `SpriteEngine`, `K` -> `HttpClient`, `StackAttack4` -> `StackAttack`

**Main-class fields:** `ia` -> `entities`, `ja` -> `grid`, `ka` -> `grid2`, `la` -> `marks`, `oA` -> `players`, `pA` -> `planes`, `qA` -> `maxPlanes`, `rA` -> `stats`, `qa` -> `gridCols`, `ra` -> `gridRows`, `pa` -> `cellSize`, `gb` -> `random`, `bb` -> `sprites`, `ma` -> `matchPending`

**Main-class methods (name/argument count):** `Z`/1 -> `settleEntity`, `AA`/1 -> `checkEntityCollisions`, `BA`/1 -> `applyGravity`, `I`/2 -> `resolveCollision`, `J`/2 -> `collectPowerUp`, `DA`/1 -> `usePowerUp`, `EA`/1 -> `powerAreaBlast`, `FA`/1 -> `powerColorBlast`, `IA`/1 -> `matchColorGroups`, `KA`/1 -> `allocEntity`, `LA`/1 -> `freeEntity`, `JA`/1 -> `createExplosionSprite`, `H`/2 -> `respawnPlayer`, `G`/2 -> `movePlayerSideways`, `D`/2 -> `movePlayer`, `F`/2 -> `movePlayerDiagonal`, `V`/1 -> `updatePlayer`, `W`/1 -> `processPlayerQueue`, `X`/1 -> `executePlayerCommand`, `Y`/1 -> `executeQueuedStep`, `Y`/0 -> `clearMarks`, `Z`/0 -> `checkRowClear`, `AA`/0 -> `explodeMarkedCells`, `BA`/0 -> `updatePlanes`, `N`/2 -> `addScore`, `L`/2 -> `floodFillGroup`, `S`/0 -> `tickGame`, `S`/1 -> `drawBox`, `T`/1 -> `drawExplosion`, `OA`/1 -> `playSoundEvent`, `A`/5 -> `collectNeighbours`, `E`/2 -> `cellsBelow`, `CA`/1 -> `playerOfEntity`

## Notes

- Game code was decompiled from the original jar, so some structure (large switch methods, `varN` locals) is still decompiler-shaped.
- `lib/j2me-stubs.jar` contains signatures generated from the Apache-2.0 licensed J2ME-Loader sources; it is only used to compile.
- Not tested on real hardware.
