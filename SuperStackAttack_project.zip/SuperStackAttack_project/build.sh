#!/bin/sh
# Builds dist/SuperStackAttack.jar from src/ + res/.
# (ProGuard reads paths relative to its config file, so absolute paths are written.)
# Needs: a JDK (8 or newer). Optional: ProGuard 7.x for CLDC preverification (needed by real phones):
#   PROGUARD_JAR=/path/to/proguard.jar ./build.sh
set -e
cd "$(dirname "$0")"
rm -rf build dist; mkdir -p build/classes build/stage/META-INF dist

javac -nowarn --release 8 -encoding UTF-8 -cp lib/j2me-stubs.jar -d build/classes src/*.java
cp -r res/* build/stage/
cp build/classes/*.class build/stage/
cp MANIFEST.MF build/stage/META-INF/
jar cfm dist/SuperStackAttack_unpreverified.jar build/stage/META-INF/MANIFEST.MF -C build/stage .
echo "built dist/SuperStackAttack_unpreverified.jar"

if [ -n "$PROGUARD_JAR" ]; then
  JH=$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")
  if [ -f "$JH/jmods/java.base.jmod" ]; then RT="$JH/jmods/java.base.jmod(!**.jar;!module-info.class)"; else RT="$JH/jre/lib/rt.jar"; fi
  cat > build/pg.conf <<PG
-injars $PWD/dist/SuperStackAttack_unpreverified.jar
-outjars $PWD/dist/SuperStackAttack.jar
-libraryjars $PWD/lib/j2me-stubs.jar
-libraryjars $RT
-microedition
-target 1.3
-dontshrink
-dontoptimize
-dontobfuscate
-ignorewarnings
-keep public class StackAttack
PG
  java -jar "$PROGUARD_JAR" @build/pg.conf
  echo "built dist/SuperStackAttack.jar (preverified)"
else
  echo "PROGUARD_JAR not set: skipped preverification (fine for most emulators, not for real phones)"
fi
