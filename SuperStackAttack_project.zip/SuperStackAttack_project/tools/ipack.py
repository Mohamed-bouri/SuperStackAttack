#!/usr/bin/env python3
"""
ipack.py - unpack / repack the game's image packs (res/i.p and res/default/i.p).

Format (big endian), as read by StackAttack.A(InputStream) and StackAttack.A(String,String,int):
    u16 count | count x u16 size | image 0 bytes | image 1 bytes | ...
Every image is PNG (or JPEG) and is loaded with Image.createImage().

  python3 tools/ipack.py unpack res/default/i.p art/default      -> art/default/00.png, 01.jpg, ... + list.txt
  python3 tools/ipack.py pack   art/default res/default/i.p      -> rebuilds the pack from the files in the folder

Rules enforced when packing:
  - files are named NN.png / NN.jpg (NN = index, must be 00..count-1, no gaps)
  - each image must be <= 32767 bytes (the loader reads sizes as signed shorts)
  - warns if an image's width/height differs from the original (sprite sheets are cut into fixed frames,
    so keep dimensions unless you also change the code)
Needs only Python 3 (Pillow is optional, used for the size warning).
"""
import os, re, struct, sys

def kind(b):
    if b[:4] == b'\x89PNG': return 'png'
    if b[:2] == b'\xff\xd8': return 'jpg'
    if b[:3] == b'GIF': return 'gif'
    return 'bin'

def dims(b):
    if b[:4] == b'\x89PNG': return struct.unpack('>II', b[16:24])
    if b[:2] == b'\xff\xd8':
        i = 2
        while i < len(b):
            if b[i] != 0xFF: i += 1; continue
            m = b[i+1]
            if m in (0xC0, 0xC1, 0xC2):
                h, w = struct.unpack('>HH', b[i+5:i+9]); return (w, h)
            i += 2 + struct.unpack('>H', b[i+2:i+4])[0]
    return None

def unpack(src, out):
    d = open(src, 'rb').read()
    n = struct.unpack('>H', d[:2])[0]
    sizes = struct.unpack('>%dH' % n, d[2:2+2*n]); off = 2 + 2*n
    assert off + sum(sizes) == len(d), 'size table does not match file length'
    os.makedirs(out, exist_ok=True); lines = []
    for i, sz in enumerate(sizes):
        b = d[off:off+sz]; off += sz
        k = kind(b); name = '%02d.%s' % (i, k)
        open(os.path.join(out, name), 'wb').write(b)
        wh = dims(b); lines.append('%02d  %-4s %6d bytes  %s' % (i, k, sz, ('%dx%d' % wh) if wh else ''))
    open(os.path.join(out, 'list.txt'), 'w').write('\n'.join(lines) + '\n')
    print('unpacked %d images to %s' % (n, out))

def pack(folder, dst):
    files = {}
    for f in os.listdir(folder):
        m = re.fullmatch(r'(\d+)\.(png|jpg|gif|bin)', f)
        if m: files[int(m.group(1))] = f
    n = len(files)
    assert n and sorted(files) == list(range(n)), 'files must be numbered 00..%02d with no gaps' % (n-1)
    blobs = [open(os.path.join(folder, files[i]), 'rb').read() for i in range(n)]
    for i, b in enumerate(blobs):
        assert len(b) <= 32767, '%s is %d bytes; the limit is 32767' % (files[i], len(b))
    lst = os.path.join(folder, 'list.txt')
    if os.path.exists(lst):
        for ln in open(lst):
            m = re.match(r'(\d+)\s+\S+\s+\d+ bytes\s+(\d+)x(\d+)', ln)
            if m and int(m.group(1)) < n and dims(blobs[int(m.group(1))]) not in (None, (int(m.group(2)), int(m.group(3)))):
                print('WARNING: %s is now %s, was %sx%s (frames are cut at fixed sizes)' % (files[int(m.group(1))], 'x'.join(map(str, dims(blobs[int(m.group(1))]))), m.group(2), m.group(3)))
    data = struct.pack('>H', n) + struct.pack('>%dH' % n, *[len(b) for b in blobs]) + b''.join(blobs)
    open(dst, 'wb').write(data); print('packed %d images -> %s (%d bytes)' % (n, dst, len(data)))

if __name__ == '__main__':
    if len(sys.argv) != 4 or sys.argv[1] not in ('unpack', 'pack'): print(__doc__); sys.exit(1)
    (unpack if sys.argv[1] == 'unpack' else pack)(sys.argv[2], sys.argv[3])
