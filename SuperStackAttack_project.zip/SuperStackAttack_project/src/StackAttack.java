import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;
import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Gauge;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.ImageItem;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.ItemCommandListener;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.Spacer;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;
import javax.microedition.m3g.AnimationTrack;
import javax.microedition.m3g.Appearance;
import javax.microedition.m3g.CompositingMode;
import javax.microedition.m3g.Graphics3D;
import javax.microedition.m3g.Image2D;
import javax.microedition.m3g.KeyframeSequence;
import javax.microedition.m3g.Loader;
import javax.microedition.m3g.Mesh;
import javax.microedition.m3g.Node;
import javax.microedition.m3g.Object3D;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.World;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

/**
 * Super Stack Attack: the MIDlet and all game logic.
 *  - Config      : user options (splash sound)
 *  - StackAttack : MIDlet entry point, menus, game rules, physics, input, rendering calls
 *  - StateThread : worker thread that performs game-state transitions (new game, load level, ...)
 */
/**
 * USER OPTIONS. Edit a value, rebuild (see README), done.
 */
final class Config {
   /** Play the splash sound when a whole bottom row is cleared. */
   static final boolean SPLASH_ON_ROW_CLEAR = true;
   /** Play the splash sound when 3+ same-colour boxes are destroyed. */
   static final boolean SPLASH_ON_COLOR_MATCH = true;
   /** Resource path of the splash sound inside the jar (file lives in res/). */
   static final String SPLASH_FILE = "/splash.mid";
   /** Sound id used for the splash in the sound table (ids 0..12 are the original sounds). */
   static final int SPLASH_SOUND_ID = 13;
   /** true: splash cuts off other sounds so it is always heard. false: it is skipped if another sound is playing. */
   static final boolean SPLASH_INTERRUPTS_SOUNDS = true;
}

public class StackAttack extends MIDlet implements CommandListener, ItemCommandListener {
   private int[] a = new int[]{49152032, 1025, 49152048, 1026, 49152064, 1027, 1554, 4, -15971515, 1028, -16480203, 1028, -16694011, 1028, -16138027, 1028, -16102843, 1028, -16676651, 1028, -16661259, 1028, -16646139, 1028, -15285275, 1028, 8194243, 4, 1491939, 1049604, 993, 91, -16777099, 91, 19779, 91, 1661012099, 1049691, 0, 4112, 0, 4147, 0, 4134, 3346, 39, -16400155, 39, -16400139, 39, -16400123, 39, -16400107, 39, -16400091, 39, 8194243, 39, 16842899, 1049639, 641, 53, 17416339, 1049653, 43794, 54, 8194243, 54, 639123, 1049654, 209, 52, 641219, 1076, 639123, 1049652, 209, 87, 264387, 1111, 262291, 1049687, 16914, 49, -15498075, 1073, -16005947, 49, 8194243, 49, 65683, 1049649, 18962, 65, -16579883, 65, -16185259, 65, 8194243, 65, 802963, 1049665, 18962, 50, 8194243, 50, 1278099, 1049650, 1905, 62, 819347, 1049662, 493763, 62, 1217, 63, -16775979, 63, 802963, 1049663, 772291, 63, 1185, 78, -16776011, 78, 772291, 78, 802963, 1049678, 2625, 41, 688275, 1048617, 833, 68, -16777099, 68, 838979, 68, 17451139, 1049668, 14098, 17, 8194243, 17, 262291, 1049617, 1281, 5, 65683, 1049605, 43538, 40, -3634411, 40, -1995995, 40, 8194243, 40, 16859283, 1049640, 833, 10, -16777099, 10, 118083, 10, 84099, 1049610, 36114, 6, -15823979, 6, -16495707, 6, -16203243, 1030, 985283, 6, 999571, 1048582, 2913, 64, 559731, 64, 17385571, 64, 2961, 47, 17074371, 47, 98451, 1049647, 20242, 7, -16071611, 1031, -16053323, 1031, -15990395, 1031, -16022811, 1031, -16088027, 1031, 8194243, 7, 65683, 1049607, 1089, 43, -16776107, 43, 114835, 1049643, 16914, 42, -15874907, 1066, -15858491, 1066, -15842171, 1066, -15825819, 1066, 8194243, 42, 114835, 1049642, 1185, 55, -16776011, 55, 688275, 1049655, 1153, 57, -16776043, 57, 688275, 1049657, 1217, 56, -16775979, 56, 688275, 1049656, 1121, 58, -16776075, 58, 688275, 1049658, 2993, 44, 114835, 1049644, 0, 4144, 737, 46, 114835, 1049646, 1, 8, 65683, 1049608, 0, 4107, 993, 12, -16777099, 12, 134467, 12, 1661143171, 1048588, 0, 4109, 3169, 79, 868499, 1048655, 3169, 83, 884883, 1048659, 29458, 27, 1664368787, 1048603, 3770211, 27, 0, 4116, 0, 4170, 0, 4177, 0, 4178, 33554, 77, -15564411, 1101, -11746907, 77, 442515, 1049677, 33554, 18, -13499083, 18, -13417083, 18, 65683, 1049618, 1361, 19, 197956, 19, 3295427, 19, 1661239443, 1049619, 657, 21, 198724, 21, 3377347, 21, 1661239443, 1049621, 0, 4118, 2641, 23, -16774843, 23, 65683, 1049623, 22546, 24, 1661288595, 1049624, 0, 4121, 2641, 26, -16774987, 26, 1661012099, 1049626, 3378499, 26, 16914, 85, -15645595, 1109, -11647803, 85, -15596411, 1109, 17088659, 1049685, 1121, 69, -16776075, 69, 934035, 1048645, 1149123, 1093, 1217, 71, -16775979, 71, 934035, 1048647, 1329347, 1095, 1153, 72, -16776043, 72, 934035, 1048648, 1411267, 1096, 1121, 88, -16776075, 88, 3358867, 1048664, 444611, 1112, 1217, 89, -16775979, 89, 3358867, 1048665, 1345731, 1113, 1153, 90, -16776043, 90, 3358867, 1048666, 1345731, 1114, 14098, 86, -11664507, 86, -11663355, 86, -11664539, 86, 98451, 1048662, 30482, 70, 1661042835, 1048646, 1905, 73, 3442883, 73, 1147027, 1049673, 14098, 75, -16546939, 75, -16545787, 75, -16546971, 75, 17678483, 1048651, 2913, 76, 5048947, 76, 21842019, 76, 17694867, 1048652, 8466, 35, 98451, 1049635, 8466, 36, -16170635, 1060, -12811643, 36, 573587, 1049636, 369, 37, 1639028, 37, 3983555, 37, 1661517971, 1049637, 30226, 29, -16266507, 1053, -16282907, 1053, 1664794771, 1048605, 1889, 31, 1639316, 31, 3820195, 31, 1661419667, 1049631, 1889, 32, 3883155, 1048608, 1664827539, 1048608, 8466, 30, 1661419667, 1049630, 45842, 33, 1664748195, 33, 3866771, 1048609, 45842, 34, 1664748195, 34, 3866771, 1048610, 43794, 900, 852115, 1049476, 2737, 902, 31541443, 1049478, 852115, 1049478, 2737, 903, 25133092, 1927, 31541443, 1049479, 852115, 1049479, 2737, 904, 31541443, 1049480, 852115, 1049480, 2737, 905, 14765379, 905, 1661798531, 1049481, 2737, 906, 17631427, 1049482, 852115, 1049482, 2737, 800, 29903043, 1049376, 82067, 1050400, 2737, 801, 29903043, 1049377, 82067, 1050401, 2737, 806, -16774843, 806, 16859283, 1050406, 82067, 1050406, 2737, 802, 29968579, 1049378, 82067, 1050402, 3201, 803, 17533123, 1049379, 82067, 1050403, 2737, 804, -16776507, 804, 17533123, 1049380, 82067, 1050404, 2737, 805, -16774747, 805, 29886659, 1050405, 13107347, 1050405};
   private int b;
   private String[][] c;
   private Vector d;
   private Vector e;
   private int f;
   public static byte[] g;
   public boolean h;
   public GameCanvasLoop i;
   private String j;
   private String k;
   private boolean l;
   private int m;
   private int n;
   public static byte[] o;
   public static byte[] p;
   public static SoundManager q;
   private Displayable r;
   private List s;
   private Vector t;
   private Form u;
   private Vector v;
   int w = 0;
   BluetoothLink x;
   int y = 0;
   int z = -1;
   int aa = -1;
   boolean ba = false;
   boolean ca = false;
   boolean da = false;
   boolean ea = false;
   boolean fa = false;
   byte ga = 0;
   byte ha = 1;
   /** Entity table: one row per live object (box, player, explosion). Columns: [0]=type (0 = free slot, 1 = player, 3..18 = boxes, 19..34 = explosion / death animation), [1]=column, [2]=row, [3]=x pixel offset, [4]=y pixel offset (smooth movement), [7]=type before exploding, [8]=explosion sprite slot, [9]=changed flag. Size = gridCols * gridRows + 2. */
   int[][] entities = (int[][])null;
   /** Board grid [column][row] -> index into entities, or -1 when the cell is empty. Row 0 is the floor. */
   int[][] grid;
   /** Second board layer that holds player 2 (2-player mode), so both players can be tracked independently. */
   int[][] grid2;
   /** Scratch grid used by match detection: 1 = candidate, 3 = part of a group of 3+, 99 = destroy this cell. */
   byte[][] marks;
   /** Set when a box lands; next tick runs the colour-match and row-clear checks. */
   boolean matchPending = false;
   Vector na = new Vector();
   String oa = new String("");
   /** Cell size in pixels (24). */
   int cellSize = 24;
   /** Board width in cells (10 in single player). */
   int gridCols = 0;
   /** Board height in cells (10 in single player). */
   int gridRows = 0;
   int sa = 0;
   int ta = 0;
   int ua = 10;
   int va = 12;
   int wa = 312;
   int xa = 0;
   int ya = 0;
   int za = 0;
   int aA = 0;
   boolean bA = false;
   long cA = 0L;
   long dA = 0L;
   long eA = 0L;
   long fA = 0L;
   Font gA = Font.getFont(0, 1, 0);
   long hA = 0L;
   long iA = 0L;
   int[][] jA = new int[][]{{48, 0, 4, 0}, {49, 5, 0, 0}, {50, 4, 0, 0}, {51, 6, 0, 0}, {52, 2, 0, 0}, {53, 10, 0, 0}, {54, 3, 0, 0}, {55, 0, 0, 0}, {56, 0, 0, 0}, {57, 0, 0, 0}, {42, 0, 0, 0}, {35, 0, 0, 0}, {-10, 0, 0, 0}, {-11, 0, 0, 0}, {-6, 0, 0, 0}, {-7, 0, 0, 0}, {-1, 4, 4, 0}, {-2, 0, 4, 0}, {-3, 2, 4, 0}, {-4, 3, 4, 0}, {-5, 10, 4, 0}};
   int[][] kA = new int[][]{{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {52, 21, 0, 0}, {53, 22, 0, 0}, {54, 23, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {-3, 21, 4, 0}, {-4, 23, 4, 0}, {-5, 22, 4, 0}};
   int[] lA = new int[]{205, 206, 207, 208, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127};
   int[] mA = new int[]{0, 0, 120, 121, 122, 123, 124};
   int nA = 0;
   /** Per-player state [player][field]: [0]=entity index, [1]=character, [2]=lives, [3]=score, [4]=held power-up type, [5]=power-up timer, [7]=pending command, [10]=state (12 = dead), [11..14]=queued move steps, [17]=key bit mask. */
   int[][] players = new int[2][20];
   /** Dropper planes: planes[i] = {x position, direction (0 idle, 1 left, 2 right), box type carried, target column}. */
   int[][] planes = new int[12][4];
   /** Max simultaneous dropper planes = drop rate. Starts at 2/5/9/9 by difficulty, +1 per cleared row, capped at 12. */
   int maxPlanes = 0;
   /** Statistics counters: stats[0][1] = rows cleared, stats[0][n] = colour groups of size n destroyed. */
   int[][] stats = new int[2][10];
   int[] sA = new int[10];
   int[] tA = new int[9];
   int[] uA = new int[2];
   int[] vA = new int[8];
   int[] wA = new int[8];
   int xA = 0;
   int yA = 0;
   int zA = 0;
   int[][] ab = new int[][]{{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {1, 0, 0}, {2, 0, 0}, {3, 0, 0}, {4, 0, 0}, {5, 0, 0}, {6, 0, 0}, {7, 0, 0}, {8, 0, 0}, {9, 0, 0}, {10, 0, 0}, {11, 0, 0}, {12, 0, 0}, {13, 0, 0}, {14, 0, 0}, {15, 0, 0}, {16, 0, 0}, {0, 0, 0}, {0, 0, 0}};
   /** SpriteEngine: renderer plus the pool of sprite slots. */
   SpriteEngine sprites = new SpriteEngine(this);
   int cb = 48;
   int db = 30;
   int[] eb;
   int fb;
   /** Random number generator for drops. */
   private Random random;
   private int hb;
   int ib;
   int jb;
   int kb;
   int lb;
   int mb;
   int nb;
   int ob;
   int pb;
   public boolean[] qb;
   boolean rb;
   private Vector sb;
   World tb;
   Node ub;
   Texture2D[][] vb;
   int wb;
   int xb;
   int yb;
   int zb;
   long aB;
   String[] bB;
   int cB;
   World dB;
   Node eB;
   Node fB;
   Node gB;
   Graphics3D hB;
   private boolean iB;
   int jB;
   public SmsMessenger kB;
   private int lB;
   String[] mB;
   private HttpClient nB;
   private int oB;
   public String pB;
   public String[] qB;
   boolean rB;
   InputStream sB;
   String tB;
   short[] uB;
   int vB;
   int wB;
   int xB;
   int[] yB;
   boolean zB;
   int ac;
   boolean bc;
   int cc;

   private boolean A(int var1) {
      RecordStore var4 = null;
      try {
         var4 = RecordStore.openRecordStore("ByteStorage" + var1, false);
      } catch (Exception var3) {
         return false;
      }

      if (var4 != null) {
         try {
            var4.closeRecordStore();
         } catch (Exception var2) {
         }
      }

      return true;
   }

   private void B(int var1) {
      if (this.A(var1)) {
         try {
            RecordStore var3 = RecordStore.openRecordStore("ByteStorage" + var1, false);
            if (var3.getNumRecords() == 1) {
               var3.deleteRecord(1);
            }

            var3.closeRecordStore();
            RecordStore.deleteRecordStore("ByteStorage" + var1);
         } catch (Exception var2) {
         }

      }
   }

   private byte[] C(int var1) {
      RecordStore var4 = null;
      byte[] var5;

      try {
         var4 = RecordStore.openRecordStore("ByteStorage" + var1, false);
         var5 = var4.getRecord(1);
      } catch (Exception var3) {
         var5 = new byte[]{0};
      }

      if (var4 != null) {
         try {
            var4.closeRecordStore();
         } catch (Exception var2) {
         }
      }

      return var5;
   }

   private void A(byte[] var1, int var2) {
      RecordStore var4 = null;
      boolean var3 = false;

      try {
         var4 = RecordStore.openRecordStore("ByteStorage" + var2, true);
         if (var4.getNumRecords() < 1) {
            var4.addRecord(var1, 0, 1);
            var3 = true;
         }

         if (var4.getSizeAvailable() >= var1.length * 2) {
            var4.setRecord(1, var1, 0, var1.length);
            var3 = false;
         }
      } catch (Exception var6) {
         String var7 = ((Throwable)var6).getMessage();
         if (var7.compareTo("javax/microeditions/rms/RecordStoreNotFoundException") == 0) {
         }
      }

      if (var4 != null) {
         try {
            var4.closeRecordStore();
            if (var3) {
               this.B(var2);
            }
         } catch (Exception var5) {
         }
      }

   }

   private boolean[] A(int var1, int var2, boolean var3) {
      boolean[] var7 = new boolean[var2];

      try {
         RecordStore var6 = RecordStore.openRecordStore("BooleanStorage" + var1, false);
         byte[] var5 = var6.getRecord(1);

         for(int var9 = 0; var9 < var2; ++var9) {
            if (var5[var9] == 0) {
               var7[var9] = true;
            }
         }

         var6.closeRecordStore();
      } catch (Exception var8) {
         for(int var4 = 0; var4 < var2; ++var4) {
            var7[var4] = var3;
         }

         this.A(var7, var1);
      }

      return var7;
   }

   private void A(boolean[] var1, int var2) {
      byte[] var3 = new byte[var1.length];

      for(int var5 = 0; var5 < var1.length; ++var5) {
         var3[var5] = (byte)(var1[var5] ? 0 : 1);
      }

      try {
         RecordStore var6 = RecordStore.openRecordStore("BooleanStorage" + var2, true);

         while(var6.getNumRecords() < 1) {
            var6.addRecord(var3, 0, 1);
         }

         var6.setRecord(1, var3, 0, var3.length);
         var6.closeRecordStore();
      } catch (Exception var4) {
      }

   }

   public String A() {
      byte[] var2 = null;

      try {
         RecordStore var1 = RecordStore.openRecordStore("RA", true);
         if (var1.getNumRecords() == 0) {
            var1.closeRecordStore();
            return "";
         }

         var2 = var1.getRecord(1);
         var1.closeRecordStore();
      } catch (Exception var3) {
      }

      return this.A(var2);
   }

   public String A(byte[] var1) {
      if (var1 != null && var1.length > 0) {
         char[] var3 = new char[var1.length / 2];

         for(int var2 = 0; var2 < var3.length; ++var2) {
            char var4 = (char)((var1[var2 * 2] + 256) % 256);
            var4 = (char)(var4 << 8);
            var4 = (char)(var4 | (var1[var2 * 2 + 1] + 256) % 256);
            var3[var2] = var4;
         }

         return new String(var3);
      } else {
         return null;
      }
   }

   public void A(String var1) {
      byte[] var3 = null;
      if (var1 != null) {
         var3 = this.B(var1);
      }

      if (var3 != null) {
         try {
            RecordStore var5 = RecordStore.openRecordStore("RA", true);
            if (var5.getNumRecords() == 0) {
               var5.addRecord(var3, 0, var3.length);
            } else {
               var5.setRecord(1, var3, 0, var3.length);
            }

            var5.closeRecordStore();
         } catch (Exception var4) {
         }

      }
   }

   public byte[] B(String var1) {
      if (var1 == null) {
         return new byte[0];
      } else {
         char[] var2 = var1.toCharArray();
         byte[] var4 = new byte[var2.length * 2];

         for(int var3 = 0; var3 < var2.length; ++var3) {
            var4[2 * var3] = (byte)(var2[var3] >> 8 & 255);
            var4[2 * var3 + 1] = (byte)(var2[var3] & 255);
         }

         return var4;
      }
   }

   private Vector D(int var1) {
      Vector var5 = new Vector();

      try {
         RecordStore var3 = RecordStore.openRecordStore("SuperStackAttackStrings" + var1, false);
         byte[] var6 = var3.getRecord(1);
         int var2 = ((var6[1] + 256) % 256 << 8 | (var6[0] + 256) % 256) + 2;

         for(int var7 = 2; var7 < var2; ++var7) {
            var5.addElement((new DataInputStream(new ByteArrayInputStream(var3.getRecord(var7)))).readUTF());
         }

         var3.closeRecordStore();
      } catch (Exception var4) {
      }

      return var5;
   }

   private void A(int var1, Vector var2) {
      try {
         try {
            RecordStore.deleteRecordStore("SuperStackAttackStrings" + var1);
         } catch (Exception var4) {
         }

         RecordStore var3 = RecordStore.openRecordStore("SuperStackAttackStrings" + var1, true);
         byte[] var6 = new byte[]{(byte)(var2.size() & 255), (byte)(var2.size() >> 8 & 255)};
         var3.addRecord(var6, 0, var6.length);

         for(int var9 = 0; var9 < var2.size(); ++var9) {
            ByteArrayOutputStream var7 = new ByteArrayOutputStream();
            (new DataOutputStream(var7)).writeUTF((String)var2.elementAt(var9));
            byte[] var8 = var7.toByteArray();
            var3.addRecord(var8, 0, var8.length);
         }

         var3.closeRecordStore();
      } catch (Exception var5) {
      }

   }

   private void C(String var1) {
      try {
         InputStream var2 = this.getClass().getResourceAsStream("lang/" + var1 + ".lng");
         byte[] var4 = new byte[2];
         var2.read(var4, 0, 2);
         int var6 = ((var4[1] + 256) % 256 << 8 | (var4[0] + 256) % 256) - 2;
         var4 = new byte[var6];
         if (var2.read(var4) == var6) {
            g = var4;
         }
      } catch (Exception var3) {
      }

   }

   private static String A(String var0, int var1) {
      String var8 = "";
      String var7 = "";
      int var6 = 0;
      int var5 = var0.indexOf("\n");
      boolean var4 = false;
      boolean var3 = false;

      while(true) {
         int var2;
         do {
            if (var4) {
               var8 = "";
               var6 = 0;
               var2 = -1;
               break;
            }

            var7 = var7 + var8;
            var2 = var6;
            if (var6 > -1) {
               var6 = var0.indexOf(32, var6 + 1);
            }

            if (var6 > var5 && var5 != -1 || var6 == -1) {
               var6 = var5;
               if (var5 > -1) {
                  var5 = var0.indexOf(10, var5 + 1);
               }
            }

            if (var6 == -1 && var5 == -1) {
               var6 = var0.length();
               var4 = true;
            }

            if (var6 > -1 && var2 > -1) {
               var8 = var0.substring(var2, var6);
            }

            if (var8.compareTo(" =") == 0) {
               var6 += 2;
               var8 = var0.substring(var2, var6);
            }

            if (!var4 && var0.charAt(var2) == '\n') {
               var3 = true;
            }
         } while(Font.getDefaultFont().stringWidth(var7 + var8) < var1 - 2 && !var3);

         String var11;
         if (var2 > 0) {
            var11 = var0.substring(0, var2);
            var11 = var11 + "\n";
         } else {
            var11 = "";
         }

         var0 = var0.substring(var2 + 1, var0.length());
         var0 = var11 + var0;
         var7 = "";
         var3 = false;
         if (var4) {
            return var0;
         }
      }
   }

   public static String E(int var0) {
      ++var0;
      var0 *= 2;
      if (var0 >= 0 && var0 < g.length) {
         int var1 = (g[var0 + 4] + 256) % 256 << 8 | (g[var0 + 3] + 256) % 256;
         var0 = (g[var0 + 2] + 256) % 256 << 8 | (g[var0 + 1] + 256) % 256;
         byte[] var2 = new byte[var1 - var0];
         System.arraycopy(g, var0, var2, 0, var2.length);
         switch (g[0]) {
            case 0:
               String var12 = new String();

               for(int var9 = 0; var9 < var2.length; ++var9) {
                  var12 = var12 + (char)(var2[var9] < 0 ? 256 + var2[var9] : var2[var9]);
               }

               String var10 = var12.replace('\r', '\n');
               return var10;
            case 1:
               StringBuffer var11 = new StringBuffer(var2.length / 2);

               for(int var8 = 0; var8 < var2.length - 1; var8 += 2) {
                  var11.append((char)((var2[var8 + 1] + 256) % 256 << 8 | (var2[var8] + 256) % 256));
               }

               return var11.toString().replace('\r', '\n');
            case 2:
               byte[] var7 = new byte[var2.length + 2];
               var7[0] = (byte)(var2.length >>> 8);
               var7[1] = (byte)var2.length;
               System.arraycopy(var2, 0, var7, 2, var2.length);

               try {
                  return (new DataInputStream(new ByteArrayInputStream(var7))).readUTF().replace('\r', '\n');
               } catch (Exception var3) {
               }
            default:
               return null;
         }
      } else {
         return "";
      }
   }

   protected void startApp() {
      if (this.b == -1) {
         this.K(1);
      } else {
         this.players[0][17] = 0;
         this.players[0][18] = 0;
         this.players[1][17] = 0;
         this.players[1][18] = 0;
         this.h = false;
         this.i.e = true;
         if (!this.i.f.isAlive()) {
            this.i.A(true, true);
            Display.getDisplay(this).setCurrent(this.i);
         }

         if (this.n == 2) {
         }
      }

   }

   protected void pauseApp() {
      this.h = true;
      this.i.e = false;
      this.players[0][17] = 0;
      this.players[0][18] = 0;
      this.players[1][17] = 0;
      this.players[1][18] = 0;
   }

   protected void destroyApp(boolean var1) {
      ((MIDlet)this).notifyDestroyed();
   }

   public void B() {
      if (this.jB > 0) {
         --this.jB;
      } else {
         this.h = true;
      }

   }

   public void C() {
      this.h = false;
   }

   public void commandAction(Command var1, Displayable var2) {
      if (var2 == this.r) {
         if (var1 != List.SELECT_COMMAND && var1.getPriority() != 500) {
            this.B(var1.getPriority() & 16383, var1.getCommandType() == 2);
         } else if (this.s.getSelectedIndex() > -1) {
            this.B((Integer)this.t.elementAt(this.s.getSelectedIndex()) & 16383, false);
         }

      }
   }

   private Displayable F(int var1) {
      Object var8 = null;
      int var7 = 0;
      Object var6 = null;

      for(int var5 = 0; var5 < this.a.length; var5 += 2) {
         int var4 = this.a[var5];
         int var3 = this.a[var5 + 1];
         if (var1 == (var3 & 1023)) {
            switch (var4 & 15) {
               case 0:
                  if (this.i == null) {
                     this.i = new GameCanvasLoop(this, var4 >>> 14, var3 & 15360 | var4 >> 4 & 1023);
                  } else {
                     this.i.b = var4 >>> 14;
                     this.i.c = var3 & 15360 | var4 >> 4 & 1023;
                  }

                  var8 = this.i;
                  ((Displayable)var8).setCommandListener(this);
                  this.f = var4;
                  break;
               case 1:
                  this.u = new Form(E(var4 >> 4 & 1023));
                  var8 = this.u;
                  ((Displayable)var8).setCommandListener(this);
                  this.v = new Vector();
                  this.f = var4;
                  break;
               case 2:
                  byte var13;
                  switch (var4 >> 4 & 15) {
                     case 1:
                        var13 = 3;
                        break;
                     case 2:
                        var13 = 1;
                        break;
                     case 3:
                        var13 = 2;
                        break;
                     default:
                        var13 = 0;
                  }

                  try {
                     this.s = new List(E(var4 >> 8 & 1023), var13);
                     this.t = new Vector();
                     var8 = this.s;
                     ((Displayable)var8).setCommandListener(this);
                     this.f = var4;
                  } catch (Exception var9) {
                  }
                  break;
               case 3:
                  byte var12;
                  switch (var3 >>> 20) {
                     case 0:
                     default:
                        var12 = 1;
                        break;
                     case 1:
                        var12 = 2;
                  }

                  ((Displayable)var8).addCommand(new Command(E(var4 >> 4 & 1023), var12, var4 >>> 24 << 13 | var3 & 15360 | var4 >> 14 & 1023));
                  break;
               case 4:
                  int var11;
                  switch (var4 >>> 22) {
                     case 0:
                        var11 = 0;
                        break;
                     case 1:
                        var11 = 1;
                        break;
                     case 2:
                        var11 = 2;
                        break;
                     case 3:
                        var11 = 65536;
                        break;
                     case 4:
                        var11 = 3;
                        break;
                     case 5:
                        var11 = 4;
                        break;
                     default:
                        var11 = 0;
                  }

                  this.v.addElement(new Integer(this.u.size() | var3 >>> 10 << 8));
                  this.u.append(new TextField(E(var4 >> 4 & 1023), this.c[var1][var7], var4 >> 14 & 255, var11));
                  ++var7;
                  break;
               case 5:
                  if (this.u != null) {
                     this.u.append(E(var4 >> 4 & 1023));
                  } else if (this.s != null) {
                     this.s.append(E(var4 >> 4 & 1023), (Image)null);
                     this.t.addElement(new Integer(var4 >> 14 & 1023 | var3 & 15360));
                  }
                  break;
               case 6:
                  Alert var14 = new Alert(E(var4 >> 4 & 1023));
                  if (var1 == 8) {
                     char[] var2 = (new String("10/17/05 11:48:01")).toCharArray();
                     var14.setString("(c) 20" + var2[6] + var2[7] + " " + E(var4 >> 14 & 1023) + "\n" + ((MIDlet)this).getAppProperty("MIDlet-Version"));
                  } else {
                     var14.setString(E(var4 >> 14 & 1023));
                  }

                  int var10 = (var4 >>> 24) * 50;
                  var14.setTimeout(var10 == 0 ? -2 : var10);
                  var8 = var14;
                  break;
               case 7:
                  if (this.u != null) {
                     switch (var4 >> 14 & 1023) {
                        default:
                           var6 = new ImageItem(E(var4 >> 4 & 1023), (Image)null, 0, E(var3 >> 14 & 1023));
                           this.u.append((Item)var6);
                     }
                  }
                  break;
               case 8:
                  if (this.u != null) {
                     var6 = new StringItem(E(var4 >> 4 & 1023), E(var3 >> 14 & 1023), 0);
                     this.u.append((Item)var6);
                  }
               case 9:
            }

            if (var6 != null) {
               ((Item)var6).setItemCommandListener(this);
            }
         } else {
            var7 = 0;
         }
      }

      return (Displayable)var8;
   }

   private void G(int var1) {
      Display.getDisplay(this).setCurrent(this.F(var1));
   }

   public void commandAction(Command var1, Item var2) {
      if (this.r.getClass().getName().equals("javax.microedition.lcdui.Form") || this.r.getClass().getName().equals("com.siemens.mp.lcdui.Form")) {
         int var3 = var1.getPriority() & 16383;
         this.B(var3, false);
      }
   }

   private int H(int var1) {
      for(int var2 = 0; var2 < this.d.size(); ++var2) {
         if ((Integer)this.d.elementAt(var2) >>> 8 == var1) {
            return var2;
         }
      }

      return -1;
   }

   private void A(int var1, int var2) {
      var2 |= var1 << 8;
      var1 = this.H(var1);
      if (var1 == -1) {
         this.d.addElement(new Integer(var2));
      } else {
         this.d.setElementAt(new Integer(var2), var1);
      }

   }

   private int I(int var1) {
      var1 = this.H(var1);
      return var1 == -1 ? 0 : (Integer)this.d.elementAt(var1) & 255;
   }

   public void J(int var1) {
      this.e.addElement(new Integer(var1));
   }

   private int D() {
      int var1 = (Integer)this.e.lastElement();
      this.e.removeElement(this.e.lastElement());
      return var1;
   }

   public void K(int var1) {
      this.w = this.b;
      if (this.x != null) {
         this.x.n = this.b;
         if (this.x.n == 27) {
            this.x.o = true;
         } else if (this.x.n == 11) {
            this.x.o = false;
         }
      }

      this.H();
      this.b = var1;
      this.G();
   }

   public void A(int var1, String var2, String var3) {
      this.H();
      this.j = var2;
      this.k = var3;
      this.b = var1;
      this.G();
      this.j = null;
      this.k = null;
   }

   public void A(int var1, boolean var2) {
      this.H();
      this.l = var2;
      this.m = var1;
      this.b = var1;
      this.G();
   }

   public void L(int var1) {
      this.K();
      this.n = var1;
      this.J();
   }

   String B(String var1, int var2) {
      StringBuffer var5 = new StringBuffer(var1.trim());

      for(int var3 = 0; var3 < var5.length(); ++var3) {
         if (var5.charAt(var3) == '\n' || var5.charAt(var3) == '\r') {
            var5.deleteCharAt(var3--);
         }
      }

      String var4 = new String(var5);
      if (var4.length() < var2) {
         return null;
      } else {
         return var4;
      }
   }

   public int A(String[] var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < 8; ++var3) {
         if (var1 != null && var1[var3] != null) {
            ++var2;
         }
      }

      return var2;
   }

   public Vector E() {
      Vector var1 = this.D(7);
      if (var1 == null || var1.size() == 0) {
         var1 = new Vector();
         var1.addElement(E(34));
         var1.addElement(E(35));
         var1.addElement(E(36));
         var1.addElement(E(37));
         var1.addElement(E(38));
         this.A(7, var1);
      }

      return var1;
   }

   public Image A(boolean var1, int var2) {
      switch (var2) {
         case 0:
            return this.B("/" + this.oa, "i.p", 32);
         case 1:
            return this.B("/" + this.oa, "i.p", 27);
         case 2:
            return this.B("/" + this.oa, "i.p", 30);
         case 3:
            return this.B("/" + this.oa, "i.p", 29);
         default:
            return null;
      }
   }

   private String D(String var1) {
      String[] var2 = new String[]{"ar-AR", "ar", "pt-BR", "pt-br", "bg-BG", "bg", "ca-CA", "ca", "hr-HR", "hr", "cs-CS", "cs", "da-DA", "da", "nl-NL", "nl", "en-US", "en", "et-ET", "et", "fa-FA", "fa", "fi-FI", "fi", "fr-FR", "fr", "de-DE", "de", "el-EL", "el", "he-HE", "he", "hi-HI", "hi", "hu-HU", "hu", "id-ID", "id", "it-IT", "it", "lv-LV", "lv", "lt-LT", "lt", "ms-MS", "ms", "no-NO", "no", "pl-PL", "pl", "pt-PT", "pt", "ro-RO", "ro", "ru-RU", "ru", "sr-SR", "sr", "zh-CN", "zh", "sk-SK", "sk", "sl-SL", "sl", "es-ES", "es", "sv-SV", "sv", "tl-TL", "tl", "th-TH", "th", "zh-TW", "zh-tw", "tr-TR", "tr", "uk-UK", "uk", "ur-UR", "ur", "vi-VI", "vi"};

      for(int var3 = 0; var3 < var2.length; var3 += 2) {
         if (var1.equals(var2[var3])) {
            return var2[var3 + 1];
         }
      }

      return var1;
   }

   public StackAttack() {
      this.eb = new int[this.cb * this.db];
      this.fb = 0;
      this.random = new Random();
      this.hb = -1;
      this.mb = 0;
      this.nb = 0;
      this.ob = 0;
      this.rb = true;
      this.vb = new Texture2D[3][2];
      this.wb = 0;
      this.xb = 0;
      this.yb = 0;
      this.cB = 0;
      this.dB = null;
      this.eB = null;
      this.fB = null;
      this.gB = null;
      this.hB = null;
      this.iB = false;
      this.jB = 0;
      this.kB = new SmsMessenger(this);
      this.lB = 0;
      this.mB = new String[10];
      this.nB = new HttpClient("05969D8D", -1720134317);
      this.oB = 0;
      this.pB = "";
      this.qB = new String[10];
      this.tB = "";
      this.wB = 0;
      this.yB = new int[10];
      this.zB = false;
      this.ac = 0;
      this.bc = false;
      this.cc = 0;
      this.rB = false;

      try {
         Class.forName("javax.bluetooth.LocalDevice");
         this.rB = true;
      } catch (Exception var2) {
      }

      this.C(this.D(System.getProperty("microedition.locale")));
      if (g == null) {
         this.C("en");
         if (g == null) {
            this.C("en-us");
            if (g == null) {
               this.destroyApp(true);
            }
         }
      }

      this.b = -1;
      this.n = 200;
      this.e = new Vector();
      this.d = new Vector();
      this.c = new String[93][1];
      q = new SoundManager();
      this.sprites.A();
      this.players[1][0] = -1;
      this.ib = 0;
      this.na.addElement(new String("default/"));
      if (this.oa.length() == 0) {
         this.oa = (String)this.na.firstElement();
      }

      o = this.C(1);
      if (o.length == 1 && o[0] == 0) {
         o = new byte[4];
         o[0] = 20;
         o[1] = 20;
         o[2] = 1;
         o[3] = 1;
      }

      p = new byte[o.length];
      System.arraycopy(o, 0, p, 0, o.length);
      q.C(o[1]);
      this.qb = this.A(3, 5, false);
      this.fb = 3;
      byte[] var1 = this.C(2);
      if (var1[0] != 0) {
         this.lb = (var1[3] + 256) % 256 << 24 | (var1[2] + 256) % 256 << 16 | (var1[1] + 256) % 256 << 8 | (var1[0] + 256) % 256;
      }

      for(int var3 = 0; var3 < this.sA.length; ++var3) {
         this.sA[var3] = -1;
      }

      for(int var4 = 0; var4 < this.tA.length; ++var4) {
         this.tA[var4] = -1;
      }

      for(int var5 = 0; var5 < this.uA.length; ++var5) {
         this.uA[var5] = -1;
      }

      for(int var6 = 0; var6 < this.vA.length; ++var6) {
         this.vA[var6] = -1;
      }

      for(int var7 = 0; var7 < this.wA.length; ++var7) {
         this.wA[var7] = -1;
      }

      this.zA = -1;
      this.yA = -1;
      this.xA = -1;
   }

   void F() {
      if (this.hB == null) {
         this.hB = Graphics3D.getInstance();

         try {
            Object3D[] var1 = Loader.load("/charsel.m3g");
            this.tb = (World)var1[0];
            this.ub = (Mesh)var1[0].find(18);
            this.vb[0][0] = new Texture2D((Image2D)Loader.load("/" + this.oa + "0" + "portrait_red.png")[0]);
            this.vb[0][1] = new Texture2D((Image2D)Loader.load("/" + this.oa + "1" + "portrait_red.png")[0]);
            this.vb[1][0] = new Texture2D((Image2D)Loader.load("/" + this.oa + "0" + "portrait_blue.png")[0]);
            this.vb[1][1] = new Texture2D((Image2D)Loader.load("/" + this.oa + "1" + "portrait_blue.png")[0]);
            this.vb[2][0] = new Texture2D((Image2D)Loader.load("/" + this.oa + "0" + "portrait_grn.png")[0]);
            this.vb[2][1] = new Texture2D((Image2D)Loader.load("/" + this.oa + "1" + "portrait_grn.png")[0]);
            int var4 = this.ub.getAnimationTrackCount();

            for(int var3 = 0; var3 < var4; ++var3) {
               AnimationTrack var2 = this.ub.getAnimationTrack(var3);
               KeyframeSequence var7 = var2.getKeyframeSequence();
               this.xb = var7.getDuration();
               var2.getController();
            }
         } catch (Exception var6) {
         }

         try {
            Object3D[] var8 = Loader.load("/wait.m3g");
            this.dB = (World)var8[0];
            this.eB = (Mesh)var8[0].find(13);
            this.fB = (Mesh)var8[0].find(14);
            this.gB = (Mesh)var8[0].find(15);
         } catch (Exception var5) {
         }
      }

   }

   private void G() {
      Object var7 = null;
      StateThread var6 = null;
      if (this.l) {
         this.sprites.a.fillRect(0, 0, 240, 320);
         this.cB = 0;
         Appearance var2 = ((Mesh)this.eB).getAppearance(0);
         var2.getCompositingMode();
         CompositingMode var1 = new CompositingMode();
         var1.setAlphaWriteEnable(true);
         var1.setBlending(64);
         var2.setCompositingMode(var1);

         try {
            Texture2D var27 = new Texture2D((Image2D)Loader.load("/" + this.oa + "yellow.png")[0]);
            var27.setBlending(228);
            var2.setTexture(0, var27);
         } catch (Exception var22) {
         }

         var2 = ((Mesh)this.fB).getAppearance(0);
         var2.getCompositingMode();
         var1 = new CompositingMode();
         var1.setAlphaWriteEnable(true);
         var1.setBlending(64);
         var2.setCompositingMode(var1);

         try {
            Texture2D var29 = new Texture2D((Image2D)Loader.load("/" + this.oa + "red.png")[0]);
            var29.setBlending(228);
            var2.setTexture(0, var29);
         } catch (Exception var21) {
         }

         var2 = ((Mesh)this.gB).getAppearance(0);
         var2.getCompositingMode();
         var1 = new CompositingMode();
         var1.setAlphaWriteEnable(true);
         var1.setBlending(64);
         var2.setCompositingMode(var1);

         try {
            Texture2D var31 = new Texture2D((Image2D)Loader.load("/" + this.oa + "blue.png")[0]);
            var31.setBlending(228);
            var2.setTexture(0, var31);
         } catch (Exception var20) {
         }

         var6 = new StateThread(this);
         this.b = 13;
         var7 = this.F(this.b);
         ((GameCanvasLoop)var7).A(true, true);
      } else if (this.b != 11) {
         var7 = this.F(this.b);
      }

      switch (this.b) {
         case 1:
            ((GameCanvasLoop)var7).A(true, true);
            break;
         case 2:
            ((GameCanvasLoop)var7).A(true, true);
            break;
         case 3:
            q.A(0);
            ((GameCanvasLoop)var7).A(true, true);
            break;
         case 4:
            this.F();
            this.fA = 90L;
            if (this.x != null) {
               try {
                  this.x.A();
                  this.x = null;
               } catch (Exception var19) {
               }
            }

            this.jB = 0;
            if (this.e != null) {
               this.e.removeAllElements();
            }

            byte[] var108 = this.C(11);
            this.mb = var108[0];
            if (this.mb == 0) {
               this.mb = 1;
            }

            if (!this.rB) {
               this.s.delete(1);
               this.t.removeElementAt(1);
            }
            break;
         case 5:
            this.iB = true;
            byte[] var102 = this.C(2);
            if (var102[0] != 0) {
               this.lb = (var102[3] + 256) % 256 << 24 | (var102[2] + 256) % 256 << 16 | (var102[1] + 256) % 256 << 8 | (var102[0] + 256) % 256;
            }

            this.kB.C();
            this.kB.G();
            StringItem var103 = new StringItem("", E(162));
            ((Item)var103).setLayout(3);
            this.u.append(var103);
            var103 = new StringItem("", "" + this.lb);
            ((Item)var103).setLayout(3);
            this.u.append(var103);

            try {
               this.kB.A(E(6) + " " + E(80) + ": " + this.lb);
               this.kB.A(1);
               if (this.lb != 0) {
                  String var105 = "file:///" + "fs/MyStuff/Pictures/" + "SuperStackAttack" + "/" + this.lb + "." + "png";
                  String var136 = var105.replace('\\', '/');
                  Image var106 = F(var136);
                  if (var106 != null) {
                     this.u.append(new ImageItem("", var106, 19, ""));
                     this.kB.A(2, var136);
                  } else {
                     this.u.append(new Spacer(240, 106));
                     StringItem var107 = new StringItem("", "");
                     ((Item)var107).setLayout(3);
                     var107.setText(E(19));
                     this.u.append(var107);
                  }
               }
            } catch (Exception var18) {
            }

            if (this.lb > 0) {
               this.u.addCommand(new Command(E(170), 1, 48));
               this.u.addCommand(new Command(E(52), 1, 59));
            } else {
               this.u.addCommand(new Command(E(140), 1, 1028));
            }
            break;
         case 6:
            Image var147 = this.B("/", "i.p", 1);
            Image var134 = this.B("/", "i.p", 0);
            if (var147 == null || var134 == null) {
               return;
            }

            if (p[1] > 0) {
               var134 = var147;
            } else {
               var134 = var134;
            }

            int var101 = this.A(this.s, E(185));
            if (var101 != -1) {
               this.s.set(var101, E(185), var134);
            }
            break;
         case 7:
            this.ib = 0;
            break;
         case 8:
            StringBuffer var146 = new StringBuffer(E(209));
            int var100 = var146.toString().indexOf("%1%");
            if (var100 != -1) {
               var146.deleteCharAt(var100);
               var146.deleteCharAt(var100);
               var146.deleteCharAt(var100);
               var146.insert(var100, ((MIDlet)this).getAppProperty("MIDlet-Version") + " " + "LG91");
            }

            int var133 = var146.toString().indexOf("%2%");
            if (var133 != -1) {
               var146.deleteCharAt(var133);
               var146.deleteCharAt(var133);
               var146.deleteCharAt(var133);
            }

            var146.insert(var133, "20" + "05" + " - " + "10" + " - " + "17");
            this.u.append(var146.toString());
            break;
         case 9:
            this.A(11, true);
            break;
         case 11:
            this.i = (GameCanvasLoop)this.F(this.b);
            this.i.A(true, true);
            this.h = false;
            var7 = this.i;
            if (this.n == 5) {
               this.L(1);
               this.L(5);
            } else {
               this.L(1);
            }
            break;
         case 12:
            if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
               byte[] var99 = new byte[5];
               var99[4] = 1;
               this.x.A(0, this.x.j, 1017, 1, var99);
            }
            break;
         case 16:
         case 38:
         case 48:
         case 51:
         case 74:
         case 81:
         case 82:
            this.yb = 0;
            this.MA(this.b);
            ((GameCanvasLoop)var7).A(true, true);
            break;
         case 17:
            this.s.append(E(56), (Image)null);
            this.t.addElement(new Integer(14));
            this.s.append(E(128), (Image)null);
            this.t.addElement(new Integer(14));
            this.s.append(E(54), (Image)null);
            this.t.addElement(new Integer(14));
            if (this.ha == 1) {
               this.s.append(E(63), (Image)null);
               this.t.addElement(new Integer(14));
            }
            break;
         case 18:
            if (this.x == null) {
               try {
                  this.x = new BluetoothLink(this, this);
               } catch (Exception var11) {
               }
            }
            break;
         case 19:
            ((TextField)this.u.get(0)).setString(this.c[19][0]);
            break;
         case 20:
         case 22:
         case 25:
            ((GameCanvasLoop)var7).A(true, true);
            break;
         case 21:
            ((TextField)this.u.get(0)).setString(this.c[21][0]);
            break;
         case 27:
            this.s.deleteAll();

            for(int var97 = 0; var97 < 8; ++var97) {
               if (this.x.g[var97] != null) {
                  this.s.append(this.x.g[var97], this.A(this.x.m[var97], this.players[var97 == 0 ? 0 : 1][1]));
                  this.t.addElement(new Integer(0));
               }
            }

            if ((this.y & 1048576) != 0) {
               this.x.h[this.x.j][0] = 1;
               int var132 = 0;

               for(int var98 = 0; var98 < 8; ++var98) {
                  if (this.x.g[var98] != null && this.x.h[var98][0] == 1) {
                     ++var132;
                  }
               }

               if (var132 >= 2) {
                  this.s.addCommand(new Command(E(196), 1, 204));
               }
            } else if ((this.y & 65536) != 0 && this.x.h[this.x.j][0] == 0) {
               this.x.h[this.x.j][0] = 1;
               this.x.A(0, this.x.j, 1004, 0, (byte[])null);
            }
            break;
         case 30:
            Vector var131 = this.E();

            for(int var96 = 0; var96 < var131.size(); ++var96) {
               this.s.append((String)var131.elementAt(var96), (Image)null);
               this.t.addElement(new Integer(231));
            }
            break;
         case 31:
            ((TextField)this.u.get(0)).setString(this.c[31][0]);
            break;
         case 33:
         case 34:
            if (this.x != null) {
               Image var151 = this.B("/", "i.p", 1);
               Image var145 = this.B("/", "i.p", 0);
               int var130 = this.A(this.x.g);
               if (var130 == 2) {
                  var130 = -1;
               } else if (var130 > 2) {
                  var130 = 0;
                  this.x.k[0][0] = E(201);
                  this.x.k[0][1] = Integer.toString(64);
               }

               for(int var94 = 0; var94 < 8; ++var94) {
                  if (this.x.g != null && this.x.g[var94] != null && var94 != this.x.j) {
                     ++var130;
                     this.x.k[var130][0] = this.x.g[var94];
                     this.x.k[var130][1] = Integer.toString(var94);
                  }
               }

               for(int var95 = 0; var95 < var130 + 1; ++var95) {
                  this.s.append(this.x.k[var95][0], this.x.l[var95] ? var151 : var145);
                  this.t.addElement(new Integer(234));
               }
            }
            break;
         case 35:
            Vector var129 = this.E();

            for(int var93 = 0; var93 < var129.size(); ++var93) {
               this.s.append((String)var129.elementAt(var93), (Image)null);
               this.t.addElement(new Integer(240));
            }

            this.s.append("(...)", (Image)null);
            this.t.addElement(new Integer(241));
            break;
         case 37:
            if (this.z != -99) {
               Vector var92 = this.E();
               ((TextField)this.u.get(0)).setString((String)var92.elementAt(this.z));
            }
            break;
         case 39:
            this.iB = false;
            this.B("/", "i.p", 0);
            Image[] var144 = new Image[5];
            Image[] var128 = new Image[5];
            var144[0] = this.B("/" + this.oa, "i.p", 8);
            var144[1] = this.B("/" + this.oa, "i.p", 10);
            var144[2] = this.B("/", "i.p", 2);
            var144[3] = this.B("/", "i.p", 4);
            var144[4] = this.B("/", "i.p", 6);
            var128[0] = this.B("/" + this.oa, "i.p", 9);
            var128[1] = this.B("/" + this.oa, "i.p", 11);
            var128[2] = this.B("/", "i.p", 3);
            var128[3] = this.B("/", "i.p", 5);
            var128[4] = this.B("/", "i.p", 7);

            for(int var91 = 0; var91 < this.s.size(); ++var91) {
               if (this.qb[var91]) {
                  this.s.set(var91, this.s.getString(var91), var144[var91]);
               } else {
                  this.s.set(var91, this.s.getString(var91), var128[var91]);
               }
            }

            this.s.setSelectedFlags(this.qb);
         case 40:
         case 903:
         default:
            break;
         case 41:
            if (this.sb != null) {
               this.sb.removeAllElements();
               this.sb = null;
            }

            String var87 = "file:///" + "fs/MyStuff/Pictures/" + "SuperStackAttack" + "/";
            this.sb = new Vector();

            try {
               FileConnection var143 = (FileConnection)Connector.open(var87, 1);
               if (var143.exists()) {
                  Enumeration var126 = var143.list("*", true);

                  while(var126.hasMoreElements()) {
                     Object var88 = var126.nextElement();
                     this.sb.addElement(var88);
                  }

                  var143.close();
               }
            } catch (Exception var23) {
            }

            if (this.sb != null) {
               if (this.sb.size() == 0) {
                  this.u.setTitle(E(163) + " 0 / 0 ");
               } else {
                  this.u.setTitle(E(163) + " " + (this.ob + 1) + " / " + this.sb.size());
                  Object var89 = this.sb.elementAt(this.ob);
                  if (var89 != null) {
                     String var127 = "file:///" + "fs/MyStuff/Pictures/" + "SuperStackAttack" + "/" + var89;

                     try {
                        try {
                           Image var90 = F(var127);
                           if (var90 != null) {
                              this.u.append(new ImageItem("", var90, 51, ""));
                           }
                        } catch (Exception var12) {
                        }
                     } catch (Exception var13) {
                     }

                     System.gc();
                  }
               }
            } else {
               this.u.setTitle(E(163) + " list == null ");
            }

            if (this.sb.size() > 0) {
               if (this.sb.size() > 1) {
                  this.u.addCommand(new Command(E(134), E(134), 1, 49));
               }

               this.u.addCommand(new Command(E(52), 1, 50));
            } else {
               this.u.addCommand(new Command(E(140), E(140), 2, 42));
            }
            break;
         case 44:
            try {
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 2), 16, ""));
               this.u.append(E(188));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 7), 16, ""));
               this.u.append(E(189));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 36), 16, ""));
               this.u.append(E(192));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 37), 16, ""));
               this.u.append(E(194));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 38), 16, ""));
               this.u.append(E(191));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 39), 16, ""));
               this.u.append(E(190));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 40), 16, ""));
               this.u.append(E(195));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 41), 16, ""));
               this.u.append(E(193));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 34), 16, ""));
               this.u.append(E(143));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 16), 16, ""));
               this.u.append(E(11));
               this.u.append(new Spacer(240, 5));
               this.u.append(new ImageItem("", this.B("/" + this.oa, "i.p", 21), 16, ""));
               this.u.append(E(42));
            } catch (Exception var14) {
            }
            break;
         case 46:
            int var150 = 0;

            try {
               for(; var150 < this.jA.length; ++var150) {
                  if (this.jA[var150][1] != 0) {
                     short var141 = 0;
                     short var124 = 0;
                     switch (this.jA[var150][0]) {
                        case -11:
                           var141 = 110;
                           break;
                        case -7:
                           var141 = 184;
                           break;
                        case -6:
                           var141 = 183;
                           break;
                        case -5:
                           var141 = 93;
                           break;
                        case -4:
                           var141 = 96;
                           break;
                        case -3:
                           var141 = 95;
                           break;
                        case -2:
                           var141 = 94;
                           break;
                        case -1:
                           var141 = 97;
                           break;
                        case 35:
                           var141 = 108;
                        case 42:
                        default:
                           break;
                        case 48:
                           var141 = 98;
                           break;
                        case 49:
                           var141 = 99;
                           break;
                        case 50:
                           var141 = 100;
                           break;
                        case 51:
                           var141 = 101;
                           break;
                        case 52:
                           var141 = 102;
                           break;
                        case 53:
                           var141 = 103;
                           break;
                        case 54:
                           var141 = 104;
                           break;
                        case 55:
                           var141 = 105;
                           break;
                        case 56:
                           var141 = 106;
                           break;
                        case 57:
                           var141 = 107;
                     }

                     switch (this.jA[var150][1]) {
                        case 2:
                           var124 = 129;
                           break;
                        case 3:
                           var124 = 130;
                           break;
                        case 4:
                           var124 = 89;
                           break;
                        case 5:
                           var124 = 90;
                           break;
                        case 6:
                           var124 = 91;
                        case 7:
                        case 8:
                        case 9:
                        default:
                           break;
                        case 10:
                           var124 = 1;
                     }

                     String var83 = E(var141);
                     this.u.append(new StringItem(var83 + " :", E(var124)));
                     Spacer var84 = new Spacer(0, 0);
                     ((Item)var84).setLayout(256);
                     this.u.append(var84);
                  } else {
                     byte var142 = 0;
                     short var125 = 0;
                     switch (this.jA[var150][0]) {
                        case -11:
                           var142 = 110;
                           var125 = 62;
                           break;
                        case 35:
                           var142 = 108;
                           var125 = 142;
                        case 42:
                     }

                     if (var125 != 0) {
                        String var85 = E(var142);
                        this.u.append(new StringItem(var85 + " :", E(var125)));
                        Spacer var86 = new Spacer(0, 0);
                        ((Item)var86).setLayout(256);
                        this.u.append(var86);
                     }
                  }
               }
            } catch (Exception var25) {
            }
            break;
         case 47:
            String var80;
            if (this.jb == 17) {
               var80 = E(186);
            } else {
               var80 = E(10);
            }

            this.u.setTitle(var80);
            Spacer var81 = new Spacer(240, 106);
            this.u.append(var81);
            Gauge var82;
            if (this.jb == 17) {
               var82 = new Gauge("", true, 10, o[1] / 10);
            } else {
               var82 = new Gauge("", true, 10, o[0] / 10);
            }

            var82.setLayout(48);
            this.hb = this.u.append(var82);
            break;
         case 49:
         case 63:
            this.ga = 0;
            this.ha = 1;
            break;
         case 50:
            this.za = 0;
            this.eA = 0L;

            for(int var79 = 1; var79 <= this.mb; ++var79) {
               this.s.append(E(119) + " " + var79, (Image)null);
               this.t.addElement(new Integer(29));
            }

            this.s.setSelectedIndex(this.s.size() - 1, true);
            break;
         case 52:
            String var73 = "";
            switch (this.kb) {
               case 0:
                  var73 = E(14);
                  break;
               case 1:
                  var73 = E(15);
                  break;
               case 2:
                  var73 = E(16);
                  break;
               case 3:
                  var73 = E(17);
                  break;
               case 4:
                  var73 = E(18);
            }

            this.u.setTitle(var73);
            String var123 = "";
            switch (this.kb) {
               case 0:
                  var123 = "500";
                  break;
               case 1:
                  var123 = "1500";
                  break;
               case 2:
                  var123 = "1000";
                  break;
               case 3:
                  var123 = "2000";
                  break;
               case 4:
                  var123 = "4000";
            }

            Spacer var74 = new Spacer(240, 10);
            this.u.append(var74);
            StringItem var75 = new StringItem("", E(19));
            ((Item)var75).setLayout(515);
            this.u.append(var75);
            Spacer var76 = new Spacer(240, 10);
            this.u.append(var76);
            StringItem var77 = new StringItem("", E(8));
            ((Item)var77).setLayout(515);
            this.u.append(var77);
            var77 = new StringItem("", "" + var123 + " " + E(149));
            ((Item)var77).setLayout(515);
            this.u.append(var77);
            break;
         case 53:
            String var140 = "";
            switch (this.kb) {
               case 0:
                  var140 = E(14);
                  break;
               case 1:
                  var140 = E(15);
                  break;
               case 2:
                  var140 = E(16);

                  try {
                     this.u.append(new ImageItem("", Image.createImage("/s.jpg"), 51, ""));
                  } catch (Exception var17) {
                  }

                  this.kB.G();
                  this.kB.A(2);
                  this.kB.A(3, "/s.jpg");
                  this.kB.A(E(16));
                  break;
               case 3:
                  var140 = E(17);

                  try {
                     this.u.append(new ImageItem("", Image.createImage("/r.png"), 51, ""));
                  } catch (Exception var16) {
                  }

                  this.kB.G();
                  this.kB.A(2);
                  this.kB.A(3, "/s/0.mid");
                  this.kB.A(E(17));
                  break;
               case 4:
                  var140 = E(18);
                  Image var122 = null;

                  try {
                     var122 = Image.createImage("/m.gif");
                  } catch (Exception var15) {
                  }

                  if (var122 != null) {
                     this.u.append(new ImageItem("", var122, 51, ""));
                  }

                  this.kB.G();
                  this.kB.A(2);
                  this.kB.A(3, "/m.gif");
                  this.kB.A(E(18));
            }

            this.u.addCommand(new Command(E(161), 1, 21));
            this.u.setTitle(var140);
            break;
         case 57:
            int var138 = 0;

            try {
               this.u.append(new Spacer(240, 5));
               this.u.append(E(51));
               int[][] var153 = new int[3][2];

               for(int var120 = 0; var120 < var153.length; ++var120) {
                  for(int var66 = 0; var66 < var153[var120].length; ++var66) {
                     var153[var120][var66] = -1;
                  }
               }

               for(; var138 < this.kA.length; ++var138) {
                  switch (this.kA[var138][1]) {
                     case 21:
                        for(int var69 = 0; var69 < var153[0].length; ++var69) {
                           if (var153[0][var69] == -1) {
                              var153[0][var69] = this.kA[var138][0];
                              break;
                           }
                        }
                        break;
                     case 22:
                        for(int var68 = 0; var68 < var153[2].length; ++var68) {
                           if (var153[2][var68] == -1) {
                              var153[2][var68] = this.kA[var138][0];
                              break;
                           }
                        }
                        break;
                     case 23:
                        for(int var67 = 0; var67 < var153[1].length; ++var67) {
                           if (var153[1][var67] == -1) {
                              var153[1][var67] = this.kA[var138][0];
                              break;
                           }
                        }
                  }
               }

               for(int var149 = 0; var149 < var153.length; ++var149) {
                  int[] var139 = new int[2];
                  byte var121 = 0;
                  switch (var149) {
                     case 0:
                        var121 = 48;
                        break;
                     case 1:
                        var121 = 49;
                        break;
                     case 2:
                        var121 = 47;
                  }

                  for(int var70 = 0; var70 < var153[var149].length; ++var70) {
                     switch (var153[var149][var70]) {
                        case -5:
                           var139[var70] = 93;
                           break;
                        case -4:
                           var139[var70] = 96;
                           break;
                        case -3:
                           var139[var70] = 95;
                           break;
                        case 52:
                           var139[var70] = 102;
                           break;
                        case 53:
                           var139[var70] = 103;
                           break;
                        case 54:
                           var139[var70] = 104;
                           break;
                        default:
                           var139[var70] = -1;
                     }
                  }

                  String var71;
                  if (var139[1] == -1) {
                     var71 = E(var139[0]);
                  } else {
                     var71 = E(var139[0]) + ", " + E(var139[1]);
                  }

                  this.u.append(new StringItem(var71 + " :", E(var121)));
                  Spacer var72 = new Spacer(0, 0);
                  ((Item)var72).setLayout(256);
                  this.u.append(var72);
               }
            } catch (Exception var26) {
            }
            break;
         case 62:
            this.u.setTitle(E(119) + " " + (this.pb + 1));
            this.u.append(E(this.lA[this.pb]));
            if (this.lA[this.pb] == 127) {
               int[] var152 = this.C("/m.p", this.pb);
               if (var152[0] == 5) {
                  this.u.append(E(this.mA[var152[0]]));
               } else if (var152[0] == 6) {
                  long var62 = (long)var152[1];
                  long var155 = var62 / 1000L;
                  int var63 = (int)(var155 % 60L);
                  int var148 = var63 / 10;
                  int var137 = (int)(var155 % 10L);
                  long var64 = var155 - (long)var63;
                  var155 = var64 % 59L;
                  int var119 = (int)(var155 / 10L);
                  int var65 = (int)var155 % 10;
                  this.u.append(E(this.mA[var152[0]]) + ": " + var119 + "" + var65 + ":" + var148 + "" + var137);
               } else {
                  this.u.append(E(this.mA[var152[0]]) + ": " + var152[1]);
               }
            }
            break;
         case 64:
         case 76:
            Image var118 = this.B("/" + this.oa, "i.p", 42);
            int var60 = (this.u.getHeight() - var118.getHeight()) / 2;
            Spacer var61 = new Spacer(this.u.getWidth(), var60);
            this.u.append(var61);
            this.u.append(new ImageItem("", var118, 19, ""));
            if (this.b == 64) {
               this.u.addCommand(new Command(E(57), 2, 43));
            } else if (this.b != 76) {
               this.s.addCommand(new Command(E(57), 2, 310));
            }
            break;
         case 65:
            if (this.ha == 1) {
               this.s.setTitle(E(76));
            }

            if (this.ha == 0) {
               this.s.setTitle(E(75));
            }
            break;
         case 69:
            this.ha = 0;
            break;
         case 70:
            for(int var59 = 0; var59 <= 5; ++var59) {
               this.s.append(E(119) + " " + (var59 - 0 + 1), (Image)null);
               this.t.addElement(new Integer(300));
            }
            break;
         case 71:
            this.ha = 1;
            this.pb = 99;
            break;
         case 72:
            this.players[0][1] = 3;
            this.ha = 2;
            this.za = 6;
            this.pb = 100;
            break;
         case 73:
            this.u.setTitle(E(119) + " " + (this.pb + 1));
         case 88:
            this.u.append(E(127));
            int[] var5 = this.C("/s.p", this.pb);
            if (var5[0] == 5) {
               this.u.append(E(this.mA[var5[0]]));
            } else if (var5[0] == 6) {
               long var55 = (long)var5[1];
               long var8 = var55 / 1000L;
               int var56 = (int)(var8 % 60L);
               int var4 = var56 / 10;
               int var3 = (int)(var8 % 10L);
               long var57 = var8 - (long)var56;
               var8 = var57 % 59L;
               int var117 = (int)(var8 / 10L);
               int var58 = (int)var8 % 10;
               this.u.append(E(this.mA[var5[0]]) + ": " + var117 + "" + var58 + ":" + var4 + "" + var3);
            } else {
               this.u.append(E(this.mA[var5[0]]) + ": " + var5[1]);
            }

            this.players[0][1] = var5[2];
            if (var5[3] != -1) {
               this.players[1][1] = var5[3];
            }
            break;
         case 78:
            this.ha = 0;
            break;
         case 79:
            new Spacer(0, 3);
            this.u.append(new StringItem(E(162), "" + this.xB));
            Spacer var51 = new Spacer(0, 0);
            ((Item)var51).setLayout(256);
            this.u.append(var51);
            this.u.append(new StringItem(E(20) + ":", "" + this.yB[0]));
            var51 = new Spacer(0, 0);
            ((Item)var51).setLayout(256);
            this.u.append(var51);
            this.u.append(new StringItem(E(114) + ":", "" + this.yB[1]));
            var51 = new Spacer(0, 0);
            ((Item)var51).setLayout(256);
            this.u.append(var51);
            this.u.append(new StringItem(E(43), (String)null));

            for(int var116 = 3; var116 <= 9; ++var116) {
               if (this.stats[0][var116] != 0) {
                  var51 = new Spacer(0, 0);
                  ((Item)var51).setLayout(256);
                  this.u.append(var51);
                  this.u.append(new StringItem("" + var116 + ": " + this.yB[var116], (String)null));
               }
            }
            break;
         case 83:
            if (this.bc) {
               this.u.append(new String(E(159)));
               if ((this.y & 1048576) == 0 && (this.y & 65536) == 0) {
                  byte[] var49 = this.C(11);
                  if (var49[0] <= this.pb + 1 && this.pb + 1 < this.lA.length) {
                     ++this.mb;
                     var49 = new byte[]{(byte)this.mb};
                     this.A((byte[])var49, 11);
                  }
               }

               this.bc = false;
            } else {
               this.u.append(new String(E(158)));
            }
            break;
         case 87:
            String var43 = "";
            switch (this.ib - 1) {
               case 0:
                  var43 = E(14);
                  break;
               case 1:
                  var43 = E(15);
            }

            this.u.setTitle(var43);
            String var115 = "";
            switch (this.ib - 1) {
               case 0:
                  var115 = "500";
                  break;
               case 1:
                  var115 = "1500";
            }

            Spacer var44 = new Spacer(240, 10);
            this.u.append(var44);
            StringItem var45 = new StringItem("", E(19));
            ((Item)var45).setLayout(515);
            this.u.append(var45);
            Spacer var46 = new Spacer(240, 10);
            this.u.append(var46);
            StringItem var47 = new StringItem("", E(8));
            ((Item)var47).setLayout(515);
            this.u.append(var47);
            var47 = new StringItem("", "" + var115 + " " + E(149));
            ((Item)var47).setLayout(515);
            this.u.append(var47);
            break;
         case 800:
            String var114 = this.pB;
            this.nB.A();

            try {
               byte[] var40 = this.C(80);
               if (var40.length >= 1 && var40[0] != 0) {
                  this.pB = new String(var40);
               } else {
                  this.pB = "";
               }
            } catch (Exception var24) {
            }

            this.pB = var114;
            if (this.pB.equals("")) {
               this.pB = this.A();
            }

            this.qB[0] = this.pB;
            this.qB[1] = "";
            this.qB[2] = "";
            Item var41 = new Spacer(240, 5);
            var41.setLayout(512);
            this.u.append(var41);
            var41 = new TextField(E(135), this.qB[0], 12, 0);
            var41.setLayout(3);
            this.u.append(var41);
            break;
         case 801:
            Item var38 = new Spacer(240, 5);
            var38.setLayout(512);
            this.u.append(var38);
            var38 = new StringItem("", E(156));
            var38.setLayout(3);
            this.u.append(var38);
            break;
         case 802:
            Item var36 = new Spacer(240, 5);
            var36.setLayout(512);
            this.u.append(var36);
            var36 = new StringItem("", E(82));
            var36.setLayout(3);
            this.u.append(var36);
            break;
         case 803:
            this.u.append(new StringItem("", this.nB.B(this.nB.C())));
            break;
         case 900:
            this.mB[0] = "";
            this.mB[1] = "";
            this.mB[2] = "";
            if (this.kB.B(1)) {
               this.s.insert(0, E(178), (Image)null);
               this.t.insertElementAt(new Integer(902), 0);
            }
            break;
         case 902:
            Spacer var34 = new Spacer(240, 3);
            ((Item)var34).setLayout(512);
            this.u.append(var34);
            this.u.append(new StringItem("", this.kB.B()));
            var34 = new Spacer(240, 3);
            ((Item)var34).setLayout(512);
            this.u.append(var34);
            this.u.append(new TextField(E(3), (String)null, 50, 0));
            break;
         case 904:
            if (this.kB.A() == 1) {
               this.u.append(new Spacer(240, 5));
               this.u.append(new TextField(E(169), (String)null, 254, 3));
            } else if (this.kB.A() == 2) {
               this.u.append(new Spacer(240, 5));
               this.u.append(new TextField(E(176), (String)null, 254, 3));
               this.u.append(new Spacer(240, 5));
               this.u.append(new TextField(E(172), (String)null, 254, 1));
            }
            break;
         case 905:
            this.u.append(new Spacer(240, 5));
            StringItem var33 = new StringItem("", E(166));
            ((Item)var33).setLayout(3);
            this.u.append(var33);
            break;
         case 906:
            int var113 = this.kB.I();
            StringItem var32 = new StringItem("", "");
            ((Item)var32).setLayout(3);
            if (var113 == 0) {
               var32.setText(E(140));
            } else {
               var32.setText(E(44));
               this.u.append(var32);
               var32 = new StringItem("", "");
               ((Item)var32).setLayout(3);
               var32.setText("Result : " + var113 + " msg: " + this.kB.H());
            }

            this.u.append(var32);
      }

      if (var7 != null) {
         if (var7 instanceof List && (this.f >> 4 & 15) == 1 && ((List)var7).size() > 0 && this.b != 50) {
            int var109 = this.I(this.b);
            if (var109 >= ((List)var7).size()) {
               var109 = ((List)var7).size() - 1;
            }

            try {
               ((List)var7).setSelectedIndex(var109, true);
            } catch (Exception var10) {
            }
         }

         if (this.j != null && this.k != null) {
            Alert var110 = new Alert(this.j);
            var110.setString(this.k);
            var110.setTimeout(-2);
            Display.getDisplay(this).setCurrent(var110, (Displayable)var7);
         } else {
            Display.getDisplay(this).setCurrent((Displayable)var7);
         }

         this.r = (Displayable)var7;
      }

      if (var6 != null) {
         ((Thread)var6).start();
      }

   }

   private void H() {
      switch (this.b) {
         case 1:
         case 2:
         case 3:
         case 4:
         case 5:
         case 7:
         case 9:
         case 18:
         case 24:
         case 31:
         case 900:
         case 903:
         case 906:
         default:
            break;
         case 6:
            this.A((byte[])o, 1);
            break;
         case 16:
         case 20:
         case 22:
         case 25:
         case 38:
         case 48:
         case 51:
         case 74:
         case 81:
         case 82:
            ((GameCanvasLoop)this.r).e = false;
            ((GameCanvasLoop)this.r).d = false;
            break;
         case 33:
            this.s.getSelectedIndex();
            break;
         case 800:
            this.nB.A();
            this.qB[0] = ((TextField)this.u.get(this.u.size() - 1)).getString();
            this.A(this.qB[0]);
            break;
         case 902:
            this.mB[0] = ((TextField)this.u.get(this.u.size() - 1)).getString();
            break;
         case 904:
            this.mB[3] = ((TextField)this.u.get(1)).getString();
            if (this.u.size() > 2) {
               this.mB[2] = ((TextField)this.u.get(3)).getString();
            }
      }

      switch (this.f & 15) {
         case 1:
            try {
               int var2 = 0;
               int var1 = 0;
               if (this.u != null) {
                  for(; var2 < this.u.size(); ++var2) {
                     if (this.u.get(var2).getClass() == (new TextField("", "", 1, 0)).getClass()) {
                        this.c[this.b][var1] = ((TextField)this.u.get(var2)).getString();
                        ++var1;
                     }
                  }
               }

               this.u = null;
            } catch (Exception var4) {
            }
            break;
         case 2:
            if ((this.f >> 4 & 15) == 1) {
               try {
                  this.A(this.b, this.s.getSelectedIndex());
               } catch (Exception var3) {
               }
            }

            this.s = null;
            this.t = null;
      }

   }

   public void A(int var1, int var2, Object var3, String var4) {
      switch (var1) {
         case 1:
            this.K(26);
         case 2:
         case 4:
         case 7:
         case 11:
         case 12:
         case 13:
         default:
            break;
         case 3:
            if (this.b != 24) {
               this.K(24);
            }

            this.s.append(var4, (Image)null);
            this.t.addElement(new Integer(207));
            break;
         case 5:
         case 6:
            if (this.b != 4) {
               this.L(10);
               this.K(4);
            }
            break;
         case 8:
            if (this.b == 27) {
               this.K(27);
            }
            break;
         case 9:
            if ((this.y & 1048576) != 0 && this.b == 11) {
               this.L(3);
            }
            break;
         case 10:
            this.x.h[var2][0] = 0;
            byte[] var5 = new byte[]{0, 0, 0, 0, this.ga, this.ha, (byte)this.pb, (byte)this.maxPlanes, (byte)this.za, (byte)((int)(this.eA & 255L)), (byte)((int)(this.eA >>> 8 & 255L)), (byte)((int)(this.eA >>> 16 & 255L)), (byte)((int)(this.eA >>> 24 & 255L)), (byte)((int)(this.eA >>> 32 & 255L)), (byte)((int)(this.eA >>> 40 & 255L)), (byte)((int)(this.eA >>> 48 & 255L)), (byte)((int)(this.eA >>> 56 & 255L)), (byte)this.players[0][1], (byte)this.players[1][1]};
            this.x.A(var2, this.x.j, 1002, 15, var5);
            break;
         case 14:
            this.A(4, E(6), var3.toString());
      }

   }

   public synchronized void A(int var1, int var2, int var3, byte[] var4) {
      switch (var1) {
         case 500:
            String var36 = "";
            var2 = var4[4];

            try {
               var1 = (var4[5] + 256) % 256 | (var4[6] + 256) % 256 << 8 | (var4[7] + 256) % 256 << 16 | (var4[8] + 256) % 256 << 24;
               ByteArrayInputStream var21 = new ByteArrayInputStream(var4, 9, var1);
               DataInputStream var22 = new DataInputStream(var21);
               var36 = var22.readUTF();
               var22.close();
            } catch (Exception var7) {
            }

            this.K(32);
            this.u.setTitle(this.x.g[var2]);
            this.u.append(var36);
            break;
         case 1002:
            this.ga = var4[4];
            this.ha = var4[5];
            this.pb = var4[6];
            this.maxPlanes = var4[7];
            this.za = var4[8];
            this.eA = (long)((var4[9] + 256) % 256) | (long)((var4[10] + 256) % 256) << 8 | (long)((var4[11] + 256) % 256) << 16 | (long)((var4[12] + 256) % 256) << 24 | (long)((var4[13] + 256) % 256) << 32 | (long)((var4[14] + 256) % 256) << 40 | (long)((var4[15] + 256) % 256) << 48 | (long)((var4[16] + 256) % 256) << 56;
            this.players[0][1] = var4[17];
            this.players[1][1] = var4[18];
            if (this.ha == 0) {
               this.K(88);
            } else if (this.ha == 1) {
               this.K(89);
            } else if (this.ha == 2) {
               this.K(90);
            }
            break;
         case 1003:
            this.players[0][1] = var4[4];
            this.players[1][1] = var4[5];
            if (this.b == 27) {
               this.K(27);
            }
            break;
         case 1004:
            this.x.h[var2][0] = 1;
            if (this.b == 27) {
               this.K(27);
            }
            break;
         case 1011:
            this.A(11, true);
            break;
         case 1012:
         case 1014:
            this.x.h[var2][1] = 1;
            var3 = 1;

            for(int var28 = 0; var28 < 8; ++var28) {
               if (this.x.g[var28] != null && this.x.h[var28][1] == 0) {
                  var3 = 0;
                  break;
               }
            }

            if (var3 != 0) {
               for(int var29 = 0; var29 < 8; ++var29) {
                  this.x.h[var29][1] = 0;
               }

               if (var1 == 1012) {
                  this.B(311, false);
               } else if (var1 == 1014) {
                  this.x.A(64, this.x.j, 1015, 0, (byte[])null);
               }
            }
            break;
         case 1013:
            if ((this.y & 65536) != 0) {
               try {
                  DataInputStream var34 = new DataInputStream(new ByteArrayInputStream(var4));
                  var34.readInt();

                  for(int var27 = 0; var27 < this.gridRows; ++var27) {
                     for(int var17 = 0; var17 < this.gridCols; ++var17) {
                        this.grid[var17][var27] = -1;
                     }
                  }

                  for(int var18 = 0; var18 < this.gridCols * this.gridRows + 2; ++var18) {
                     this.entities[var18][0] = 0;
                  }

                  for(byte var19 = var34.readByte(); var19 != -1; var19 = var34.readByte()) {
                     this.entities[var19][0] = var34.readByte();
                     this.entities[var19][1] = var34.readByte();
                     this.entities[var19][2] = var34.readByte();
                     this.entities[var19][3] = var34.readByte();
                     this.entities[var19][4] = var34.readByte();
                  }
               } catch (Exception var8) {
               }
            }

            this.x.A(0, this.x.j, 1014, 0, (byte[])null);
            break;
         case 1015:
            this.cA = System.currentTimeMillis();
            this.h = false;
            this.L(2);
            break;
         case 1017:
            this.x.h[var2][2] = var4[4];
            var3 = 0;
            var1 = 8;

            while(true) {
               --var1;
               if (var1 < 0) {
                  var2 = (int)this.dA;
                  byte[] var16 = new byte[9];
                  var16[4] = (byte)var3;
                  var16[5] = (byte)(var2 & 255);
                  var16[6] = (byte)(var2 >>> 8 & 255);
                  var16[7] = (byte)(var2 >>> 16 & 255);
                  var16[8] = (byte)(var2 >>> 24 & 255);
                  this.x.A(64, this.x.j, 1018, 5, var16);
                  return;
               }

               if (this.x.g[var1] != null && this.x.h[var1][2] == 1) {
                  ++var3;
               }
            }
         case 1018:
            this.cA = System.currentTimeMillis();
            this.dA = (long)((var4[5] + 256) % 256 | (var4[6] + 256) % 256 << 8 | (var4[7] + 256) % 256 << 16 | (var4[8] + 256) % 256 << 24);
            var1 = (var4[4] != 0) ? 1 : 0;
            if (var1 != 0) {
               this.L(5);
            } else {
               this.L(2);
               this.h = false;
            }
            break;
         case 1019:
            this.h = var4[4] == 1;
            if ((this.y & 65536) != 0 && var3 > 1) {
               this.dA = (long)((var4[5] + 256) % 256 | (var4[6] + 256) % 256 << 8 | (var4[7] + 256) % 256 << 16 | (var4[8] + 256) % 256 << 24);
            }
            break;
         case 1021:
            this.players[1][17] = (var4[4] + 256) % 256 | (var4[5] + 256) % 256 << 8 | (var4[6] + 256) % 256 << 16 | (var4[7] + 256) % 256 << 24;
            break;
         case 1022:
            int var6 = 0;
            if (this.ha != 2) {
               int[] var10000 = this.players[0];
               ++var6;
               var10000[10] = var4[4];
               var10000 = this.players[0];
               ++var6;
               var10000[15] = var4[5];
               this.A(0, this.players[0][10], this.players[0][15], false);
            } else {
               var6 += 2;
            }

            int[] var48 = this.players[1];
            ++var6;
            var48[10] = var4[6];
            var48 = this.players[1];
            ++var6;
            var48[15] = var4[7];
            this.A(1, this.players[1][10], this.players[1][15], false);
            this.playSoundEvent(this.players[1][10]);
            if (this.ha == 2) {
               this.dA = (long)((var4[8] + 256) % 256 | (var4[9] + 256) % 256 << 8 | (var4[10] + 256) % 256 << 16 | (var4[11] + 256) % 256 << 24);
               var6 += 4;
            }

            byte var5 = var4[var6++ + 4];
            int[][] var32 = this.entities;

            for(int var25 = 0; var25 < var5; ++var25) {
               var1 = var4[var6++ + 4];
               var32[var1][7] = var32[var1][0];
               var32[var1][0] = var4[var6++ + 4];
               var32[var1][1] = var4[var6++ + 4];
               var32[var1][2] = var4[var6++ + 4];
               var32[var1][3] = var4[var6++ + 4];
               var32[var1][4] = var4[var6++ + 4];
               switch (var32[var1][0]) {
                  case 0:
                     if (this.entities[var1][8] != 0) {
                        this.sprites.B(this.entities[var1][8]);
                     }
                     break;
                  case 19:
                  case 20:
                     var32[var1][0] = 19;
                     var32[var1][8] = this.createExplosionSprite(var1);
                     break;
                  case 27:
                  case 28:
                     var32[var1][0] = 27;
                     this.U(var1);
               }
            }
            break;
         case 1023:
            this.players[0][3] = (var4[4] + 256) % 256 | (var4[5] + 256) % 256 << 8 | (var4[6] + 256) % 256 << 16 | (var4[7] + 256) % 256 << 24;
            this.players[0][15] = (short)((var4[8] + 256) % 256 | (var4[9] + 256) % 256 << 8);
            this.players[0][4] = var4[10];
            this.players[1][2] = var4[11];
            this.players[1][4] = var4[12];
            this.players[1][5] = var4[13];
            break;
         case 1024:
            var3 = 0;
            int[][] var24 = this.planes;
            var1 = 2;
            this.maxPlanes = var4[4];

            for(this.da = var4[5] == 1; var3 < this.maxPlanes; ++var3) {
               var24[var3][0] = (short)((var4[var1 + 4 + 0] + 256) % 256 | (var4[var1 + 4 + 1] + 256) % 256 << 8);
               var1 += 2;
               var24[var3][1] = var4[var1 + 4];
               ++var1;
               var24[var3][2] = var4[var1 + 4];
               ++var1;
            }
            break;
         case 1030:
            this.L(3);
            break;
         case 1031:
            this.bc = var4[4] != 0;
            var2 = 1;

            for(int var9 = 0; var9 < 10; ++var9) {
               this.yB[var9] = (var4[var2 + 4 + 0] + 256) % 256 | (var4[var2 + 4 + 1] + 256) % 256 << 8 | (var4[var2 + 4 + 2] + 256) % 256 << 16 | (var4[var2 + 4 + 3] + 256) % 256 << 24;
               var2 += 4;
            }

            this.L(10);
      }

   }

   public void B(int var1, boolean var2_) {
      int var2 = var2_ ? 1 : 0;
      if ((var1 & 1024) != 0) {
         this.J(this.b);
         this.K(var1 & 1023);
      } else if ((var1 & 2048) != 0) {
         this.G(var1 & 1023);
      } else if ((var1 & 1023) == 6) {
         this.A(this.b, 0);
         this.f &= -241;
         this.K(this.D());
      } else {
         var2 = var1 & 1023;
         switch (var2) {
            case 1:
               this.destroyApp(true);
               break;
            case 2:
               this.L(2);
               this.A(11, false);
               break;
            case 7:
               this.lb = 0;
               byte[] var29 = new byte[]{(byte)(this.lb & 255), (byte)(this.lb >>> 8 & 255), (byte)(this.lb >>> 16 & 255), (byte)(this.lb >>> 24 & 255)};
               this.A((byte[])var29, 2);
               this.K(5);
               break;
            case 8:
               if (this.ga == 0 && this.ha == 1) {
                  this.JA();
               }

               this.aA = 0;
               this.L(10);
               break;
            case 12:
               if (this.b == 12) {
                  this.rb = true;
                  this.h = false;
                  this.K(11);
                  if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
                     byte[] var28 = new byte[5];
                     var28[4] = 0;
                     this.x.A(0, this.x.j, 1017, 1, var28);
                  }
               } else if (this.ha == 1) {
                  this.aA = 10;
                  this.A(11, true);
               } else if (this.ha == 0) {
               }
               break;
            case 13:
               if (this.ib == 0) {
                  this.players[0][1] = this.ib;
                  this.A(17, false);
               } else if (this.qb[this.ib - 1]) {
                  this.players[0][1] = this.ib;
                  this.A(17, false);
               } else {
                  this.K(87);
               }
               break;
            case 14:
            case 33:
            case 302:
               this.fA = 90L;
               switch (this.s.getSelectedIndex()) {
                  case 0:
                     this.maxPlanes = 2;
                     break;
                  case 1:
                     this.maxPlanes = 5;
                     break;
                  case 2:
                     this.maxPlanes = 9;
                     break;
                  case 3:
                     this.maxPlanes = 9;
                     this.fA = 45L;
               }

               if (this.b == 75) {
                  this.A(27, true);
               } else {
                  this.A(11, true);
               }
               break;
            case 15:
               if (this.b != 48) {
                  if (this.ib == 0) {
                     this.ib = 1;
                  } else if (this.ib == 1) {
                     this.ib = 2;
                  } else if (this.ib == 2) {
                     this.ib = 0;
                  }
               } else if (this.ib == 0) {
                  this.ib = 1;
               } else if (this.ib == 1) {
                  this.ib = 2;
               } else if (this.ib == 2) {
                  this.ib = 0;
               }

               this.MA(this.b);
               break;
            case 16:
            case 17:
               this.jb = var2;
               this.K(47);
               this.G();
               break;
            case 18:
               if (this.jb == 17) {
                  p[1] = (byte)(((Gauge)this.u.get(this.hb)).getValue() * 10);
               } else {
                  p[0] = (byte)(((Gauge)this.u.get(this.hb)).getValue() * 10);
               }

               q.C(p[1]);
               this.K(6);
               this.G();
               break;
            case 21:
               if (this.kb != 0 && this.kb != 1 && this.qb[this.kb]) {
                  if (this.kb == 2) {
                     this.A("fs/MyStuff/Pictures/", "SuperStackAttackSplash.jpg", "/", "s.jpg");
                  } else if (this.kb == 3) {
                     this.A(System.getProperty("com.siemens.mp.systemfolder.ringingtone") + "/", "SuperStackAttackTheme.mid", "/", "s/0.mid");
                  } else if (this.kb == 4) {
                     this.A(System.getProperty("com.siemens.mp.systemfolder.pictures") + "/MMS/", "SuperStackAttackMMS.gif", "/", "m.gif");
                  }
               }

               this.K(39);
               this.kb = -1;
               break;
            case 22:
               if (this.kb != 0 && this.kb != 1) {
                  this.K(54);
               }
               break;
            case 23:
               this.kb = this.s.getSelectedIndex();
               if (this.qb[this.kb]) {
                  if (this.kb != 0 && this.kb != 1) {
                     this.K(53);
                  } else {
                     this.ib = this.kb + 1;
                     this.K(38);
                  }
               } else {
                  this.K(52);
               }
               break;
            case 29:
               this.pb = this.s.getSelectedIndex();
               this.K(62);
               break;
            case 30:
               this.A(11, true);
            case 31:
            case 203:
            case 803:
            default:
               break;
            case 34:
            case 308:
               this.oa = (String)this.na.elementAt(this.nb);

               try {
                  this.vb[0][0] = new Texture2D((Image2D)Loader.load("/" + this.oa + "0" + "portrait_red.png")[0]);
                  this.vb[0][1] = new Texture2D((Image2D)Loader.load("/" + this.oa + "1" + "portrait_red.png")[0]);
                  this.vb[1][0] = new Texture2D((Image2D)Loader.load("/" + this.oa + "0" + "portrait_blue.png")[0]);
                  this.vb[1][1] = new Texture2D((Image2D)Loader.load("/" + this.oa + "1" + "portrait_blue.png")[0]);
                  this.vb[2][0] = new Texture2D((Image2D)Loader.load("/" + this.oa + "0" + "portrait_grn.png")[0]);
                  this.vb[2][1] = new Texture2D((Image2D)Loader.load("/" + this.oa + "1" + "portrait_grn.png")[0]);
               } catch (Exception var10) {
               }

               if (var1 == 34) {
                  if (this.ha == 1) {
                     this.K(16);
                  } else if (this.ha == 0) {
                     this.K(50);
                  }
               } else if (var1 == 308) {
                  if (this.ha == 1) {
                     if ((this.y & 1048576) != 0) {
                        this.K(81);
                     } else {
                        this.K(82);
                     }
                  } else if (this.ha == 0) {
                     if ((this.y & 1048576) != 0) {
                        this.K(70);
                     } else {
                        this.K(27);
                     }
                  } else if (this.ha == 2) {
                     if ((this.y & 1048576) != 0) {
                        this.K(86);
                     } else {
                        this.K(82);
                     }
                  }
               }
               break;
            case 35:
               this.K(50);
               break;
            case 36:
               if (this.ha == 1) {
                  this.K(16);
               } else if (this.ha == 0) {
                  this.K(50);
               }
               break;
            case 37:
            case 309:
               ++this.nb;
               if (this.nb > this.na.size() - 1) {
                  this.nb = 0;
               }

               this.oa = (String)this.na.elementAt(this.nb);
               if ((this.y & 1048576) == 0 && (this.y & 65536) == 0) {
                  this.K(64);
               } else {
                  this.K(76);
               }
               break;
            case 40:
               this.K(this.x.n);
               break;
            case 41:
               this.K(39);
               break;
            case 42:
               this.K(4);
               break;
            case 43:
               this.K(49);
               break;
            case 44:
               this.K(65);
               break;
            case 45:
               switch (this.b) {
                  case 900:
                     this.K(this.lB);
                  case 902:
                     this.K(this.lB);
                     return;
                  case 901:
                  default:
                     return;
                  case 903:
                     this.K(902);
                     return;
                  case 904:
                     this.K(902);
                     return;
               }
            case 46:
               this.K(5);
               break;
            case 47:
               if (this.ha == 1) {
                  if (this.A(10)) {
                     this.K(65);
                  } else if (this.na.size() > 1) {
                     this.K(64);
                  } else {
                     this.K(16);
                  }
               } else if (this.ha == 0) {
                  if (this.na.size() > 1) {
                     this.K(64);
                  } else {
                     this.K(50);
                  }
               }
               break;
            case 48:
               this.K(40);
               break;
            case 49:
               ++this.ob;
               this.ob %= this.sb.size();
               this.K(41);
               break;
            case 50:
               this.K(68);
               break;
            case 51:
               if (this.sb.size() > 0) {
                  try {
                     FileConnection var27 = (FileConnection)Connector.open("file:///" + "fs/MyStuff/Pictures/" + "SuperStackAttack" + "/" + this.sb.elementAt(this.ob));
                     if (var27.exists()) {
                        var27.delete();
                     }

                     var27.close();
                     this.sb.removeElementAt(this.ob);
                  } catch (Exception var9) {
                  }

                  if (this.ob != 0) {
                     --this.ob;
                     if (this.ob < 0) {
                        this.ob += this.sb.size();
                     } else {
                        this.ob %= this.sb.size();
                     }
                  }

                  this.K(41);
               }
               break;
            case 52:
               if (this.iB) {
                  this.K(5);
               } else {
                  this.K(39);
               }
               break;
            case 53:
               if (this.cc == 0) {
                  this.K(4);
               } else {
                  this.cc = 0;
                  if (this.pb + 1 == this.lA.length) {
                     this.K(50);
                  } else {
                     this.K(83);
                  }
               }
               break;
            case 54:
               if ((this.y & 65536) == 0 && (this.y & 1048576) == 0) {
                  this.K(50);
               } else {
                  this.K(4);
               }
               break;
            case 55:
               this.K(this.w);
               break;
            case 56:
               if ((this.y & 1048576) != 0) {
                  if (this.ha == 1) {
                     this.K(85);
                  } else if (this.ha == 0) {
                     this.K(69);
                  } else if (this.ha == 2) {
                     this.K(72);
                  }
               } else if ((this.y & 65536) != 0) {
                  if (this.ha == 1) {
                     this.K(89);
                  } else if (this.ha == 0) {
                     this.K(88);
                  } else if (this.ha == 2) {
                     this.K(90);
                  }
               }
               break;
            case 57:
               this.K(85);
               break;
            case 58:
               Image var26;
               if (p[1] == 0) {
                  p[1] = 20;
                  var26 = this.B("/", "i.p", 1);
               } else {
                  p[1] = 0;
                  var26 = this.B("/", "i.p", 0);
               }

               this.s.set(this.s.getSelectedIndex(), this.s.getString(this.s.getSelectedIndex()), var26);
               break;
            case 59:
               this.K(10);
               break;
            case 60:
               System.arraycopy(p, 0, o, 0, o.length);
               this.A((byte[])o, 1);
               this.K(4);
               break;
            case 61:
               System.arraycopy(o, 0, p, 0, p.length);
               this.K(4);
               break;
            case 200:
               String var25 = this.A();
               if (var25 == "") {
                  this.c[19][0] = E(137);
               } else {
                  this.c[19][0] = var25;
               }

               this.K(19);
               this.y = 1048576;
               break;
            case 201:
               this.c[19][0] = this.B((String)((TextField)this.u.get(0)).getString(), 3);
               if (this.c[19][0] == null) {
                  this.A(19, E(85), E(86));
               } else {
                  this.x.i = this.c[19][0];
                  this.A(this.c[19][0]);
                  this.K(85);
               }
               break;
            case 204:
               this.x.A(32, this.x.j, 1011, 0, (byte[])null);
               this.A(11, true);
               this.h = true;
               break;
            case 205:
               if (this.x == null) {
                  try {
                     this.x = new BluetoothLink(this, this);
                  } catch (Exception var5) {
                  }
               }

               String var24 = this.A();
               if (var24 == "") {
                  this.c[21][0] = E(137);
               } else {
                  this.c[21][0] = var24;
               }

               this.K(21);
               this.y = 65536;
               break;
            case 206:
               if (this.b == 21) {
                  this.c[21][0] = ((TextField)this.u.get(0)).getString();
                  if (this.c[21][0] == null) {
                     this.A(21, E(41), E(86));
                  } else {
                     this.A(this.c[21][0]);
                     this.x.i = this.c[21][0];
                  }
               } else if (this.b == 26) {
                  String var35 = this.x.i;
                  if (this.x != null) {
                     try {
                        this.x.A();
                        this.x = null;
                     } catch (Exception var7) {
                     }
                  }

                  if (this.x == null) {
                     try {
                        this.x = new BluetoothLink(this, this);
                     } catch (Exception var6) {
                     }
                  }

                  this.x.i = var35;
               }

               this.A(23, true);
               break;
            case 207:
               this.aa = this.s.getSelectedIndex();
               this.A(25, true);
               break;
            case 208:
               this.x.A(this.x.b[this.aa], true);
               break;
            case 209:
               this.K(4);
               if (this.x != null) {
                  try {
                     this.x.A();
                     this.x = null;
                  } catch (Exception var8) {
                  }
               }
               break;
            case 210:
               this.A(27, true);
               break;
            case 230:
               this.x.n = this.b;
               if (this.A(this.x.g) > 1) {
                  for(int var23 = 0; var23 < 8; ++var23) {
                     this.x.l[var23] = false;
                  }

                  this.K(29);
               } else {
                  this.A(this.b, "", E(138));
               }
               break;
            case 231:
               this.c[31][0] = (String)this.E().elementAt(this.s.getSelectedIndex());
               this.B(233, false);
               break;
            case 232:
               if (this.x != null) {
                  if (this.b == 33) {
                     if (this.x.D()) {
                        this.K(11);
                        byte[] var22 = new byte[5];
                        var22[4] = 0;
                        this.x.A(0, this.x.j, 1017, 1, var22);
                     } else {
                        this.K(33);
                     }
                  } else if (this.b == 34) {
                     this.x.D();
                     this.B(235, false);
                  }
               } else {
                  this.K(33);
               }
               break;
            case 233:
               if (this.b == 31) {
                  this.c[31][0] = this.B((String)((TextField)this.u.get(0)).getString(), 1);
               }

               if (this.c[31][0] != null) {
                  if (!this.x.o) {
                     this.K(33);
                  } else if (this.x.o) {
                     this.K(34);
                  }
               }
               break;
            case 234:
               int var4 = this.s.getSelectedIndex();
               var1 = 0;
               Image var36 = this.B("/", "i.p", 1);
               Image var33 = this.B("/", "i.p", 0);
               if (this.x != null) {
                  if (this.b != 33 && this.b != 34) {
                     if (this.b == 27 && (this.y & 1048576) != 0) {
                        if (var4 == this.x.j) {
                           return;
                        }

                        this.x.m[var4] = !this.x.m[var4];

                        for(int var34 = 0; var34 < this.s.size(); ++var34) {
                           if (this.x.m[var34]) {
                              ++var1;
                           }
                        }

                        if (var1 > 0) {
                           this.x.m[var4] = false;
                           this.A(27, E(115), E(117) + " " + 0 + ".");
                        } else {
                           this.s.set(var4, this.x.g[var4], this.A(this.x.m[var4], this.players[var4 == 0 ? 0 : 1][1]));
                        }
                     } else if (this.b == 27 && (this.y & 65536) != 0) {
                        return;
                     }
                  } else {
                     this.x.l[var4] = !this.x.l[var4];
                     if (this.x.l[0] && Integer.parseInt(this.x.k[0][1]) == 64) {
                        for(int var21 = 1; var21 < this.s.size(); ++var21) {
                           this.x.l[var21] = false;
                           this.s.set(var21, this.x.k[var21][0], var33);
                        }
                     }

                     this.s.set(var4, this.x.k[var4][0], this.x.l[var4] ? var36 : var33);
                  }
               }
               break;
            case 235:
               if (!this.x.o) {
                  this.K(11);
               } else if (this.x.o) {
                  this.K(27);
               }

               byte[] var19 = new byte[5];
               var19[4] = 0;
               this.x.A(0, this.x.j, 1017, 1, var19);
               break;
            case 236:
               this.K(this.x.n);
               break;
            case 237:
               if (this.x.n == 11) {
                  this.K(11);
               } else if (this.x.n == 27) {
                  this.K(27);
               } else {
                  this.K(this.w);
               }
               break;
            case 240:
               this.z = this.s.getSelectedIndex();
               this.K(36);
               break;
            case 241:
               this.z = -99;
               this.K(37);
               break;
            case 242:
               Vector var18 = this.E();
               var18.removeElementAt(this.z);
               this.A(7, var18);
               this.K(35);
               break;
            case 243:
               Vector var32 = this.E();
               String var17 = ((TextField)this.u.get(0)).getString();
               if (this.z == -99) {
                  var32.addElement(var17);
               } else {
                  var32.setElementAt(var17, this.z);
               }

               this.A(7, var32);
               this.K(35);
               break;
            case 300:
               this.pb = this.s.getSelectedIndex();
               this.K(73);
               break;
            case 301:
               if (this.b == 81) {
                  this.players[0][1] = this.ib;
                  this.K(75);
               } else if (this.b == 82) {
                  this.players[1][1] = this.ib;
                  this.K(27);
               }

               byte[] var16 = new byte[]{0, 0, 0, 0, (byte)this.players[0][1], (byte)this.players[1][1]};
               this.x.A(4160, this.x.j, 1003, 2, var16);
               break;
            case 311:
               try {
                  ByteArrayOutputStream var3 = new ByteArrayOutputStream();
                  DataOutputStream var31 = new DataOutputStream(var3);
                  var31.writeInt(0);

                  for(int var14 = 0; var14 < this.gridCols * this.gridRows + 2; ++var14) {
                     if (this.entities[var14][0] != 0) {
                        var31.writeByte(var14);
                        var31.writeByte(this.entities[var14][0]);
                        var31.writeByte(this.entities[var14][1]);
                        var31.writeByte(this.entities[var14][2]);
                        var31.writeByte(this.entities[var14][3]);
                        var31.writeByte(this.entities[var14][4]);
                     }
                  }

                  var31.writeByte(-1);
                  byte[] var15 = var3.toByteArray();
                  this.x.A(64, this.x.j, 1013, var15.length - 4, var15);
               } catch (Exception var11) {
                  ((Throwable)var11).printStackTrace();
               }
               break;
            case 312:
               switch (this.s.getSelectedIndex()) {
                  case 0:
                     this.eA = 120000L;
                     break;
                  case 1:
                     this.eA = 300000L;
                     break;
                  case 2:
                     this.eA = 600000L;
               }

               this.A(27, true);
               break;
            case 313:
               this.ha = 1;
               this.pb = 99;
               this.K(81);
               break;
            case 800:
               this.K(this.oB);
               break;
            case 801:
               switch (this.b) {
                  case 800:
                     if (((TextField)this.u.get(1)).getString().length() != 0) {
                        this.A(806, true);
                     }

                     return;
                  case 801:
                     this.A(802, true);
                     return;
                  default:
                     return;
               }
            case 802:
               this.oB = this.b;
               this.K(800);
               break;
            case 805:
               this.K(803);
               break;
            case 901:
               switch (this.b) {
                  case 902:
                     this.K(904);
                     return;
                  case 903:
                     this.K(904);
                     return;
                  case 904:
                     this.K(905);
                     return;
                  case 905:
                     this.A(906, true);
                     return;
                  case 906:
                     this.K(this.lB);
                     return;
                  default:
                     return;
               }
            case 902:
               this.lB = this.b;

               for(int var13 = 0; var13 < this.mB.length; ++var13) {
                  this.mB[var13] = "";
               }

               this.kB.C(1);
               this.K(902);
               break;
            case 903:
               this.lB = this.b;

               for(int var12 = 0; var12 < this.mB.length; ++var12) {
                  this.mB[var12] = "";
               }

               this.kB.C(2);
               this.K(902);
               break;
            case 904:
               this.K(902);
               break;
            case 905:
               this.K(this.lB);
         }

      }
   }

   public short[] A(InputStream var1) throws Exception {
      byte[] var4 = new byte[2];
      var1.read(var4, 0, 2);
      short var3 = (short)(var4[0] << 8 & '\uff00' | var4[1] & 255);
      short[] var2 = new short[var3];

      for(int var5 = 0; var5 < var3; ++var5) {
         var1.read(var4, 0, 2);
         var2[var5] = (short)(var4[0] << 8 & '\uff00' | var4[1] & 255);
      }

      return var2;
   }

   public byte[] A(InputStream var1, int var2) throws Exception {
      short[] var3 = this.A(var1);

      int var4;
      for(var4 = 0; var4 < var2 && var4 < var3.length; ++var4) {
         var1.skip((long)var3[var4]);
      }

      if (var4 == var2) {
         var2 = var3[var4];
         if (var2 > 0) {
            byte[] var5 = new byte[var2];
            var1.read(var5, 0, var2);
            return var5;
         }
      }

      return null;
   }

   byte[] A(String var1, String var2, int var3) {
      if (var1.compareTo(this.tB) != 0 || this.sB == null || var3 < this.vB) {
         this.I();

         try {
            this.sB = this.getClass().getResourceAsStream(var1 + var2);
            this.uB = this.A(this.sB);
            this.tB = var1;
            this.vB = 0;
         } catch (Exception var4) {
            this.I();
         }
      }

      try {
         while(this.vB < var3 && this.vB < this.uB.length) {
            this.sB.skip((long)this.uB[this.vB]);
            ++this.vB;
         }

         if (this.vB == var3) {
            short var7 = this.uB[this.vB];
            if (var7 > 0) {
               byte[] var6 = new byte[var7];
               this.sB.read(var6, 0, var7);
               ++this.vB;
               return var6;
            }
         }
      } catch (Exception var5) {
         this.I();
      }

      return null;
   }

   Image B(String var1, String var2, int var3) {
      byte[] var4 = this.A(var1, var2, var3);
      return var4 != null ? Image.createImage(var4, 0, var4.length) : null;
   }

   void I() {
      if (this.sB != null) {
         try {
            this.sB.close();
         } catch (Exception var1) {
         }
      }

      this.sB = null;
      this.uB = null;
      this.tB = "";
      this.vB = 0;
   }

   private void J() {
      switch (this.n) {
         case 1:
            this.cA = System.currentTimeMillis();
            this.zB = false;
            ++this.n;
            if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
               int var2 = 0;

               for(int var3 = 0; var3 < 8; ++var3) {
                  if (this.x.g[var3] != null) {
                     ++var2;
                  }
               }

               if (var2 < 2) {
                  if ((this.y & 1048576) != 0) {
                     this.L(3);
                  } else {
                     this.K(4);
                  }
               }
            }
            break;
         case 2:
            this.zB = false;
            this.h = false;
            if (this.i != null) {
               this.i.i = 0;
            }
            break;
         case 3:
            this.zB = true;
            this.h = true;
            q.A(2);
            if (this.ga == 0 && this.ha == 1 && (this.y & 1048576) == 0 && (this.y & 65536) == 0) {
               if (this.players[0][3] > this.lb) {
                  this.sprites.A(this, "" + this.players[this.nA][3]);
                  q.A(1);
                  this.lb = this.players[0][3];
                  byte[] var1 = new byte[]{(byte)(this.lb & 255), (byte)(this.lb >>> 8 & 255), (byte)(this.lb >>> 16 & 255), (byte)(this.lb >>> 24 & 255)};
                  this.A((byte[])var1, 2);
                  if (this.lb >= 500) {
                     this.qb[0] = true;
                  }

                  if (this.lb >= 1500) {
                     this.qb[1] = true;
                  }

                  if (this.lb >= 1000) {
                     this.qb[2] = true;
                  }

                  if (this.lb >= 2000) {
                     this.qb[3] = true;
                  }

                  if (this.lb >= 4000) {
                     this.qb[4] = true;
                  }

                  this.A((boolean[])this.qb, 3);
               }

               this.B(10);
            }

            if ((this.y & 1048576) != 0) {
               this.x.A(32, this.x.j, 1030, 0, (byte[])null);
               this.ba = true;
            }

            this.xB = this.players[0][3];
            this.yB = this.stats[0];
            this.wB = 75;
            break;
         case 10:
            this.sprites.B();
            this.i.e = false;
            this.i.d = false;
            this.grid2 = (int[][])null;
            this.grid = (int[][])null;
            this.marks = (byte[][])null;
            this.za = 0;
            this.eA = 0L;
            this.sprites.A(this.sA[0]);
            this.sA[0] = -1;
            this.sprites.B(this.uA[0]);
            this.uA[0] = -1;
            this.sprites.A(this.sA[5]);
            this.sA[5] = -1;
            this.sprites.B(this.xA);
            this.xA = -1;
            this.sprites.A(this.sA[1]);
            this.sA[1] = -1;
            this.sprites.B(this.yA);
            this.yA = -1;
            this.sprites.B(this.zA);
            this.zA = -1;
            this.sprites.A(this.sA[2]);
            this.sA[2] = -1;
            this.sprites.A(this.sA[3]);
            this.sA[3] = -1;
            this.sprites.B(this.tA[0]);
            this.tA[0] = -1;
            this.sprites.B(this.tA[1]);
            this.tA[1] = -1;
            this.sprites.B(this.tA[2]);
            this.tA[2] = -1;
            this.sprites.B(this.tA[3]);
            this.tA[3] = -1;
            this.sprites.A(this.sA[7]);
            this.sA[7] = -1;
            this.sprites.B(this.tA[4]);
            this.tA[4] = -1;
            this.sprites.B(this.tA[5]);
            this.tA[5] = -1;
            this.sprites.A(this.sA[4]);
            this.sA[4] = -1;
            this.sprites.B(this.tA[6]);
            this.tA[6] = -1;
            this.sprites.A(this.sA[9]);
            this.sA[9] = -1;
            this.sprites.B(this.tA[8]);
            this.tA[8] = -1;
            this.sprites.A(this.vA[0]);
            this.vA[0] = -1;
            this.sprites.B(this.wA[0]);
            this.wA[0] = -1;
            this.sprites.A(this.vA[1]);
            this.vA[1] = -1;
            this.sprites.B(this.wA[1]);
            this.wA[1] = -1;
            this.sprites.A(this.vA[2]);
            this.vA[2] = -1;
            this.sprites.B(this.wA[2]);
            this.wA[2] = -1;
            this.sprites.A(this.vA[3]);
            this.vA[3] = -1;
            this.sprites.B(this.wA[3]);
            this.wA[3] = -1;
            this.sprites.A(this.vA[5]);
            this.vA[5] = -1;
            this.sprites.B(this.wA[4]);
            this.wA[4] = -1;
            this.sprites.B(this.wA[5]);
            this.wA[5] = -1;
            this.sprites.A(this.vA[6]);
            this.sprites.B(this.wA[6]);
            this.wA[6] = -1;
            this.sprites.A(this.vA[7]);
            this.vA[7] = -1;
            this.sprites.B(this.wA[7]);
            this.wA[7] = -1;
            System.gc();
            if (this.zB) {
               this.K(79);
            } else if (this.ga == 0 && this.ha == 0) {
               this.K(83);
            } else {
               this.K(4);
            }
      }

   }

   private void K() {
   }

   public synchronized void L() {
      switch (this.b) {
         case 11:
            this.tickGame();
            this.N();
            break;
         case 25:
            this.K(13);
            this.B(208, false);
      }

   }

   public synchronized void M(int var1) {
      switch (this.b) {
         case 1:
         case 2:
         case 3:
            this.K(4);
            break;
         case 11:
            switch (this.n) {
               case 2:
               case 5:
                  switch (var1) {
                     case -11:
                        this.rb = false;
                        this.h = true;
                        this.K(12);
                        return;
                     case -7:
                        this.h = true;
                        this.rb = false;
                        this.K(12);
                        return;
                     case -6:
                        if (this.y != 0) {
                           if (this.A(this.x.g) > 1) {
                              for(int var8 = 0; var8 < 8; ++var8) {
                                 this.x.l[var8] = false;
                              }

                              byte[] var9 = new byte[5];
                              var9[4] = 1;
                              this.x.A(0, this.x.j, 1017, 1, var9);
                              this.B(230, false);
                           } else {
                              this.A(11, "", E(138));
                           }

                           return;
                        }

                        return;
                     case 35:
                        this.h = !this.h;
                        if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
                           byte[] var10 = new byte[9];
                           var1 = (int)this.dA;
                           var10[4] = (byte)(this.h ? 1 : 0);
                           var10[5] = (byte)(var1 & 255);
                           var10[6] = (byte)(var1 >>> 8 & 255);
                           var10[7] = (byte)(var1 >>> 16 & 255);
                           var10[8] = (byte)(var1 >>> 24 & 255);
                           this.x.A(4160, this.x.j, 1019, 5, var10);
                        }

                        return;
                     case 42:
                        Date var3 = new Date();
                        String var2 = var3.toString();
                        String var4 = var2.substring(4, 19);
                        var4 = var4.replace(' ', '_');
                        var4 = var4.replace(':', '_');
                        this.sprites.A(this, var4);
                        this.bA = true;
                        return;
                     default:
                        return;
                  }
               case 3:
                  this.wB = 0;
                  return;
               case 4:
               default:
                  return;
            }
         case 12:
            this.h = false;
            break;
         case 16:
         case 38:
         case 48:
         case 51:
         case 74:
         case 81:
         case 82:
            switch (var1) {
               case -11:
                  switch (this.b) {
                     case 16:
                        this.K(63);
                        return;
                     case 38:
                        this.K(39);
                        return;
                     case 48:
                        this.B(6, true);
                        return;
                     case 51:
                        this.B(13, false);
                        return;
                     case 74:
                     case 81:
                     case 82:
                        this.B(6, true);
                        return;
                     default:
                        return;
                  }
               case -7:
               case -5:
               case 53:
                  switch (this.b) {
                     case 16:
                     case 51:
                        this.B(13, false);
                        return;
                     case 38:
                        this.B(41, false);
                        return;
                     case 48:
                        this.B(6, true);
                        return;
                     case 74:
                     case 81:
                     case 82:
                        this.B(301, false);
                        return;
                     default:
                        return;
                  }
               case -4:
               case -3:
                  switch (this.b) {
                     case 16:
                     case 48:
                     case 51:
                     case 74:
                     case 81:
                     case 82:
                        this.NA(var1);
                        this.MA(this.b);
                     case 38:
                  }
            }
      }

   }

   public synchronized void N(int var1) {
      switch (this.b) {
         case 11:
         default:
      }
   }

   public void O(int var1) {
      int[] var10000 = null;
      int[][] var3;
      if (this.ha == 2 && this.nA == 0) {
         var3 = this.kA;
      } else {
         var3 = this.jA;
      }

      if (!this.h) {
         for(int var2 = 0; var2 < 32; ++var2) {
            if ((this.players[this.nA][17] & 1 << var2) != 0 && var3[var2][0] != var1) {
               var10000 = this.players[this.nA];
               var10000[18] |= 1 << var2;
            }
         }

         for(int var4 = 0; var4 < var3.length; ++var4) {
            if (var3[var4][0] == var1) {
               var10000 = this.players[this.nA];
               var10000[17] |= 1 << var4;
               break;
            }
         }
      }

   }

   private void M() {
      int var1 = this.i.A();
      this.O(var1);
   }

   public void P(int var1) {
      int[][] var10000 = (int[][])null;
      int[][] var3;
      if (this.ha == 2 && var1 == 0) {
         var3 = this.kA;
      } else {
         var3 = this.jA;
      }

      if (this.players[var1][17] != 0) {
         for(int var2 = 0; var2 < 32; ++var2) {
            if ((this.players[var1][17] & 1 << var2) != 0) {
               if (var3[var2][3] == 0) {
                  this.K(var1, var3[var2][1]);
               } else if (var3[var2][3] > 0) {
                  int var10002 = var3[var2][3]--;
               }
            }
         }

      }
   }

   private void N() {
      if (this.rb) {
         if (!this.ea) {
            this.ea = true;
            switch (this.b) {
               case 11:
                  switch (this.n) {
                     case 2:
                     case 5:
                        this.sprites.D(40703);
                        this.U();
                        int[] var9 = this.players[this.nA];
                        int var7 = var9[0];
                        if (var9[1] != 3) {
                           this.xa = this.va + (this.entities[var7][1] * 8 - this.entities[var7][3]) * 3;
                        } else {
                           this.xa = var9[15];
                        }

                        this.ya = -(160 - (this.ta >> 1));
                        this.xa += 8;
                        this.xa -= 120;
                        if (this.xa < 0) {
                           this.xa = 0;
                        } else if (this.xa + 240 > this.sa) {
                           this.xa = this.sa - 240;
                        }

                        this.sprites.A(this.xa, this.ya, 0);
                        this.B(this.xa, this.ya);
                        this.sprites.E(this.tA[4]);
                        this.sprites.E(this.tA[5]);
                        this.sprites.E(this.tA[6]);
                        if (this.players[0][1] == 3) {
                           this.O();
                        }

                        for(int var10 = 0; var10 < this.entities.length; ++var10) {
                           var7 = this.entities[var10][0];
                           if (var7 != 0) {
                              if (var7 == 1) {
                                 this.Q(var10);
                                 this.A(var10, this.entities[var10][1], this.entities[var10][2]);
                              } else if (var7 >= 27 && var7 < 35) {
                                 this.R(var10);
                                 this.A(var10, this.entities[var10][1], this.entities[var10][2]);
                              } else if (var7 >= 19 && var7 < 27) {
                                 this.drawExplosion(var10);
                                 this.A(var10, this.entities[var10][1], this.entities[var10][2]);
                              } else {
                                 this.drawBox(var10);
                                 this.A(var10, this.entities[var10][1], this.entities[var10][2]);
                              }
                           }
                        }

                        this.Q();
                        if (this.players[0][1] != 3) {
                           this.P();
                        }

                        this.R();
                        if (this.bA) {
                           this.W();
                        }

                        if (this.h || this.n == 5) {
                           this.V();
                        }
                        break;
                     case 3:
                        String var1;
                        if (this.ga == 0 && this.ha == 0) {
                           if (this.bc) {
                              var1 = "Mission erfolgreich!";
                           } else {
                              var1 = "Mission gescheitert!";
                           }
                        } else {
                           var1 = E(67);
                        }

                        String[] var4 = A((String)var1, (Font)this.gA, 240);
                        int var5 = var4.length * this.gA.getHeight();
                        if (var4.length > 1) {
                           var5 += (var4.length - 1) * (this.gA.getHeight() / 2);
                        }

                        int var3 = 160 - var5 / 2;
                        this.sprites.a.setFont(this.gA);

                        for(int var2 = 0; var2 < var4.length; ++var2) {
                           String var6 = var4[var2];
                           this.sprites.a.setColor(16777215);
                           this.sprites.a.drawString(var6, 121, var3 + 1, 17);
                           this.sprites.a.setColor(0);
                           this.sprites.a.drawString(var6, 120, var3, 17);
                           var3 += this.gA.getHeight();
                        }
                     case 200:
                  }
               default:
                  this.ea = false;
            }
         }
      }
   }

   private void B(int var1, int var2) {
      SpriteState var4 = this.sprites.d[this.tA[0]];
      SpriteSheet var3 = this.sprites.c[var4.a];
      this.sprites.E(this.tA[0]);
      if (var4.b + this.sprites.D(var3) < this.sa) {
         var4.b += this.sprites.D(var3);
         this.sprites.E(this.tA[0]);
      }

   }

   private void O() {
      SpriteState var2 = this.sprites.d[this.xA];
      var2.c = 49;
      var2.b = 0 + this.players[0][15];
      SpriteState var1 = this.sprites.d[this.yA];
      var1.c = 80;
      var2.f = 1;
      if (this.players[0][4] != 0) {
         var2.f = 0;
         var1.b = var2.b + 3 - 1;
         var1.d = this.ab[this.players[0][4]][0];
         var1.e = this.ab[this.players[0][4]][1];
         var1.f = this.ab[this.players[0][4]][2];
         this.sprites.E(this.yA);
      }

      this.sprites.E(this.xA);
   }

   private void P() {
      SpriteState var4 = this.sprites.d[this.xA];
      var4.c = 49;
      SpriteState var3 = this.sprites.d[this.yA];
      var3.c = 80;

      for(int var2 = 0; var2 < this.maxPlanes; ++var2) {
         if (this.planes[var2][1] != 0) {
            int var1 = 0 + this.planes[var2][0];
            var4.b = var1;
            var4.f = 1;
            if (this.planes[var2][2] != 0) {
               var4.f = 0;
               var3.b = var1 + 3 - 1;
               int[] var5 = this.ab[this.planes[var2][2]];
               var3.d = var5[0];
               var3.e = var5[1];
               var3.f = var5[2];
               this.sprites.E(this.yA);
            }

            this.sprites.E(this.xA);
         }
      }

   }

   private void Q(int var1) {
      int[] var2 = this.entities[var1];
      int var3 = this.va + (var2[1] * 8 - var2[3]) * 3;
      int var6 = this.wa - ((var2[2] + 1) * 8 - var2[4]) * 3;
      int var4 = this.playerOfEntity(var1);
      SpriteState var5 = this.sprites.d[this.uA[var4]];
      var5.b = var3;
      var5.c = var6 - 24;
      this.sprites.E(this.uA[var4]);
      if (!this.h) {
         ++var5.f;
         if (var5.f >= var5.g) {
            this.A(var4, this.players[var4][10], this.players[var4][15], false);
         }
      }

   }

   private void Q() {
      if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
         if (this.players[this.nA][1] == 3) {
            return;
         }

         int var1 = this.players[this.nA][0];
         int[] var4 = this.entities[var1];
         int var3 = this.va + (var4[1] * 8 - var4[3]) * 3;
         int var2 = this.wa - ((var4[2] + 1) * 8 - var4[4]) * 3;
         SpriteState var5 = this.sprites.d[this.tA[8]];
         var5.b = var3;
         var5.c = var2 - 48;
         var5.c -= 24;
         this.sprites.E(this.tA[8]);
      }

   }

   private void R(int var1) {
      int[] var2 = this.entities[var1];
      int var3 = this.va + (var2[1] * 8 - var2[3]) * 3;
      int var7 = this.wa - ((var2[2] + 1) * 8 - var2[4]) * 3;
      var1 = this.playerOfEntity(var1);
      int var4 = this.uA[var1];
      SpriteState var6 = this.sprites.d[var4];
      var6.b = var3;
      var6.c = var7 - 24;
      this.sprites.E(var4);
      ++var6.f;
   }

   /** Draws one box entity. */
   private void drawBox(int var1) {
      int[] var5 = this.entities[var1];
      int var4 = this.va + (var5[1] * 8 - var5[3]) * 3;
      int var3 = this.wa - ((var5[2] + 1) * 8 - var5[4]) * 3;
      int var6 = var5[0];
      int[] var2 = this.ab[var6];
      SpriteState var7 = this.sprites.d[this.yA];
      var7.b = var4;
      var7.c = var3;
      var7.d = var2[0];
      var7.e = var2[1];
      var7.f = var2[2];
      var7.h = 1;
      this.sprites.E(this.yA);
   }

   /** Draws one explosion animation frame. */
   private void drawExplosion(int var1) {
      int var3;
      int[] var6 = this.entities[var1];
      int var5 = this.va + (var6[1] * 8 - var6[3]) * 3;
      int var4 = this.wa - ((var6[2] + 1) * 8 - var6[4]) * 3;
      var3 = var6[8];
      SpriteState var2 = this.sprites.d[var3];
      var2.b = var5;
      var2.c = var4;
      var4 = var6[7];
      var2.f = var6[0] - 19;
      label21:
      switch (var4) {
         case 1:
            var1 = this.playerOfEntity(var1);
            switch (this.players[var1][1]) {
               case 0:
                  var2.d = 1;
                  break label21;
               case 1:
                  var2.d = 3;
                  break label21;
               case 2:
                  var2.d = 2;
               default:
                  break label21;
            }
         case 2:
         default:
            var2.d = 3;
            break;
         case 3:
         case 8:
            var2.d = 0;
            break;
         case 4:
         case 9:
            var2.d = 1;
            break;
         case 5:
         case 10:
            var2.d = 2;
            break;
         case 6:
         case 11:
            var2.d = 3;
            break;
         case 7:
         case 12:
            var2.d = 4;
            break;
         case 13:
         case 14:
         case 15:
         case 16:
         case 17:
         case 18:
            var2.d = 0;
      }

      this.sprites.E(var3);
   }

   private void R() {
      int var4 = this.wA[1];
      SpriteState var3 = this.sprites.d[var4];
      int var2 = this.sprites.D(this.sprites.c[this.vA[1]]);
      var3.b = 0;
      var3.f = 0;
      this.sprites.E(var4);

      int var1;
      for(var1 = 240 - var3.b - 36; var1 >= 0; var1 -= var2) {
         var3.b += var2;
         var3.f = 1;
         this.sprites.E(var4);
      }

      int var6 = this.wA[2];
      SpriteState var5 = this.sprites.d[var6];
      var4 = this.sprites.D(this.sprites.c[this.vA[2]]);
      var5.f = 2;
      var5.b = 240 - var4;
      this.sprites.E(var6);
      int var10000 = var1 - var4;
      var2 = 0;
      var1 = 3;
      if (this.gridCols == 10) {
         var1 = 2;
      }

      while(var2 < var1) {
         var5.f = 1;
         var5.b -= var4;
         this.sprites.E(var6);
         ++var2;
      }

      if (this.gridCols == 10) {
         var5.b += 10;
      } else {
         var5.b += 3;
      }

      var5.f = 0;
      var5.b -= var4;
      this.sprites.E(var6);
      if (this.gridCols == 10) {
         this.sprites.a.drawRGB(this.eb, 0, this.cb, var5.b - ((16 - this.gridCols >> 1) * 3 + 1) + 6, var5.c + 13, this.cb, this.db, true);
      } else {
         this.sprites.a.drawRGB(this.eb, 0, this.cb, var5.b + 6, var5.c + 13, this.cb, this.db, true);
      }

      int var31 = this.players[this.nA][4];
      if (var31 != 0) {
         var1 = 1;
         if (this.players[this.nA][5] > 0 && this.players[this.nA][5] % 5 == 1) {
            var1 = 0;
         }

         if (var1 != 0) {
            var2 = this.wA[5];
            SpriteState var12 = this.sprites.d[var2];
            var12.d = this.ab[var31][0];
            var12.e = this.ab[var31][1];
            var12.f = this.ab[var31][2];
            this.sprites.E(var2);
         }
      }

      if (this.ha != 2) {
         int var38 = this.wA[7];
         SpriteState var36 = this.sprites.d[var38];
         var31 = this.sprites.D(this.sprites.c[var36.a]);
         var2 = this.players[0][3];
         var1 = 0;
         if (var2 >= 1000000) {
            var1 = var2 / 1000000 % 10;
         }

         var36.b = 50;
         var36.f = var1;
         this.sprites.E(var38);
         var1 = 0;
         if (var2 >= 100000) {
            var1 = var2 / 100000 % 10;
         }

         var36.b += var31;
         var36.f = var1;
         this.sprites.E(var38);
         var1 = 0;
         if (var2 >= 10000) {
            var1 = var2 / 10000 % 10;
         }

         var36.b += var31;
         var36.f = var1;
         this.sprites.E(var38);
         var1 = 0;
         if (var2 >= 1000) {
            var1 = var2 / 1000 % 10;
         }

         var36.b += var31;
         var36.f = var1;
         this.sprites.E(var38);
         var1 = 0;
         if (var2 >= 100) {
            var1 = var2 / 100 % 10;
         }

         var36.b += var31;
         var36.f = var1;
         this.sprites.E(var38);
         var1 = 0;
         if (var2 >= 10) {
            var1 = var2 / 10 % 10;
         }

         var36.b += var31;
         var36.f = var1;
         this.sprites.E(var38);
         var1 = var2 % 10;
         var36.b += var31;
         var36.f = var1;
         this.sprites.E(var38);
      }

      var31 = this.wA[3];
      SpriteState var29 = this.sprites.d[var31];

      for(int var20 = 0; var20 < this.players[this.nA][2]; ++var20) {
         var29.b = 50 + 20 * var20;
         var29.c = 32;
         this.sprites.E(var31);
      }

      var1 = 0;
      if (this.za == 6) {
         var1 = 1;
      } else if (this.ha == 2) {
         var1 = 1;
      }

      if (var1 != 0) {
         int var7 = this.wA[0];
         SpriteState var40 = this.sprites.d[var7];
         var40.b = 44;
         var40.c = 38;
         int var39 = this.sprites.D(this.sprites.c[this.vA[0]]) + 1;
         long var22 = this.eA - this.dA;
         long var8 = var22 / 1000L;
         int var23 = (int)(var8 % 60L);
         var4 = var23 / 10;
         var31 = (int)(var8 % 10L);
         long var24 = var8 - (long)var23;
         var8 = var24 % 59L;
         int var30 = (int)(var8 / 10L);
         int var25 = (int)var8 % 10;
         var40.f = var30;
         this.sprites.E(var7);
         var40.b += var39;
         var40.f = var25;
         this.sprites.E(var7);
         var40.b += var39;
         var40.f = 10;
         this.sprites.E(var7);
         var40.b += 5;
         var40.f = var4;
         this.sprites.E(var7);
         var40.b += var39;
         var40.f = var31;
         this.sprites.E(var7);
      }

   }

   public synchronized void A(Graphics var1) {
      if (!this.fa) {
         this.fa = true;
         switch (this.b) {
            case 1:
               try {
                  var1.drawImage(Image.createImage("/s.jpg"), 120, 160, 3);
                  Image var11 = this.B("/", "i.p", 16);
                  var1.setColor(16777215);
                  var1.fillRect(0, 0, 240, 320);
                  var1.drawImage(var11, 120, 160, 3);
                  var1.setColor(0);
                  var1.fillTriangle(230, 312, 236, 312, 233, 317);
               } catch (Exception var5) {
               }
               break;
            case 2:
               try {
                  var1.setColor(16777215);
                  var1.fillRect(0, 0, 240, 320);
                  Image var10 = this.B("/", "i.p", 10);
                  var1.drawImage(var10, 120, 160, 3);
                  var1.setColor(0);
                  var1.fillTriangle(230, 312, 236, 312, 233, 317);
               } catch (Exception var4) {
               }
               break;
            case 3:
               try {
                  var1.setColor(0);
                  var1.fillRect(0, 0, 240, 320);
                  Image var9 = Image.createImage("/s.jpg");
                  var1.drawImage(var9, 120, 160, 3);
                  var1.setColor(16777215);
                  var1.fillTriangle(230, 312, 236, 312, 233, 317);
               } catch (Exception var3) {
               }
            case 11:
            default:
               break;
            case 13:
            case 20:
            case 22:
            case 25:
               var1.setColor(0);
               var1.fillRect(0, 0, 240, 320);
               var1.setColor(16777215);
               this.dB.animate(this.cB);
               this.cB += 120;
               if (this.cB > 3840) {
                  this.cB = 0;
               }

               this.hB.bindTarget(var1);
               this.hB.render(this.dB);
               this.hB.releaseTarget();
               String var8 = E(148);
               var1.setColor(16777215);
               var1.drawString(var8, 120 - Font.getDefaultFont().stringWidth(var8) / 2, 0 + Font.getDefaultFont().getHeight(), 0);
               break;
            case 16:
            case 38:
            case 48:
            case 51:
            case 74:
            case 81:
            case 82:
               var1.setColor(0);
               var1.fillRect(0, 0, 240, 320);
               var1.fillRect(0, 0, 240, 320);
               var1.setColor(16777215);
               this.B(var1);
               var1.setColor(0);
               var1.fillRect(0, 0, 240, 40);
               var1.setColor(16777215);
               var1.drawString(this.bB[this.zb], 5, 10, 0);
               int var7 = Font.getDefaultFont().getHeight();
               var1.drawString(this.bB[(this.zb + 1) % this.bB.length], 5, 10 + var7, 0);
               break;
            case 802:
            case 806:
               String var6 = E(148);
               var1.setColor(16777215);
               var1.fillRect(0, 0, 240, 320);
               var1.setColor(0);
               var1.drawString(var6, 160 - Font.getDefaultFont().stringWidth(var6) / 2, 120 - Font.getDefaultFont().getHeight() / 2, 20);
               break;
            case 906:
               String var2 = E(148);
               var1.setColor(16777215);
               var1.fillRect(0, 0, 240, 320);
               var1.setColor(0);
               var1.drawString(var2, 160 - Font.getDefaultFont().stringWidth(var2) / 2, 120 - Font.getDefaultFont().getHeight() / 2, 20);
         }

         this.fa = false;
      }
   }

   // ============================================================
   // GAME TICK: one logic step per frame
   // ============================================================

   /** One logic step per frame: player update, per-entity physics and explosion animation, match/row-clear checks, then plane spawning. */
   private void tickGame() {
      if (this.n != 5) {
         if (this.n == 3 && (this.y & 65536) == 0) {
            --this.wB;
            if (this.wB <= 0) {
               this.L(10);
               if ((this.y & 1048576) != 0) {
                  byte[] var3 = new byte[45];
                  var3[4] = (byte)(this.bc ? 1 : 0);
                  int var2 = 1;

                  for(int var1 = 0; var1 < 10; ++var1) {
                     var3[var2 + 4 + 0] = (byte)(this.stats[0][var1] & 255);
                     var3[var2 + 4 + 1] = (byte)(this.stats[0][var1] >>> 8 & 255);
                     var3[var2 + 4 + 2] = (byte)(this.stats[0][var1] >>> 16 & 255);
                     var3[var2 + 4 + 3] = (byte)(this.stats[0][var1] >>> 24 & 255);
                     var2 += 4;
                  }

                  this.x.A(32, this.x.j, 1031, 41, var3);
               }
            }
         }

         if (!this.h && this.n != 5) {
            this.M();
            if ((this.y & 65536) != 0) {
               if (this.players[this.nA][17] != 0) {
                  byte[] var16 = new byte[8];
                  var16[4] = (byte)(this.players[this.nA][17] & 255);
                  var16[5] = (byte)(this.players[this.nA][17] >>> 8 & 255);
                  var16[6] = (byte)(this.players[this.nA][17] >>> 16 & 255);
                  var16[7] = (byte)(this.players[this.nA][17] >>> 24 & 255);
                  this.x.A(0, this.x.j, 1021, 4, var16);
                  this.players[this.nA][18] = 0;
               }

               this.players[this.nA][17] = 0;
               int[][] var24 = this.entities;

               for(int var17 = 0; var17 < this.gridCols * this.gridRows + 2; ++var17) {
                  if (var24[var17][0] != 0) {
                     this.settleEntity(var17);
                     if (var24[var17][0] >= 19 && var24[var17][0] < 26 || var24[var17][0] >= 27 && var24[var17][0] < 34) {
                        int var38 = var24[var17][0]++;
                     }
                  }
               }

               if (!this.da) {
                  for(int var18 = 0; var18 < this.maxPlanes; ++var18) {
                     if (this.planes[var18][1] == 1) {
                        int[] var10000 = this.planes[var18];
                        var10000[0] -= 2;
                     } else if (this.planes[var18][1] == 2) {
                        int[] var35 = this.planes[var18];
                        var35[0] += 2;
                     }
                  }
               }

               if (!this.h) {
                  this.dA += System.currentTimeMillis() - this.cA;
               }

               this.cA = System.currentTimeMillis();
            } else {
               this.P(0);
               this.players[0][17] = 0;
               if ((this.y & 1048576) != 0) {
                  this.P(1);
                  this.players[1][17] = 0;
                  int var6 = 0;

                  for(int var19 = 0; var19 < this.gridCols * this.gridRows + 2; ++var19) {
                     if (this.entities[var19][9] == 1) {
                        ++var6;
                     }
                  }

                  if (var6 > 0 || this.players[0][19] == 1 || this.players[1][19] == 1) {
                     int var5 = var6 * 6 + (this.ha == 2 ? 9 : 5);
                     int var4 = 0;
                     byte[] var25 = new byte[var5 + 4];
                     ++var4;
                     var25[4] = (byte)this.players[0][10];
                     ++var4;
                     var25[5] = (byte)this.players[0][15];
                     ++var4;
                     var25[6] = (byte)this.players[1][10];
                     ++var4;
                     var25[7] = (byte)this.players[1][15];
                     this.players[0][19] = 0;
                     this.players[1][19] = 0;
                     if (this.ha == 2) {
                        int var20 = (int)this.dA;
                        var25[8] = (byte)(var20 & 255);
                        var25[9] = (byte)(var20 >>> 8 & 255);
                        var25[10] = (byte)(var20 >>> 16 & 255);
                        var25[11] = (byte)(var20 >>> 24 & 255);
                        var4 += 4;
                     }

                     int[][] var21 = this.entities;
                     if (var6 > 0) {
                        var25[var4++ + 4 + 0] = (byte)var6;

                        for(int var7 = 0; var7 < this.gridCols * this.gridRows + 2; ++var7) {
                           if (this.entities[var7][9] == 1) {
                              var25[var4 + 0 + 4 + 0] = (byte)var7;
                              var25[var4 + 1 + 4 + 0] = (byte)var21[var7][0];
                              var25[var4 + 2 + 4 + 0] = (byte)var21[var7][1];
                              var25[var4 + 3 + 4 + 0] = (byte)var21[var7][2];
                              var25[var4 + 4 + 4 + 0] = (byte)var21[var7][3];
                              var25[var4 + 5 + 4 + 0] = (byte)var21[var7][4];
                              this.entities[var7][9] = 0;
                              var4 += 6;
                           }
                        }
                     }

                     this.x.A(32, this.x.j, 1022, var5, var25);
                  }

                  if (this.ba) {
                     byte[] var8 = new byte[]{0, 0, 0, 0, (byte)(this.players[0][3] & 255), (byte)(this.players[0][3] >>> 8 & 255), (byte)(this.players[0][3] >>> 16 & 255), (byte)(this.players[0][3] >>> 24 & 255), (byte)(this.players[0][15] & 255), (byte)(this.players[0][15] >>> 8 & 255), (byte)this.players[0][4], (byte)this.players[1][2], (byte)this.players[1][4], (byte)this.players[1][5]};
                     this.x.A(32, this.x.j, 1023, 10, var8);
                     this.ba = false;
                  }

                  if (this.ca) {
                     int[][] var34 = this.planes;
                     var6 = 0;
                     int var33 = 4 * this.maxPlanes + 2;
                     byte[] var26 = new byte[var33 + 4];
                     if (this.players[0][4] == 15 && this.players[0][5] > 0) {
                        var6 = 1;
                     }

                     if (this.players[1][4] == 15 && this.players[1][5] > 0) {
                        var6 = 1;
                     }

                     var26[4] = (byte)this.maxPlanes;
                     var26[5] = (byte)var6;
                     int var22 = 0;

                     for(int var11 = 2; var22 < this.maxPlanes; ++var22) {
                        var26[var11 + 4 + 0] = (byte)(var34[var22][0] & 255);
                        var26[var11 + 4 + 1] = (byte)(var34[var22][0] >>> 8 & 255);
                        var11 += 2;
                        var26[var11 + 4 + 0] = (byte)var34[var22][1];
                        ++var11;
                        var26[var11 + 4 + 0] = (byte)var34[var22][2];
                        ++var11;
                     }

                     this.x.A(32, this.x.j, 1024, var33, var26);
                     this.ca = false;
                  }
               } else {
                  this.players[this.nA][17] = 0;
               }

               int[][] var27 = this.entities;
               if (this.ga >= 0) {
                  switch (this.n) {
                     case 2:
                        int var23 = 0;
                        this.KA();
                        if (!this.h) {
                           this.dA += System.currentTimeMillis() - this.cA;
                        }

                        this.cA = System.currentTimeMillis();
                        if (this.ha == 2 && this.dA > this.iA && this.players[0][4] == 0) {
                           this.players[0][4] = this.CA();
                           this.iA = this.dA + 4000L * (4L - this.dA / (this.eA / 4L));
                           this.ba = true;
                        }

                        this.X();
                        this.updatePlayer(0);
                        if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
                           this.updatePlayer(1);
                        }

                        for(; var23 < var27.length; ++var23) {
                           int var13 = var27[var23][0];
                           if (var13 != 0 && var13 != 2 && var13 != 1) {
                              if (var13 >= 3 && var13 <= 18) {
                                 var13 = 0;
                                 if (var27[var23][3] != 0 || var27[var23][4] != 0) {
                                    var13 = 1;
                                 }

                                 if (this.settleEntity(var23) && this.applyGravity(var23) && var13 != 0) {
                                    this.matchPending = true;
                                 }

                                 this.checkEntityCollisions(var23);
                              } else if (var13 >= 27 && var13 < 35) {
                                 int var37 = var27[var23][0]++;
                                 if (var27[var23][0] == 35) {
                                    var27[var23][8] = this.createExplosionSprite(var23);
                                    var27[var23][0] = 19;
                                    var27[var23][9] = 1;
                                 }
                              } else if (var13 >= 19 && var13 < 27) {
                                 int var10002 = var27[var23][0]++;
                                 if (var27[var23][0] == 27) {
                                    if (var27[var23][7] == 1) {
                                       var13 = this.playerOfEntity(var23);
                                       if (var13 != -1) {
                                          var10002 = this.players[var13][2]--;
                                          if (this.players[var13][2] > 0) {
                                             this.H(var23, var13);
                                          } else {
                                             if (var13 == 0) {
                                                this.grid[var27[var23][1]][var27[var23][2]] = -1;
                                                this.C(var23, false);
                                             } else {
                                                this.grid2[var27[var23][1]][var27[var23][2]] = -1;
                                                this.C(var23, true);
                                             }

                                             this.L(3);
                                          }
                                       }
                                    } else {
                                       this.grid[var27[var23][1]][var27[var23][2]] = -1;
                                       this.sprites.B(var27[var23][8]);
                                       this.C(var23, false);
                                    }
                                 }
                              }
                           }
                        }
                  }

                  if (this.matchPending) {
                     this.clearMarks();
                     this.matchColorGroups(4);
                     this.matchColorGroups(5);
                     this.matchColorGroups(6);
                     this.matchColorGroups(7);
                     this.checkRowClear();
                     this.explodeMarkedCells();
                  }

                  this.updatePlanes();
               }

               this.matchPending = false;
            }
         } else {
            this.cA = System.currentTimeMillis();
         }
      }
   }

   private void A(int var1, int var2, int var3, boolean var4) {
      int[][] var7 = this.players;
      SpriteState var6 = this.sprites.d[this.uA[var1]];
      if (var4) {
         var7[var1][19] = 1;
      }

      switch (var2) {
         case 0:
            if (this.players[var1][4] != 13 && this.players[var1][4] != 14) {
               int var8 = this.random.nextInt();
               if (var8 < 0) {
                  var8 *= -1;
               }

               var6.e = 0;
               var6.f = 0 + var8 % 7;
               var6.g = 21;
            } else {
               var6.e = 1;
               if (var7[var1][15] == 3) {
                  var6.f = 0;
               } else {
                  var6.f = 3;
               }

               var6.g = var6.f + 1;
            }
            break;
         case 1:
         case 4:
            var6.e = 3;
            var6.f = 0;
            var6.g = 6;
            if (var3 == 1) {
               var6.f = 6;
               var6.g = 12;
            }
            break;
         case 2:
         case 3:
            var6.e = 1;
            var6.f = 0;
            var6.g = 3;
            if (var7[var1][10] == 3) {
               var6.f = 3;
               var6.g = 6;
            }
            break;
         case 5:
         case 6:
            var6.e = 3;
            var6.f = 0;
            var6.g = 6;
            if (var7[var1][10] == 6) {
               var6.f = 6;
               var6.g = 12;
            }
            break;
         case 7:
            var6.e = 3;
            var6.f = 0;
            var6.g = 6;
            if (var3 == 1) {
               var6.f = 6;
               var6.g = 12;
            }
            break;
         case 8:
         case 9:
            var6.e = 2;
            var6.f = 0;
            var6.g = 3;
            if (var7[var1][10] == 9) {
               var6.f = 3;
               var6.g = 6;
            }
      }

   }

   private void T() {
      int[] var2 = this.eb;
      int var1 = 0;

      for(int var3 = var2.length; var1 < var3; ++var1) {
         var2[var1] = 0;
      }

   }

   private void U() {
      int[] var1 = this.eb;

      for(int var2 = var1.length - 1; var2 >= 0; --var2) {
         var1[var2] = 16777215;
      }

   }

   private void A(int var1, int var2, int var3) {
      int[] var11 = this.eb;
      int var10 = this.db;
      int var9 = this.cb;
      int var8 = this.entities[var1][0];
      int var7 = (16 - this.gridCols) / 2;
      ++var3;
      int var6 = 0;
      int var5 = 0;
      int var4 = 0;
      if (this.entities[var1][3] != 0) {
         var5 = this.entities[var1][3] / this.fb * -1;
      }

      if (this.entities[var1][4] != 0) {
         var4 = this.entities[var1][4] / this.fb * -1;
      }

      switch (var8) {
         case 1:
            var1 = this.playerOfEntity(var1);
            switch (this.players[var1][1]) {
               case 0:
                  var6 = -65536;
                  break;
               case 1:
                  var6 = -16776961;
                  break;
               case 2:
                  var6 = -16711936;
            }

            var1 = (var2 + var7) * 3 + var5;
            int var12 = (var3 + 1) * 3 + var4;
            var11[(var10 - var12) * var9 + var1] = var6;
            var11[(var10 - (var12 - 1)) * var9 + var1] = var6;
            var11[(var10 - var12) * var9 + var1 + 1] = var6;
            var11[(var10 - (var12 - 1)) * var9 + var1 + 1] = var6;
            var11[(var10 - (var12 - 2)) * var9 + var1] = var6;
            var11[(var10 - (var12 - 2)) * var9 + var1 + 1] = var6;
            var11[(var10 - var12) * var9 + var1 + 2] = var6;
            var11[(var10 - (var12 - 1)) * var9 + var1 + 2] = var6;
            var11[(var10 - (var12 - 2)) * var9 + var1 + 2] = var6;
            break;
         default:
            var6 = -16777216;
      }

      int var13 = (var2 + var7) * 3 + var5;
      var1 = var3 * 3 + var4;
      var11[(var10 - var1) * var9 + var13] = var6;
      var11[(var10 - (var1 - 1)) * var9 + var13] = var6;
      var11[(var10 - var1) * var9 + var13 + 1] = var6;
      var11[(var10 - (var1 - 1)) * var9 + var13 + 1] = var6;
      var11[(var10 - (var1 - 2)) * var9 + var13] = var6;
      var11[(var10 - (var1 - 2)) * var9 + var13 + 1] = var6;
      var11[(var10 - var1) * var9 + var13 + 2] = var6;
      var11[(var10 - (var1 - 1)) * var9 + var13 + 2] = var6;
      var11[(var10 - (var1 - 2)) * var9 + var13 + 2] = var6;
   }

   private void V() {
      SpriteState var1 = this.sprites.d[this.wA[4]];
      this.sprites.E(this.wA[4]);
      ++var1.f;
      if (var1.f >= var1.g) {
         var1.f = 0;
      }

   }

   private void W() {
      SpriteState var1 = this.sprites.d[this.wA[6]];
      this.sprites.E(this.wA[6]);
      ++var1.f;
      if (var1.f >= var1.g) {
         var1.f = 0;
         this.bA = false;
      }

   }

   private void U(int var1) {
      var1 = this.playerOfEntity(var1);
      var1 = this.uA[var1];
      SpriteState var2 = this.sprites.d[var1];
      var2.e = 4;
      var2.f = 0;
   }

   // ============================================================
   // PLAYER: input, movement, jumping
   // ============================================================

   /** Per-frame update of one player: settle offsets, then process queued commands. */
   private void updatePlayer(int var1) {
      boolean var2 = this.players[var1][10] == 0;
      if (this.players[var1][10] != 12) {
         if (this.players[var1][1] != 3) {
            if (this.settleEntity(this.players[var1][0])) {
               if (var2) {
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
               } else {
                  this.A(var1, 0, this.players[var1][15], true);
               }

               this.players[var1][9] = this.players[var1][10];
               this.players[var1][10] = 0;
               if (var1 == this.nA) {
                  this.playSoundEvent(0);
               }

               this.processPlayerQueue(var1);
            } else {
               this.players[var1][7] = 0;
            }
         } else {
            this.processPlayerQueue(var1);
         }

      }
   }

   /** Consumes the next queued command for the player when the player is idle. */
   private void processPlayerQueue(int var1) {
      int[][] var3 = this.players;
      if (var3[var1][5] != 0) {
         int var10002 = var3[var1][5]--;
         if (var3[var1][5] <= 0) {
            if ((this.y & 1048576) != 0 && var3[var1][4] == 15) {
               this.ca = true;
            }

            var3[var1][5] = 0;
            var3[var1][4] = 0;
         }

         this.ba = true;
      }

      if (var3[var1][10] == 0) {
         if (var3[var1][11] != 0) {
            if (var3[var1][7] != 0 && var3[var1][7] != 5 && var3[var1][7] != 6) {
               this.executePlayerCommand(var1);
            }

            if (var3[var1][10] == 0) {
               this.executeQueuedStep(var1);
            }
         } else {
            int var2 = var3[var1][7];
            if (var2 != 0) {
               this.executePlayerCommand(var1);
            }

            if (var3[var1][10] == 0 && var3[var1][0] != -1 && this.entities[var3[var1][0]][2] > 0 && !this.applyGravity(var3[var1][0])) {
               this.players[var1][9] = this.players[var1][10];
               this.players[var1][10] = 1;
               if (var1 == this.nA) {
                  this.playSoundEvent(1);
               }

               this.A(var1, 1, var3[var1][15], true);
            }
         }
      } else if (var3[var1][7] != 2 && var3[var1][7] == 3) {
      }

   }

   /** Executes the player's pending command (2 = left, 3 = right, 4 = jump, 5/6 = diagonal jumps, 10 = use power-up). */
   private void executePlayerCommand(int var1) {
      int[][] var5 = this.players;
      if (var5[var1][10] == 12) {
         var5[var1][7] = 0;
      } else {
         int var2 = var5[var1][7];
         if (var2 != 0) {
            switch (var2) {
               case 2:
                  if (var5[var1][10] != 0) {
                     break;
                  }

                  if ((var5[var1][9] == 3 || var5[var1][9] == 2) && !this.applyGravity(var5[var1][0])) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 1;
                     if (var1 == this.nA) {
                        this.playSoundEvent(1);
                     }

                     this.A(var1, 1, var5[var1][15], true);
                  }

                  if (var5[var1][10] == 0) {
                     this.D(var1, 3);
                  }
                  break;
               case 3:
                  if (var5[var1][10] != 0) {
                     break;
                  }

                  if ((var5[var1][9] == 3 || var5[var1][9] == 2) && !this.applyGravity(var5[var1][0])) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 1;
                     if (var1 == this.nA) {
                        this.playSoundEvent(1);
                     }

                     this.A(var1, 1, var5[var1][15], true);
                  }

                  if (var5[var1][10] == 0) {
                     this.D(var1, 1);
                  }
                  break;
               case 4:
                  if (var5[var1][10] == 0 && this.entities[this.players[var1][0]][2] <= 5) {
                     this.D(var1, 0);
                  }
                  break;
               case 5:
                  if (var5[var1][10] == 0 && this.entities[this.players[var1][0]][2] <= 5) {
                     this.D(var1, 4);
                  }
                  break;
               case 6:
                  if (var5[var1][10] == 0 && this.entities[this.players[var1][0]][2] <= 5) {
                     this.D(var1, 5);
                  }
                  break;
               case 21:
                  if (this.players[1][4] == 15 && this.players[1][5] > 0) {
                     break;
                  }

                  var5[var1][15] -= 8;
                  if (var5[var1][15] < 8) {
                     var5[var1][15] = 8;
                  }

                  this.ba = true;
                  break;
               case 22:
                  int var4 = var5[var1][15] / 24;
                  if (var4 < this.gridCols && var5[var1][4] != 0) {
                     int var3 = -1;

                     for(int var6 = 6; var6 < this.gridRows; ++var6) {
                        if (this.grid[var4][var6] != -1) {
                           var3 = this.grid[var4][var6];
                           break;
                        }
                     }

                     if (var3 == -1) {
                        var2 = this.B(var5[var1][4], var4, 7);
                        var5[var1][4] = 0;
                        this.entities[var2][4] = -14;
                     }
                  }

                  this.ba = true;
                  break;
               case 23:
                  if (this.players[1][4] != 15 || this.players[1][5] <= 0) {
                     var5[var1][15] += 8;
                     if (var5[var1][15] > this.sa - 8 - 18) {
                        var5[var1][15] = this.sa - 8 - 18;
                     }

                     this.ba = true;
                  }
            }

            var5[var1][7] = 0;
         }

      }
   }

   /** Runs the second step of a multi-step move (queued in players[p][11]): sideways step or the second jump of a double jump. FIX 1 lives here. */
   private void executeQueuedStep(int var1) {
      int[][] var3 = this.players;
      var3[var1][9] = var3[var1][10];
      switch (var3[var1][11]) {
         case 2:
            this.G(var1, 3);
            break;
         case 3:
            this.G(var1, 1);
            break;
         case 4:
            if (this.entities[this.players[var1][0]][2] <= 5) {
               int var2 = this.grid[this.entities[var3[var1][0]][1]][this.entities[var3[var1][0]][2] + 2];
               if ((var2 == -1 || this.entities[var2][0] != 2)
                  && this.grid[this.entities[var3[var1][0]][1]][this.entities[var3[var1][0]][2] + 1] == -1) { // FIX 1
                  this.C(var3[var1][0], 0);
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, var3[var1][15], true);
               }
            }
      }

      var3[var1][11] = var3[var1][12];
      var3[var1][12] = var3[var1][13];
      var3[var1][13] = var3[var1][14];
      var3[var1][14] = 0;
   }

   private void X() {
      if (this.players[0][6] != 0) {
         this.usePowerUp(0);
         this.ba = true;
      }

      if (this.players[1][6] != 0) {
         this.usePowerUp(1);
         this.ba = true;
      }

   }

   // ============================================================
   // BOX PHYSICS: gravity, collisions, landing
   // ============================================================

   /** Decays an entity's pixel offsets toward 0 (smooth motion). Returns true once it has settled on its cell. */
   private boolean settleEntity(int var1) {
      int[][] var2 = this.entities;
      if (var2[var1][0] < 19) {
         if (var2[var1][3] != 0) {
            if (var2[var1][3] > 0) {
               var2[var1][3] -= 2;
            } else {
               var2[var1][3] += 2;
            }
         }

         if (var2[var1][4] != 0) {
            if (var2[var1][4] > 0) {
               var2[var1][4] -= 2;
            } else {
               var2[var1][4] += 2;
            }
         }
      }

      boolean var3 = var2[var1][3] == 0 && var2[var1][4] == 0;
      return var3;
   }

   /** Pixel-overlap test of a falling entity against neighbours in a 3x2 cell window; hands hits to resolveCollision. */
   private boolean checkEntityCollisions(int var1) {
      int[][] var15 = this.entities;
      int var2 = 0;
      int[] var14 = var15[var1];
      if (var14[2] != 0) {
         int var3 = var14[1] - 1;
         int var13 = var3 + 2;
         if (var3 < 0) {
            var3 = 0;
         }

         if (var13 >= this.gridCols) {
            var13 = this.gridCols - 1;
         }

         int var12 = var14[2] - 1;
         int var11 = var12 - 1;
         if (var11 < 0) {
            var11 = 0;
         }

         if (var12 >= this.gridRows) {
            var12 = this.gridRows - 1;
         }

         int var10 = -1;
         int var9 = var3;

         for(int[][] var8 = this.grid; var9 <= var13; ++var9) {
            for(int var7 = var11; var7 <= var12; ++var7) {
               int var6 = var8[var9][var7];
               if ((this.y & 1048576) != 0) {
                  var10 = this.grid2[var9][var7];
               }

               if (var6 != -1 && var6 != var1) {
                  int[] var5 = var15[var6];
                  if (var14[1] < var9 && var5[3] <= 0 || var14[1] > var9 && var5[3] >= 0) {
                     break;
                  }

                  var3 = var14[2] * 8;
                  var2 = var5[2] * 8;
                  int var4 = var3 - (8 + var14[4]);
                  var3 = var2 - (8 + var5[4]);
                  var2 = var4 - var3;
                  if (var2 < 0) {
                     var2 *= -1;
                  }

                  boolean hit = (var5[0] == 1) ? (var2 <= 16) : (var2 <= 8);
                  if (hit) {
                     this.I(var1, var6);
                  }
               }

               if ((this.y & 1048576) != 0 && var10 != -1 && var10 != var1) {
                  int[] var27 = var15[var10];
                  if (var14[1] < var9 && var27[3] <= 0 || var14[1] > var9 && var27[3] >= 0) {
                     break;
                  }

                  var3 = var14[2] * 8;
                  var2 = var27[2] * 8;
                  var3 -= 8 + var14[4];
                  var2 -= 8 + var27[4];
                  int var26 = var3 - 0;
                  var3 = var2 - 0;
                  var2 = var26 - var3;
                  if (var2 < 0) {
                     var2 *= -1;
                  }

                  boolean hit = (var27[0] == 1) ? (var2 <= 16) : (var2 <= 8);
                  if (hit) {
                     this.I(var1, var10);
                  }
               }
            }
         }
      }

      return false;
   }

   /** Support check: if nothing is below the entity it moves down one row. Returns true when supported. */
   private boolean applyGravity(int var1) {
      int[][] var6 = this.entities;
      boolean var5 = false;
      int var4 = 0;
      if (var1 != -1) {
         if (var6[var1][2] != 0) {
            int[] var3 = this.E(var6[var1][1], var6[var1][2]);
            if (var6[var1][0] == 1) {
               this.A(var3);
            }

            int var2 = this.B(var3);
            if (var2 == 0) {
               this.C(var1, 2);
               var5 = false;
            } else {
               var5 = true;
               if (var6[var1][0] == 1) {
                  while(var4 < var2) {
                     var5 = this.I(var1, this.A(var3, var4 + 1));
                     ++var4;
                  }
               }
            }
         } else {
            var5 = true;
         }
      }

      return var5;
   }

   private void C(int var1, int var2) {
      int[][] var5 = this.entities;
      int[][] var4 = this.grid;
      if (((this.y & 65536) != 0 || (this.y & 1048576) != 0) && this.players[1][0] == var1) {
         var4 = this.grid2;
      }

      var5[var1][9] = 1;
      switch (var2) {
         case 0:
            var4[var5[var1][1]][var5[var1][2] + 1] = var4[var5[var1][1]][var5[var1][2]];
            var4[var5[var1][1]][var5[var1][2]] = -1;
            int var12 = var5[var1][2]++;
            var5[var1][4] += 8;
            break;
         case 1:
            var4[var5[var1][1] + 1][var5[var1][2]] = var4[var5[var1][1]][var5[var1][2]];
            var4[var5[var1][1]][var5[var1][2]] = -1;
            int var11 = var5[var1][1]++;
            var5[var1][3] += 8;
            break;
         case 2:
            var4[var5[var1][1]][var5[var1][2] - 1] = var4[var5[var1][1]][var5[var1][2]];
            var4[var5[var1][1]][var5[var1][2]] = -1;
            int var10 = var5[var1][2]--;
            var5[var1][4] += -8;
            break;
         case 3:
            var4[var5[var1][1] - 1][var5[var1][2]] = var4[var5[var1][1]][var5[var1][2]];
            var4[var5[var1][1]][var5[var1][2]] = -1;
            int var9 = var5[var1][1]--;
            var5[var1][3] += -8;
            break;
         case 4:
            var4[var5[var1][1] - 1][var5[var1][2] + 1] = var4[var5[var1][1]][var5[var1][2]];
            var4[var5[var1][1]][var5[var1][2]] = -1;
            int var7 = var5[var1][1]--;
            var7 = var5[var1][2]++;
            var5[var1][3] += -8;
            var5[var1][4] += 8;
            break;
         case 5:
            var4[var5[var1][1] + 1][var5[var1][2] + 1] = var4[var5[var1][1]][var5[var1][2]];
            var4[var5[var1][1]][var5[var1][2]] = -1;
            int var10002 = var5[var1][1]++;
            var10002 = var5[var1][2]++;
            var5[var1][3] += 8;
            var5[var1][4] += 8;
      }

   }

   private void D(int var1, int var2) {
      int[][] var6 = this.entities;
      int[][] var5 = this.players;
      if (var5[var1][10] != 1 && var5[var1][11] != 1) {
         int var4 = var5[var1][0];
         switch (var2) {
            case 0:
               if (this.applyGravity(var4)) {
                  if (var6[var4][2] >= 5) {
                     return;
                  }

                  int var3 = this.grid[this.entities[var5[var1][0]][1]][this.entities[var5[var1][0]][2] + 1];
                  if (var3 != -1 && this.entities[var3][0] >= 4 && this.entities[var3][0] <= 18) {
                     this.entities[var3][7] = this.entities[var3][0];
                     this.entities[var3][0] = 19;
                     this.entities[var3][8] = this.createExplosionSprite(var3); // FIX 3
                     this.entities[var3][9] = 1;
                     return;
                  }

                  var3 = this.grid[this.entities[var5[var1][0]][1]][this.entities[var5[var1][0]][2] + 2];
                  if (var3 != -1 && this.entities[var3][0] == 2) {
                     return;
                  }

                  this.C(var4, var2);
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  if (this.entities[this.players[var1][0]][2] > 5) {
                     return;
                  }

                  if ((this.players[var1][1] == 2 || this.players[var1][4] == 16 && this.players[var1][5] > 0) && this.entities[this.players[var1][0]][2] < 5) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 4;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, var5[var1][15], true);
                  } else {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, var5[var1][15], true);
                  }
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 1;
                  if (var1 == this.nA) {
                     this.playSoundEvent(1);
                  }

                  this.A(var1, 1, var5[var1][15], true);
               }
               break;
            case 1:
            case 3:
               if (var5[var1][9] != 1) {
                  this.G(var1, var2);
               }
               break;
            case 2:
               if (this.B(this.E(var6[var4][1], var6[var4][2])) == 0) {
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 1;
                  if (var1 == this.nA) {
                     this.playSoundEvent(1);
                  }

                  this.A(var1, 1, var5[var1][15], true);
               }
               break;
            case 4:
            case 5:
               if (this.applyGravity(var4)) {
                  if (var5[var1][9] != 1) {
                     this.F(var1, var2);
                  }
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 1;
                  if (var1 == this.nA) {
                     this.playSoundEvent(1);
                  }

                  this.A(var1, 1, var5[var1][15], true);
               }
         }

      }
   }

   private int[] A(int var1, int var2, int var3, int var4, boolean var5) {
      int[] var7 = new int[8];

      for(int var6 = 0; var6 < var7.length; ++var6) {
         var7[var6] = -1;
      }

      var7[0] = -1;
      if (var2 > 0) {
         var7[0] = this.A(false, var1, var2 - 1, var3);
      }

      var7[4] = -1;
      if (var2 > 0) {
         var7[4] = this.A(true, var1, var2 - 1, var3);
      }

      var7[1] = this.A(false, var1, var2, var3);
      var7[5] = this.A(true, var1, var2, var3);
      var7[2] = this.A(false, var1, var2 + 1, var3);
      var7[6] = this.A(true, var1, var2 + 1, var3);
      if (var4 >= 2) {
         var7[3] = this.A(false, var1, var2 + 2, var3);
      }

      if (var4 >= 2) {
         var7[7] = this.A(true, var1, var2 + 2, var3);
      }

      if (!var5) {
         for(int var8 = 0; var8 < var7.length; ++var8) {
            if (var7[var8] != -1) {
               if (var7[var8] == this.players[0][0]) {
                  var7[var8] = -1;
               }

               if (((this.y & 65536) != 0 || (this.y & 1048576) != 0) && var7[var8] == this.players[1][0]) {
                  var7[var8] = -1;
               }
            }
         }
      }

      return var7;
   }

   private int A(int[] var1, int var2) {
      int var4 = -1;
      int var3 = 0;

      for(int var5 = 0; var5 < var1.length; ++var5) {
         if (var1[var5] != -1) {
            ++var3;
            if (var3 == var2) {
               var4 = var1[var5];
               break;
            }
         }
      }

      return var4;
   }

   private int[] E(int var1, int var2) {
      int[][] var10 = this.entities;
      int[] var9 = new int[]{-1, -1, -1, -1, -1, -1};
      if (var2 > 0) {
         int var8 = -1;
         int var7 = -1;
         int var6 = this.A(false, var1, var2, 2);
         if (var1 > 0) {
            var8 = this.A(false, var1, var2 - 1, 3);
            if (var8 != -1 && var10[var8][3] >= 0) {
               var8 = -1;
            }
         }

         if (var1 < this.gridCols - 1) {
            var7 = this.A(false, var1, var2 - 1, 1);
            if (var7 != -1 && var10[var7][3] <= 0) {
               var7 = -1;
            }
         }

         int var5 = -1;
         int var4 = -1;
         int var3 = -1;
         if ((this.y & 1048576) != 0) {
            var5 = this.A(true, var1, var2, 2);
            if (var1 > 0) {
               var4 = this.A(true, var1, var2 - 1, 3);
               if (var4 != -1 && var10[var4][3] <= 4) {
                  var4 = -1;
               }
            }

            if (var1 < this.gridCols - 1) {
               var3 = this.A(true, var1, var2 - 1, 1);
               if (var3 != -1 && var10[var3][3] >= -4) {
                  var3 = -1;
               }
            }
         }

         var9[0] = var6;
         var9[1] = var8;
         var9[2] = var7;
         var9[3] = var5;
         var9[4] = var4;
         var9[5] = var3;
      }

      return var9;
   }

   private void F(int var1, int var2) {
      int var5 = this.players[var1][0];
      int var3 = this.grid[this.entities[var5][1]][this.entities[var5][2] + 2];
      if (var3 == -1 || this.entities[var3][0] != 2) {
         int[] var4;
         if (var2 == 5) {
            this.players[var1][15] = 1;
            if (this.entities[var5][1] == this.gridCols - 1) {
               return;
            }

            var4 = this.A(this.entities[var5][1], this.entities[var5][2], 1, 2, false);
         } else {
            this.players[var1][15] = 3;
            if (this.entities[var5][1] == 0) {
               return;
            }

            var4 = this.A(this.entities[var5][1], this.entities[var5][2], 3, 2, false);
         }

         if (var4[0] != -1) {
            if (this.entities[var4[0]][0] == 2) {
               var4[0] = -1;
            } else if (this.entities[var4[0]][4] >= 0) {
               var4[0] = -1;
            }
         }

         var3 = this.B(var4);
         if (var3 == 0) {
            if (this.entities[this.players[var1][0]][2] <= 5) {
               this.C(var5, var2);
               this.players[var1][11] = 0;
               this.players[var1][12] = 0;
               this.players[var1][13] = 0;
               this.players[var1][14] = 0;
               if (var2 == 5) {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 6;
                  if (var1 == this.nA) {
                     this.playSoundEvent(6);
                  }

                  this.A(var1, 6, var2, true);
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 5;
                  if (var1 == this.nA) {
                     this.playSoundEvent(5);
                  }

                  this.A(var1, 5, var2, true);
               }

               this.players[var1][16] = 0;
            }
         } else if (var3 == 1) {
            if (var4[1] != -1) {
               if (this.entities[this.players[var1][0]][2] <= 5) {
                  this.C(var5, 0);
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  if (var2 == 5) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 3;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, 1, true);
                  } else {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 2;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, 3, true);
                  }
               }
            } else if (this.players[var1][1] == 2 || this.players[var1][4] == 16 && this.players[var1][5] > 0) {
               if (this.entities[this.players[var1][0]][2] < 5) {
                  this.C(var5, 0);
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  if (var2 == 5) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 4;
                     this.players[var1][12] = 3;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, 1, true);
                  } else {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 4;
                     this.players[var1][12] = 2;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, 3, true);
                  }
               } else {
                  this.C(var5, 0);
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  if (var2 == 5) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 3;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, 1, true);
                  } else {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 4;
                     this.players[var1][11] = 2;
                     if (var1 == this.nA) {
                        this.playSoundEvent(4);
                     }

                     this.A(var1, 4, 3, true);
                  }
               }
            } else {
               this.C(var5, 0);
               this.players[var1][11] = 0;
               this.players[var1][12] = 0;
               this.players[var1][13] = 0;
               this.players[var1][14] = 0;
               if (var2 == 5) {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  this.players[var1][11] = 3;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, 1, true);
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  this.players[var1][11] = 2;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, 3, true);
               }
            }
         } else if (var3 > 1 && this.entities[this.players[var1][0]][2] <= 5) {
            if (this.players[var1][1] == 2 || this.players[var1][4] == 16 && this.players[var1][5] > 0) {
               this.C(var5, 0);
               this.players[var1][11] = 0;
               this.players[var1][12] = 0;
               this.players[var1][13] = 0;
               this.players[var1][14] = 0;
               if (var2 == 5) {
                  var3 = 3;
                  var2 = 1;
               } else {
                  var3 = 2;
                  var2 = 3;
               }

               if (this.entities[this.players[var1][0]][2] < 5) {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  this.players[var1][11] = 4;
                  this.players[var1][12] = var3;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, var2, true);
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  this.players[var1][11] = var3;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, var2, true);
               }
            } else {
               this.C(var5, 0);
               this.players[var1][11] = 0;
               this.players[var1][12] = 0;
               this.players[var1][13] = 0;
               this.players[var1][14] = 0;
               if (var2 == 5) {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  this.players[var1][11] = 3;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, 1, true);
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 4;
                  this.players[var1][11] = 2;
                  if (var1 == this.nA) {
                     this.playSoundEvent(4);
                  }

                  this.A(var1, 4, 3, true);
               }
            }
         }

      }
   }

   private void B(int[] var1, int var2) {
      if (var2 == 1) {
         var1[3] = -1;
         if (var1[0] != -1) {
            if (this.entities[var1[0]][0] == 2) {
               var1[0] = -1;
            } else if (this.entities[var1[0]][4] >= 0) {
               var1[0] = -1;
            }
         }

         if (var1[2] != -1) {
            if (this.entities[var1[2]][0] == 2) {
               var1[2] = -1;
            } else if (this.entities[var1[2]][4] < 0) {
               var1[2] = -1;
            }
         }
      } else {
         if (var1[3] != -1) {
            if (this.entities[var1[3]][0] == 2) {
               var1[3] = -1;
            } else if (this.entities[var1[3]][4] < 0) {
               var1[3] = -1;
            }
         }

         if (var1[0] != -1) {
            if (this.entities[var1[0]][0] == 2) {
               var1[0] = -1;
            } else if (this.entities[var1[0]][4] >= 0) {
               var1[0] = -1;
            }
         }
      }

   }

   private void A(int[] var1) {
      for(int var2 = 0; var2 < var1.length; ++var2) {
         if (var1[var2] == this.players[0][0]) {
            var1[var2] = -1;
         }

         if (((this.y & 65536) != 0 || (this.y & 1048576) != 0) && var1[var2] == this.players[1][0]) {
            var1[var2] = -1;
         }
      }

   }

   private void G(int var1, int var2) {
      int[][] var3 = this.entities;
      int var7 = this.players[var1][0];
      this.players[var1][15] = var2;
      this.players[var1][19] = 1;
      if (var2 == 1) {
         if (var3[var7][1] == this.gridCols - 1) {
            return;
         }
      } else if (var3[var7][1] == 0) {
         return;
      }

      int[] var4 = this.A(var3[var7][1], var3[var7][2], var2, 2, true);
      this.B((int[])var4, 2);
      this.A(var4);
      int var6 = this.B(var4);
      switch (var6) {
         case 0:
            this.C(var7, var2);
            this.players[var1][11] = 0;
            this.players[var1][12] = 0;
            this.players[var1][13] = 0;
            this.players[var1][14] = 0;
            if (var2 == 1) {
               this.players[var1][9] = this.players[var1][10];
               this.players[var1][10] = 3;
               if (var1 == this.nA) {
                  this.playSoundEvent(3);
               }

               this.A(var1, 3, var2, true);
            } else {
               this.players[var1][9] = this.players[var1][10];
               this.players[var1][10] = 2;
               if (var1 == this.nA) {
                  this.playSoundEvent(2);
               }

               this.A(var1, 2, var2, true);
            }
            break;
         case 1:
            var6 = this.A((int[])var4, 1);
            int var13 = var3[var6][0];
            if ((var13 >= 18 && var13 <= 18 || var13 >= 8 && var13 <= 18) && this.J(var1, var6)) {
               this.C(var7, var2);
               this.players[var1][11] = 0;
               this.players[var1][12] = 0;
               this.players[var1][13] = 0;
               this.players[var1][14] = 0;
               if (var2 == 1) {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 3;
                  if (var1 == this.nA) {
                     this.playSoundEvent(3);
                  }

                  this.A(var1, 3, var2, true);
               } else {
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = 2;
                  if (var1 == this.nA) {
                     this.playSoundEvent(2);
                  }

                  this.A(var1, 2, var2, true);
               }
            } else if (var13 >= 4 && var13 <= 17 && (var2 != 3 || var3[var6][1] > 0) && (var2 != 1 || var3[var6][1] < this.gridCols - 1) && var3[var6][4] >= 0) {
               int[] var17 = this.A(var3[var6][1], var3[var6][2], var2, 1, true);
               this.B((int[])var17, 1);
               var13 = this.B(var17);
               if (var13 == 0) {
                  this.C(var6, var2);
                  this.C(var7, var2);
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  if (var2 == 1) {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 9;
                     if (var1 == this.nA) {
                        this.playSoundEvent(9);
                     }

                     this.A(var1, 9, var2, true);
                  } else {
                     this.players[var1][9] = this.players[var1][10];
                     this.players[var1][10] = 8;
                     if (var1 == this.nA) {
                        this.playSoundEvent(8);
                     }

                     this.A(var1, 8, var2, true);
                  }
               } else if (var13 == 1 && (this.players[var1][1] == 1 || this.players[var1][4] == 17 && this.players[var1][5] > 0)) {
                  var13 = this.A((int[])var17, 1);
                  if (var3[var13][0] != 1 && (var2 != 3 || var3[var13][1] > 0) && (var2 != 1 || var3[var13][1] < this.gridCols - 1) && var3[var13][0] >= 4 && var3[var13][0] <= 17) {
                     int[] var3b = this.A(var3[var13][1], var3[var13][2], var2, 1, true);
                     this.B(var3b, 1);
                     if (this.B(var3b) == 0) {
                        this.C(var13, var2);
                        this.C(var6, var2);
                        this.C(var7, var2);
                        this.players[var1][11] = 0;
                        this.players[var1][12] = 0;
                        this.players[var1][13] = 0;
                        this.players[var1][14] = 0;
                        if (var2 == 1) {
                           this.players[var1][9] = this.players[var1][10];
                           this.players[var1][10] = 9;
                           if (var1 == this.nA) {
                              this.playSoundEvent(9);
                           }

                           this.A(var1, 9, var2, true);
                        } else {
                           this.players[var1][9] = this.players[var1][10];
                           this.players[var1][10] = 8;
                           if (var1 == this.nA) {
                              this.playSoundEvent(8);
                           }

                           this.A(var1, 8, var2, true);
                        }
                     }
                  }
               }
            }
            break;
         case 2:
            int var5 = this.A((int[])var4, 1);
            if ((var2 != 3 || var3[var5][1] > 0) && (var2 != 1 || var3[var5][1] < this.gridCols - 1) && (this.players[var1][1] == 1 || this.players[var1][4] == 17 && this.players[var1][5] > 0)) {
               var6 = var5;
               var5 = this.A((int[])var4, 2);
               if (var3[var6][0] >= 4 && var3[var6][0] <= 17 && var3[var5][0] >= 4 && var3[var5][0] <= 17) {
                  var4 = this.A(var3[var6][1], var3[var6][2], var2, 1, true);
                  this.B((int[])var4, 1);
                  int[] var3b = this.A(var3[var5][1], var3[var5][2], var2, 1, true);
                  this.B(var3b, 1);
                  boolean var12 = this.B(var4) == 0;
                  boolean var9 = this.B(var3b) == 0;
                  if (var12 && var9) {
                     this.C(var6, var2);
                     this.C(var5, var2);
                     this.C(var7, var2);
                     this.players[var1][11] = 0;
                     this.players[var1][12] = 0;
                     this.players[var1][13] = 0;
                     this.players[var1][14] = 0;
                     if (var2 == 1) {
                        this.players[var1][9] = this.players[var1][10];
                        this.players[var1][10] = 9;
                        if (var1 == this.nA) {
                           this.playSoundEvent(9);
                        }

                        this.A(var1, 9, var2, true);
                     } else {
                        this.players[var1][9] = this.players[var1][10];
                        this.players[var1][10] = 8;
                        if (var1 == this.nA) {
                           this.playSoundEvent(8);
                        }

                        this.A(var1, 8, var2, true);
                     }
                  }
               }
            }
      }

   }

   private void H(int var1, int var2) {
      int[][] var5 = this.grid;
      int var4 = this.entities[var1][1];
      int var3 = this.entities[var1][2] + 1;
      this.sprites.B(this.entities[var1][8]); // FIX 2
      this.C(var1, var2 == 1);

      for(var1 = var3; var1 < this.gridRows - 1 && (var5[var4][var1] != -1 || var5[var4][var1 + 1] != -1); ++var1) {
      }

      if (var1 >= this.gridRows - 1) {
         --var1;
         if (var5[var4][var1] != -1) {
            this.C(var5[var4][var1], false);
         }

         if (var5[var4][var1 + 1] != -1) {
            this.C(var5[var4][var1 + 1], false); // FIX 4
         }
      }

      this.A(1, var4, var1, var2);
      this.players[var2][10] = 0;
      this.players[var2][4] = 0;
      this.players[var2][5] = 0;
      this.ba = true;
   }

   private int A(boolean var1, int var2, int var3, int var4) {
      int var6 = -1;
      if (var3 >= this.gridRows) return -1; // FIX 5
      int[][] var5 = this.grid;
      if (var1) {
         if ((this.y & 65536) == 0 && (this.y & 1048576) == 0) {
            return -1;
         }

         var5 = this.grid2;
      }

      switch (var4) {
         case 0:
            if (var3 + 1 < this.gridRows) {
               var6 = var5[var2][var3 + 1];
            }
            break;
         case 1:
            if (var2 + 1 < this.gridCols) {
               var6 = var5[var2 + 1][var3];
            }
            break;
         case 2:
            if (var3 - 1 >= 0) {
               var6 = var5[var2][var3 - 1];
            }
            break;
         case 3:
            if (var2 - 1 >= 0) {
               var6 = var5[var2 - 1][var3];
            }
      }

      return var6;
   }

   private int B(int[] var1) {
      int var3 = 0;
      int var2 = 0;

      for(int var4 = var1.length; var2 < var4; ++var2) {
         if (var1[var2] != -1) {
            ++var3;
         }
      }

      return var3;
   }

   /** Returns 0/1 for the player that owns this entity index, or -1. */
   private int playerOfEntity(int var1) {
      if (this.players[0][1] != 3 && this.players[0][0] == var1) {
         return 0;
      } else {
         return this.players[1][1] != 3 && this.players[1][0] == var1 ? 1 : -1;
      }
   }

   private boolean I(int var1, int var2) {
      boolean var7 = false;
      int[] var6 = this.entities[var2];
      int[] var5 = this.entities[var1];
      int var4 = var6[0];
      int var3 = var5[0];
      if ((var4 < 19 || var4 >= 27) && (var4 < 27 || var4 >= 35) && (var4 < 3 || var4 > 7)) {
         if ((var3 < 19 || var3 >= 27) && (var3 < 27 || var3 >= 35)) {
            if (var4 != 1 && var3 != 1) {
               return true;
            } else if (var4 == 1 && var3 == 1) {
               return true;
            } else if ((var3 >= 18 && var3 <= 18 || var3 >= 8 && var3 <= 18) && this.J(this.playerOfEntity(var2), var1)) {
               return true;
            } else if ((var4 >= 18 && var4 <= 18 || var4 >= 8 && var4 <= 18) && this.J(this.playerOfEntity(var1), var2)) {
               var1 = this.playerOfEntity(var1);
               this.players[var1][9] = this.players[var1][10];
               this.players[var1][10] = 1;
               if (var1 == this.nA) {
                  this.playSoundEvent(1);
               }

               this.A(var1, 1, this.players[var1][15], true);
               return true;
            } else {
               if (var6[4] > 0) {
                  if (var4 == 1) {
                     if (var3 >= 4 && var3 <= 18) {
                        var5[7] = var5[0];
                        var5[8] = this.createExplosionSprite(var1);
                        var5[0] = 19;
                        var5[9] = 1;
                     }

                     this.C(var2, 2);
                     var6[4] += 2;
                     this.players[this.playerOfEntity(var2)][9] = this.players[this.playerOfEntity(var2)][10];
                     this.players[this.playerOfEntity(var2)][10] = 1;
                     this.players[this.playerOfEntity(var2)][11] = 0;
                     if (this.playerOfEntity(var2) == this.nA) {
                        this.playSoundEvent(1);
                     }
                  }
               } else {
                  if (var4 == 1) {
                     var6[7] = var6[0];
                     var6[0] = 27;
                     var6[9] = 1;
                     this.U(var2);
                     this.players[this.playerOfEntity(var2)][9] = this.players[this.playerOfEntity(var2)][10];
                     this.players[this.playerOfEntity(var2)][10] = 12;
                     this.players[this.playerOfEntity(var2)][11] = 0;
                     this.players[this.playerOfEntity(var2)][12] = 0;
                     if (this.playerOfEntity(var2) == this.nA) {
                        this.playSoundEvent(12);
                     }
                  }

                  var7 = true;
               }

               return var7;
            }
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private boolean J(int var1, int var2) {
      boolean var3 = false;
      if (this.entities[var2][0] >= 18 && this.entities[var2][0] <= 18) {
         if (this.players[var1][2] == 3) {
            this.addScore(var1, 100);
         } else {
            int var10002 = this.players[var1][2]++;
         }

         this.entities[var2][9] = 1;
         this.C(var2, false);
         var3 = true;
         this.ba = true;
      } else if (this.entities[var2][0] >= 8 && this.entities[var2][0] <= 18 && this.players[var1][4] == 0) {
         this.players[var1][4] = this.entities[var2][0];
         this.A(var1, this.players[var1][10], this.players[var1][15], true);
         this.entities[var2][9] = 1;
         this.C(var2, false);
         this.ba = true;
         var3 = true;
      }

      return var3;
   }

   private boolean K(int var1, int var2) {
      if (this.players[var1][10] == 12) {
         return true;
      } else {
         if (var2 == 10) {
            this.players[var1][6] = 1;
         } else {
            this.players[var1][7] = var2;
         }

         return true;
      }
   }

   // ============================================================
   // POWER-UP BOXES (types 8..18)
   // ============================================================

   /** Uses the power-up the player holds: area blast, colour blast and the other special effects. */
   private void usePowerUp(int var1) {
      this.players[var1][6] = 0;
      if (this.players[var1][5] <= 0) {
         this.i.i = 0;
         switch (this.players[var1][4]) {
            case 8:
               if (this.powerAreaBlast(var1)) {
                  this.players[var1][4] = 0;
               }
               break;
            case 9:
            case 10:
            case 11:
            case 12:
               this.powerColorBlast(var1);
               this.players[var1][4] = 0;
               break;
            case 13:
               if (this.GA(var1)) {
                  this.players[var1][4] = 0;
               }
               break;
            case 14:
               if (this.HA(var1)) {
                  this.players[var1][4] = 0;
               }
               break;
            case 15:
               if ((this.y & 1048576) != 0) {
                  this.ca = true;
               }
            case 16:
            case 17:
               if (this.players[var1][5] == 0) {
                  this.players[var1][5] = 50;
               }
         }

         this.ba = true;
      }
   }

   /** Power-up: explodes every box in a 3x4 area around the player. */
   private boolean powerAreaBlast(int var1) {
      int var2 = this.players[var1][0];
      if (this.entities[var2][2] > 0) {
         var1 = this.A(false, this.entities[var2][1], this.entities[var2][2], 2);
         if (var1 >= 19 && var1 < 27 || var1 <= 0) {
            return false;
         }
      }

      if (this.entities[var2][3] == 0 && this.entities[var2][4] == 0) {
         var1 = this.entities[var2][1] - 1;
         int var8 = this.entities[var2][1] + 1;
         if (var1 < 0) {
            var1 = 0;
         }

         if (var8 >= this.gridCols) {
            var8 = this.gridCols - 1;
         }

         int var7 = this.entities[var2][2] - 1;
         int var6 = this.entities[var2][2] + 2;
         if (var7 < 0) {
            var7 = 0;
         }

         if (var6 >= this.gridRows) {
            var6 = this.gridRows - 1;
         }

         int var5 = -1;
         int var4 = var1;

         for(int[][] var3 = this.entities; var4 <= var8; ++var4) {
            for(int var14 = var7; var14 <= var6; ++var14) {
               var1 = this.grid[var4][var14];
               if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
                  var5 = this.grid2[var4][var14];
               }

               if (var1 != -1) {
                  if (var3[var1][0] != 1 && var3[var1][0] != 2) {
                     var3[var1][7] = var3[var1][0];
                     var3[var1][8] = this.createExplosionSprite(var1);
                     var3[var1][0] = 19;
                     var3[var1][9] = 1;
                  }
               } else if (var5 == -1) {
                  var1 = 1;
                  if (var14 > 0) {
                     if (this.ha != 2 && this.grid[var4][var14 - 1] == this.players[0][0]) {
                        var1 = 0;
                     }

                     if (((this.y & 65536) != 0 || (this.y & 1048576) != 0) && this.grid2[var4][var14 - 1] != -1) {
                        var1 = 0;
                     }
                  }

                  if (var1 != 0) {
                     var1 = this.B(19, var4, var14);
                     var3[var1][8] = this.createExplosionSprite(var1);
                     var3[var1][9] = 1;
                  }
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   /** Power-up: explodes every box of one colour. */
   private boolean powerColorBlast(int var1) {
      int var2 = 0;
      int var6 = this.players[var1][4] - 5;
      int[][] var5 = this.entities;

      for(int[][] var4 = this.grid; var2 < var4.length; ++var2) {
         for(int var3 = 0; var3 < var4[var2].length; ++var3) {
            var1 = var4[var2][var3];
            if (var1 != -1 && var5[var1][0] == var6) {
               var5[var1][7] = var5[var1][0];
               var5[var1][8] = this.createExplosionSprite(var1);
               var5[var1][0] = 19;
               var5[var1][9] = 1;
            }
         }
      }

      return true;
   }

   private boolean GA(int var1) {
      boolean var4 = false;
      int var2 = this.players[var1][0];
      int var3 = this.entities[var2][1];
      var2 = this.entities[var2][2];
      if (this.players[var1][15] == 3) {
         --var3;
      } else {
         ++var3;
      }

      if (var3 >= 0 && var3 < this.gridCols) {
         var2 = this.grid[var3][var2];
         if (var2 != -1) {
            int[] var5 = this.entities[var2];
            if (var5[0] >= 4 && var5[0] <= 17) {
               var5[7] = var5[0];
               var5[8] = this.createExplosionSprite(var2);
               var5[0] = 19;
               var5[9] = 1;
               var4 = true;
            } else if (var5[0] == 1) {
               var4 = true;
            }
         }

         return var4;
      } else {
         return false;
      }
   }

   private boolean HA(int var1) {
      boolean var8 = false;
      int var7 = this.players[var1][0];
      int var3 = this.entities[var7][1];
      int var2 = this.entities[var7][2];
      if (this.players[var1][15] == 3) {
         --var3;
      } else {
         ++var3;
      }

      if (var3 >= 0 && var3 < this.gridCols) {
         int var6 = this.grid[var3][var2];
         if (var6 != -1) {
            var2 = this.entities[var6][0];
            if (var2 >= 4 && var2 <= 17 || var2 >= 18 && var2 <= 18) {
               byte var4;
               byte var5;
               if (this.players[var1][15] == 3) {
                  if (this.entities[var7][1] >= this.gridCols - 1) {
                     return false;
                  }

                  var5 = 1;
                  var4 = 2;
               } else {
                  if (this.entities[var7][1] == 0) {
                     return false;
                  }

                  var5 = 3;
                  var4 = 3;
               }

               int[] var12 = this.A(this.entities[var7][1], this.entities[var7][2], var5, 2, false);
               this.B((int[])var12, 1);
               var2 = this.B(var12);
               if (var12 != null && var2 == 0) {
                  this.C(var7, var5);
                  this.players[var1][11] = 0;
                  this.players[var1][12] = 0;
                  this.players[var1][13] = 0;
                  this.players[var1][14] = 0;
                  this.players[var1][9] = this.players[var1][10];
                  this.players[var1][10] = var4;
                  if (var1 == this.nA) {
                     this.playSoundEvent(var4);
                  }

                  this.A(var1, var4, this.players[var1][15], true);
                  this.C(var6, var5);
                  var8 = true;
               }
            }
         }

         return var8;
      } else {
         return false;
      }
   }

   // ============================================================
   // MATCHING AND CLEARING
   // ============================================================

   /** Finds groups of 3+ touching boxes of the given colour (4..7), scores them and marks them for destruction. Splash sound option fires here. */
   private void matchColorGroups(int var1) {
      int[][] var6 = this.entities;
      int[][] var5 = this.grid;
      int var4 = 0;

      int var3;
      for(var3 = 0; var4 < this.gridCols; ++var4) {
         for(int var2 = 0; var2 < this.gridRows; ++var2) {
            if (var5[var4][var2] != -1 && var6[var5[var4][var2]][0] == var1 && var6[var5[var4][var2]][3] == 0 && var6[var5[var4][var2]][4] == 0) {
               this.marks[var4][var2] = 1;
               ++var3;
            }
         }
      }

      if (var3 != 0) {
         for(int var9 = 0; var9 < var5.length; ++var9) {
            for(int var7 = 0; var7 < var5[var9].length; ++var7) {
               if (this.marks[var9][var7] != 0) {
                  this.ac = 0;
                  this.floodFillGroup(var9, var7);
                  if (this.ac >= 3) {
                     this.M(var9, var7);
                     this.addScore(0, this.ac * 10);
                     if (Config.SPLASH_ON_COLOR_MATCH) {
                        this.playSplash(); // option: sound when 3+ same-colour boxes are destroyed
                     }
                     int var10002 = this.stats[0][this.ac]++;
                  }
               }
            }
         }

         for(int var10 = 0; var10 < var5.length; ++var10) {
            for(int var8 = 0; var8 < var5[var10].length; ++var8) {
               if (this.marks[var10][var8] == 3) {
                  this.marks[var10][var8] = 99;
               } else if (this.marks[var10][var8] != 99) {
                  this.marks[var10][var8] = 0;
               }
            }
         }

      }
   }

   /** Flood fill used by matchColorGroups to measure a colour group (result in ac). */
   private void floodFillGroup(int var1, int var2) {
      if (this.marks[var1][var2] == 1) {
         this.marks[var1][var2] = 2;
         ++this.ac;
         if (var1 - 1 >= 0) {
            this.floodFillGroup(var1 - 1, var2);
         }

         if (var2 + 1 < this.gridRows) {
            this.floodFillGroup(var1, var2 + 1);
         }

         if (var1 + 1 < this.gridCols) {
            this.floodFillGroup(var1 + 1, var2);
         }

         if (var2 - 1 >= 0) {
            this.floodFillGroup(var1, var2 - 1);
         }
      }

   }

   void M(int var1, int var2) {
      if (this.marks[var1][var2] == 2) {
         this.marks[var1][var2] = 3;
         if (var1 - 1 >= 0) {
            this.M(var1 - 1, var2);
         }

         if (var2 + 1 < this.gridRows) {
            this.M(var1, var2 + 1);
         }

         if (var1 + 1 < this.gridCols) {
            this.M(var1 + 1, var2);
         }

         if (var2 - 1 >= 0) {
            this.M(var1, var2 - 1);
         }
      }

   }

   /** Resets the marks grid before a new match pass. */
   private void clearMarks() {
      byte[][] var1 = this.marks;
      int[][] var3 = this.grid;

      for(int var2 = 0; var2 < var3.length; ++var2) {
         for(int var4 = 0; var4 < var3[var2].length; ++var4) {
            var1[var2][var4] = 0;
         }
      }

   }

   /** If the whole bottom row is settled boxes, destroy it, score +20 and raise maxPlanes. Splash sound option fires here. */
   private void checkRowClear() {
      int[][] var6 = this.entities;
      int[][] var5 = this.grid;
      int var4 = 0;

      int var3;
      for(var3 = 0; var4 < var5.length; ++var4) {
         int var2 = var5[var4][0];
         if (var2 == -1) {
            break;
         }

         int var1 = var6[var2][0];
         if (var1 < 3 || var1 > 18 || var6[var2][3] != 0 || var6[var2][4] != 0) {
            break;
         }

         ++var3;
      }

      if (var3 == this.gridCols) {
         for(int var7 = 0; var7 < var5.length; ++var7) {
            this.marks[var7][0] = 99;
         }

         this.addScore(0, 20);
         if (Config.SPLASH_ON_ROW_CLEAR) {
            this.playSplash(); // option: sound when a whole bottom row is cleared
         }
         int var10002 = this.stats[0][1]++;
         if (this.maxPlanes != 0) {
            ++this.maxPlanes;
            if (this.maxPlanes > 12) {
               this.maxPlanes = 12;
            }
         }
      }

   }

   /** Adds points to a player's score. */
   private void addScore(int var1, int var2) {
      if (this.ha == 0 || this.ha == 1) {
         int[] var10000 = this.players[0];
         var10000[3] += var2;
         this.ba = true;
      }

   }

   /** Turns every cell marked 99 into an explosion (type 19) with its own sprite. */
   private void explodeMarkedCells() {
      int[][] var5 = this.entities;
      int[][] var4 = this.grid;

      for(int var3 = 0; var3 < var4.length; ++var3) {
         for(int var2 = 0; var2 < var4[var3].length; ++var2) {
            int var1 = this.marks[var3][var2];
            if (var1 == 99) {
               var1 = var4[var3][var2];
               var5[var1][7] = var5[var1][0];
               var5[var1][8] = this.createExplosionSprite(var1);
               var5[var1][0] = 19;
               var5[var1][9] = 1;
            }
         }
      }

   }

   /** Moves the dropper planes, drops boxes (only if rows 6..9 of the column are empty) and randomly spawns new planes. */
   private void updatePlanes() {
      if (this.players[0][4] != 15 || this.players[0][5] <= 0) {
         if ((this.y & 65536) == 0 && (this.y & 1048576) == 0 || this.players[1][4] != 15 || this.players[1][5] <= 0) {
            int[][] var6 = this.planes;
            int var5 = 0;

            int var4;
            for(var4 = 0; var5 < this.maxPlanes; ++var5) {
               if (var6[var5][1] != 0) {
                  ++var4;
                  if (var6[var5][1] == 1) {
                     var6[var5][0] -= 2;
                     if (var6[var5][0] < -18) {
                        var6[var5][1] = 0;
                        var6[var5][2] = 0;
                        this.ca = true;
                     }
                  } else {
                     var6[var5][0] += 2;
                     if (var6[var5][0] > this.sa) {
                        var6[var5][1] = 0;
                        var6[var5][2] = 0;
                        this.ca = true;
                     }
                  }

                  if (var6[var5][0] + this.va > 0) {
                     int var3 = var6[var5][0] / 24;
                     if (var3 < this.gridCols && var6[var5][2] != 0 && var6[var5][3] == var3 && var6[var5][0] % 8 == 4) {
                        int var2 = -1;

                        for(int var1 = 6; var1 < this.gridRows; ++var1) {
                           if (this.grid[var3][var1] != -1) {
                              var2 = this.grid[var3][var1];
                              break;
                           }
                        }

                        if (var2 == -1) {
                           int var7 = this.B(var6[var5][2], var3, 7);
                           var6[var5][2] = 0;
                           this.entities[var7][4] = -14;
                           this.addScore(0, 1);
                           this.ca = true;
                           int var10002 = this.stats[0][0]++;
                        }
                     }
                  }
               }
            }

            if (var4 < this.maxPlanes) {
               int var8 = this.random.nextInt();
               if (var8 < 0) {
                  var8 *= -1;
               }

               var8 %= 25;
               if (var8 != 1) {
                  return;
               }

               var4 = this.random.nextInt() % this.gridCols;
               if (var4 < 0) {
                  var4 *= -1;
               }

               int var13 = this.CA();
               if (var13 != -1) {
                  var8 = this.random.nextInt();
                  if (var8 < 0) {
                     var8 *= -1;
                  }

                  int var12 = var8 % 2;

                  for(int var11 = 0; var11 < this.maxPlanes; ++var11) {
                     if (var6[var11][1] == 0) {
                        var6[var11][2] = var13;
                        var6[var11][3] = var4;
                        var6[var11][1] = 1 + var12;
                        if (var6[var11][1] == 1) {
                           var6[var11][0] = this.sa - 2;
                        } else {
                           var6[var11][0] = -16;
                        }

                        this.ca = true;
                        break;
                     }
                  }
               }
            }

         }
      }
   }

   public int CA() {
      int var3 = -1;
      int var1 = this.random.nextInt();
      if (var1 < 0) {
         var1 *= -1;
      }

      int var2 = var1 % 101;
      if (var2 <= 75) {
         int var4 = this.random.nextInt();
         if (var4 < 0) {
            var4 *= -1;
         }

         var4 %= 4;
         var3 = 4 + var4;
      } else if (var2 <= 84) {
         var3 = 3;
      } else if (var2 <= 90) {
         int var6 = this.random.nextInt();
         if (var6 < 0) {
            var6 *= -1;
         }

         var6 %= 5;
         var3 = 8 + var6;
      } else if (var2 <= 96) {
         int var8 = this.random.nextInt();
         if (var8 < 0) {
            var8 *= -1;
         }

         var8 %= 3;
         var3 = 13 + var8;
      } else if (var2 <= 99) {
         if ((this.y & 1048576) != 0) {
            int var10 = this.random.nextInt();
            if (var10 < 0) {
               var10 *= -1;
            }

            var10 %= 3;
            var3 = 16 + var10;
         } else if (this.players[0][1] == 0) {
            int var12 = this.random.nextInt();
            if (var12 < 0) {
               var12 *= -1;
            }

            var12 %= 2;
            var3 = 16 + var12;
         } else if (this.players[0][1] == 1) {
            var3 = 16;
         } else {
            var3 = 17;
         }
      } else if (var2 <= 100) {
         var3 = 18;
      }

      return var3;
   }

   public void DA() {
      this.gridCols = 10;
      this.gridRows = 10;
      if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
         this.gridCols = 16;
         this.gridRows = 10;
      }

      this.grid = new int[this.gridCols][this.gridRows];
      this.marks = new byte[this.gridCols][this.gridRows];
      if ((this.y & 65536) != 0 || (this.y & 1048576) != 0) {
         this.grid2 = new int[this.gridCols][this.gridRows];
      }

      this.sa = 24 + this.gridCols * this.cellSize;
      this.ta = 80 + this.gridRows * this.cellSize;
      this.entities = new int[this.gridCols * this.gridRows + 2][10];
   }

   public void EA() {
      for(int var1 = 0; var1 < this.stats[0].length; ++var1) {
         this.stats[0][var1] = 0;
         this.stats[1][var1] = 0;
      }

      for(int var3 = 0; var3 < this.players[0].length; ++var3) {
         this.players[0][var3] = 0;
         this.players[1][var3] = 0;
      }

      for(int var2 = 0; var2 < this.grid.length; ++var2) {
         for(int var4 = 0; var4 < this.grid[var2].length; ++var4) {
            this.grid[var2][var4] = -1;
         }
      }

      if (this.grid2 != null) {
         for(int var8 = 0; var8 < this.grid2.length; ++var8) {
            for(int var5 = 0; var5 < this.grid2[var8].length; ++var5) {
               this.grid2[var8][var5] = -1;
            }
         }
      }

      for(int var9 = 0; var9 < this.entities.length; ++var9) {
         for(int var6 = 0; var6 < this.entities[var9].length; ++var6) {
            this.entities[var9][var6] = 0;
         }
      }

      for(int var10 = 0; var10 < this.planes.length; ++var10) {
         for(int var7 = 0; var7 < this.planes[var10].length; ++var7) {
            this.planes[var10][var7] = 0;
         }
      }

   }

   public void FA() {
      for(int var3 = 0; var3 < this.gridCols; ++var3) {
         int var1 = this.random.nextInt();
         if (var1 < 0) {
            var1 *= -1;
         }

         int var2 = var1 % this.gridCols;

         for(int var4 = 0; var4 < this.gridRows; ++var4) {
            if (this.grid[var2][var4] == -1) {
               this.B(this.CA(), var2, var4);
               break;
            }
         }
      }

      int var11 = 0;
      int var5 = this.random.nextInt();
      if (var5 < 0) {
         var5 *= -1;
      }

      int var9 = var5 % this.gridCols;

      for(int var6 = 0; var6 < this.gridRows; ++var6) {
         if (this.grid[var9][var6] == -1) {
            this.A(1, var9, var6, 0);
            var11 = var9;
            this.players[0][2] = 1;
            break;
         }
      }

      if (((this.y & 65536) != 0 || (this.y & 1048576) != 0) && this.ha == 1) {
         do {
            var5 = this.random.nextInt();
            if (var5 < 0) {
               var5 *= -1;
            }

            var5 %= this.gridCols;
         } while(var5 == var11);

         for(int var10 = 0; var10 < this.gridRows; ++var10) {
            if (this.grid[var5][var10] == -1) {
               this.A(1, var5, var10, 1);
               this.players[1][2] = 1;
               break;
            }
         }
      }

   }

   private void GA() {
      int var1 = this.random.nextInt();
      if (var1 < 0) {
         var1 *= -1;
      }

      var1 %= this.gridCols;
      this.A(1, var1, 0, 1);
      this.players[1][2] = 1;
   }

   /** Allocates a sprite slot for an explosion and returns its index (-1 if the pool is full). */
   private int createExplosionSprite(int var1) {
      SpriteState var2 = this.sprites.C();
      var2.a = this.sA[2];
      var2.h |= 1;
      var2.h |= 4;
      return this.sprites.A(var2);
   }

   private int A(int var1, int var2, int var3, int var4) {
      var1 = this.allocEntity(var1);
      if (var4 == 0) {
         this.grid[var2][var3] = var1;
      } else {
         this.grid2[var2][var3] = var1;
      }

      this.entities[var1][1] = var2;
      this.entities[var1][2] = var3;
      this.players[var4][0] = var1;
      this.players[var4][15] = 3;
      return var1;
   }

   private int B(int var1, int var2, int var3) {
      var1 = this.allocEntity(var1);
      if (this.grid[var2][var3] != -1) {
         this.freeEntity(var1);
         var1 = -1;
      } else {
         this.grid[var2][var3] = var1;
         this.entities[var1][1] = var2;
         this.entities[var1][2] = var3;
         this.entities[var1][9] = 1;
      }

      return var1;
   }

   private void C(int var1, boolean var2) {
      int var4 = this.entities[var1][1];
      int var3 = this.entities[var1][2];
      this.freeEntity(var1);
      this.entities[var1][9] = 1;
      if (var2) {
         this.grid2[var4][var3] = -1;
      } else {
         this.grid[var4][var3] = -1;
      }

   }

   // ============================================================
   // ENTITY TABLE (allocation)
   // ============================================================

   /** Takes the first free row in the entity table and gives it the type. Returns -1 when the table is full. */
   private int allocEntity(int var1) {
      int var2 = 0;

      int[][] var3 = this.entities; for(; var2 < var3.length; ++var2) {
         if (var3[var2][0] == 0) {
            var3[var2][0] = var1;
            break;
         }
      }

      if (var2 == var3.length) {
         var2 = -1;
      }

      return var2;
   }

   /** Zeroes an entity row so it can be reused. */
   private void freeEntity(int var1) {
      int[][] var2 = this.entities;

      for(int var3 = 0; var3 < var2[var1].length; ++var3) {
         var2[var1][var3] = 0;
      }

   }

   public int A(List var1, String var2) {
      int var3 = -1;

      for(int var4 = 0; var4 < var1.size(); ++var4) {
         if (var1.getString(var4).compareTo(var2) == 0) {
            var3 = var4;
            break;
         }
      }

      return var3;
   }

   public void MA(int var1) {
      this.sprites.a.fillRect(0, 0, 240, 320);
      Font.getDefaultFont();
      String var4 = "";
      if (this.ib == 0) {
         var4 = A((String)E(30), 230);
      } else if (this.ib == 1) {
         var4 = A((String)E(28), 230);
      } else if (this.ib == 2) {
         var4 = A((String)E(32), 230);
      }

      int var3 = 0;
      int var2 = 0;

      for(int var5 = var4.indexOf(10, 0); var5 >= 0; var5 = var4.indexOf(10, var3)) {
         ++var2;
         var3 = var5 + 1;
      }

      if (var3 < var4.length()) {
         ++var2;
      }

      this.bB = new String[var2];
      var3 = var4.indexOf(10, 0);
      var2 = 0;

      for(var1 = 0; var3 >= 0; var3 = var4.indexOf(10, var1)) {
         this.bB[var2] = var4.substring(var1, var3);
         ++var2;
         var1 = var3 + 1;
      }

      if (var1 < var4.length()) {
         this.bB[var2] = var4.substring(var1);
      }

      this.zb = 0;
      this.aB = System.currentTimeMillis();
   }

   public synchronized void B(Graphics var1) {
      this.yb += 60;
      if (this.yb >= this.xb) {
         this.yb = 0;
      }

      this.hB.bindTarget(var1);
      this.tb.animate(this.yb);
      Appearance var2 = ((Mesh)this.ub).getAppearance(0);
      CompositingMode var3 = var2.getCompositingMode();
      if (var3 == null) {
         var3 = new CompositingMode();
      }

      var3.setAlphaWriteEnable(true);
      var3.setBlending(64);
      var2.setCompositingMode(var3);
      Texture2D var4 = this.vb[this.ib][this.wb];
      if (this.yb % 240 == 0) {
         ++this.wb;
      }

      if (this.aB + 1000L < System.currentTimeMillis() && this.bB.length > 2) {
         ++this.zb;
         this.zb %= this.bB.length;
         this.aB = System.currentTimeMillis();
      }

      this.wb %= 2;
      var4.setBlending(228);
      var2.setTexture(0, var4);
      this.hB.render(this.tb);
      this.hB.releaseTarget();
   }

   public synchronized void NA(int var1) {
      switch (var1) {
         case -11:
         case -7:
         case -6:
         case -5:
         case 53:
         default:
            break;
         case -4:
         case 54:
            ++this.ib;
            if (this.ib >= 3) {
               this.ib = 0;
            }

            this.yb = 0;
            break;
         case -3:
         case 52:
            --this.ib;
            if (this.ib < 0) {
               this.ib = 2;
            }

            this.yb = 0;
      }

   }

   static boolean E(String var0) {
      boolean var2 = false;

      try {
         FileConnection var4 = (FileConnection)Connector.open(var0);
         if (!var4.exists()) {
            var4.mkdir();
         }

         var4.close();
         var2 = true;
      } catch (Exception var3) {
      }

      return var2;
   }

   private boolean A(String var1, String var2, String var3, String var4) {
      try {
         InputStream var7 = this.getClass().getResourceAsStream(var3 + var4);
         if (var7 == null) {
            return false;
         } else {
            int var10;
            for(var10 = 0; var7.read() != -1; ++var10) {
            }

            byte[] var11 = new byte[var10];
            var7.reset();
            var7.read(var11);
            var7.close();

            try {
               E("file:///" + var1);
               FileConnection var9 = (FileConnection)Connector.open("file:///" + var1 + var2);
               if (!var9.exists()) {
                  var9.create();
                  OutputStream var8 = var9.openOutputStream();
                  var8.write(var11);
                  var8.close();
               }

               var9.close();
               return true;
            } catch (Exception var5) {
               return false;
            }
         }
      } catch (Exception var6) {
         return false;
      }
   }

   public static Image F(String var0) {
      Image var2 = null;
      FileConnection var1 = null;

      try {
         var1 = (FileConnection)Connector.open(var0);
         if (var1.exists()) {
            InputStream var6 = var1.openInputStream();
            byte[] var3 = new byte[(int)var1.fileSize()];
            var6.read(var3);
            var6.close();
            var2 = Image.createImage(var3, 0, var3.length);
         }
      } catch (Exception var5) {
      }

      try {
         if (var1 != null) {
            var1.close();
         }
      } catch (Exception var4) {
      }

      return var2;
   }

   public InputStream G(String var1) {
      InputStream var2 = null;

      try {
         var2 = this.getClass().getResourceAsStream(var1);
      } catch (Exception var3) {
      }

      return var2;
   }

   public int HA() {
      int var3 = 0;

      for(int var2 = 0; var2 < this.entities.length; ++var2) {
         int var1 = this.entities[var2][0];
         if (var1 >= 3 && var1 < 27) {
            ++var3;
         }
      }

      return var3;
   }

   public int A(String var1, int var2, boolean var3) {
      try {
         InputStream var10 = this.G(var1);
         byte[] var8 = this.A(var10, var2);
         var10.close();
         int var7 = 0;
         ++var7;
         ++var7;
         byte var6 = var8[2];
         ++var7;
         this.za = var8[3];
         this.cc = this.za;
         ++var7;
         this.eA = (long)((var8[7] + 256) % 256 << 24 | (var8[6] + 256) % 256 << 16 | (var8[5] + 256) % 256 << 8 | (var8[4] + 256) % 256);
         var7 += 4;
         this.maxPlanes = var8[8];
         ++var7;
         byte var5 = var8[9];
         ++var7;
         byte var4 = var8[10];
         ++var7;
         var2 = var8[11];
         ++var7;
         byte var11 = var8[12];
         ++var7;
         this.A(1, var4, var2, 0);
         this.players[0][2] = var5;
         if (var3) {
            this.players[0][1] = var11;
         }

         var4 = var8[13];
         ++var7;
         var2 = var8[14];
         ++var7;
         var11 = var8[15];
         ++var7;
         if (var6 != -1) {
            this.A(1, var4, var2, 1);
            this.players[1][2] = var5;
            if (var3) {
               this.players[1][1] = var11;
            }
         }

         var5 = var8[16];
         ++var7;

         for(int var19 = 0; var19 < var5; ++var19) {
            int var3n = var8[var7];
            ++var7;
            var2 = var8[var7];
            ++var7;
            var11 = var8[var7];
            ++var7;
            this.B(var11, var3n, var2);
         }

         return 1;
      } catch (Exception var9) {
         return 0;
      }
   }

   public int[] C(String var1, int var2) {
      try {
         InputStream var6 = this.G(var1);
         byte[] var3 = this.A(var6, var2);
         var6.close();
         var2 = 0;
         int[] var7 = new int[4];
         ++var2;
         ++var2;
         byte var5 = var3[2];
         ++var2;
         var7[0] = var3[3];
         ++var2;
         var7[1] = (var3[7] + 256) % 256 << 24 | (var3[6] + 256) % 256 << 16 | (var3[5] + 256) % 256 << 8 | (var3[4] + 256) % 256;
         var2 += 4;
         ++var2;
         ++var2;
         ++var2;
         ++var2;
         var7[2] = var3[12];
         ++var2;
         ++var2;
         ++var2;
         if (var5 != -1) {
            var7[3] = var3[15];
         } else {
            var7[3] = -1;
         }

         return var7;
      } catch (Exception var4) {
         return new int[1];
      }
   }

   public int IA() {
      byte[] var6 = this.C(10);
      int var5 = 0;
      byte var1 = var6[0];
      if (var1 != 0) {
         this.fA = (long)var1;
      }

      ++var5;
      var5 += 4;
      int var2 = (var6[8] + 256) % 256 << 24 | (var6[7] + 256) % 256 << 16 | (var6[6] + 256) % 256 << 8 | (var6[5] + 256) % 256;
      var5 += 4;

      for(int var7 = 0; var7 < var2; ++var7) {
         this.players[0][var7] = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
         var5 += 4;
      }

      int var4 = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
      var5 += 4;
      int var3 = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
      var5 += 4;

      for(int var11 = 0; var11 < var4; ++var11) {
         for(int var8 = 0; var8 < var3; ++var8) {
            this.entities[var11][var8] = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
            var5 += 4;
         }
      }

      var4 = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
      var5 += 4;
      var3 = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
      var5 += 4;

      for(int var12 = 0; var12 < var4; ++var12) {
         for(int var9 = 0; var9 < var3; ++var9) {
            this.grid[var12][var9] = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
            var5 += 4;
         }
      }

      this.maxPlanes = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
      var5 += 4;
      var5 += 4;
      var5 += 4;

      for(int var13 = 0; var13 < 12; ++var13) {
         for(int var10 = 0; var10 < 4; ++var10) {
            this.planes[var13][var10] = (var6[var5 + 3] + 256) % 256 << 24 | (var6[var5 + 2] + 256) % 256 << 16 | (var6[var5 + 1] + 256) % 256 << 8 | (var6[var5] + 256) % 256;
            var5 += 4;
         }
      }

      return 0;
   }

   public int JA() {
      int var1 = 0;
      this.ha = 1;
      this.matchPending = true;
      this.za = 0;
      ++var1;
      var1 += 4;
      var1 += 4;
      var1 = 9 + this.players[0].length * 4;
      var1 += 4;
      var1 += 4;
      var1 += this.entities.length * this.entities[0].length * 4;
      var1 += 4;
      var1 += 4;
      var1 += this.grid.length * this.grid[0].length * 4;
      var1 += 4;
      var1 += 4;
      var1 += 4;
      int var6 = var1 + this.planes.length * this.planes[0].length * 4;
      byte[] var5 = new byte[var6];
      int var4 = 0;
      int var2 = 0;
      if (this.fA != 90L) {
         var5[0] = (byte)((int)this.fA & 255);
      } else {
         var5[0] = 0;
      }

      ++var4;
      var1 = this.players.length;
      var5[1] = (byte)(var1 & 255);
      var5[2] = (byte)(var1 >>> 8 & 255);
      var5[3] = (byte)(var1 >>> 16 & 255);
      var5[4] = (byte)(var1 >>> 24 & 255);
      var4 += 4;
      var1 = this.players[0].length;
      var5[5] = (byte)(var1 & 255);
      var5[6] = (byte)(var1 >>> 8 & 255);
      var5[7] = (byte)(var1 >>> 16 & 255);
      var5[8] = (byte)(var1 >>> 24 & 255);

      for(var4 += 4; var2 < this.players[0].length; ++var2) {
         var1 = this.players[0][var2];
         var5[var4] = (byte)(var1 & 255);
         var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
         var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
         var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
         var4 += 4;
      }

      var1 = this.entities.length;
      var5[var4] = (byte)(var1 & 255);
      var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
      var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
      var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
      var4 += 4;
      var1 = this.entities[0].length;
      var5[var4] = (byte)(var1 & 255);
      var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
      var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
      var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
      var4 += 4;

      for(int var3 = 0; var3 < this.entities.length; ++var3) {
         for(int var31 = 0; var31 < this.entities[0].length; ++var31) {
            var1 = this.entities[var3][var31];
            var5[var4] = (byte)(var1 & 255);
            var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
            var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
            var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
            var4 += 4;
         }
      }

      var1 = this.grid.length;
      var5[var4] = (byte)(var1 & 255);
      var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
      var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
      var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
      var4 += 4;
      var1 = this.grid[0].length;
      var5[var4] = (byte)(var1 & 255);
      var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
      var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
      var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
      var4 += 4;

      for(int var34 = 0; var34 < this.grid.length; ++var34) {
         for(int var32 = 0; var32 < this.grid[0].length; ++var32) {
            var1 = this.grid[var34][var32];
            var5[var4] = (byte)(var1 & 255);
            var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
            var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
            var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
            var4 += 4;
         }
      }

      var1 = this.maxPlanes;
      var5[var4] = (byte)(var1 & 255);
      var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
      var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
      var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
      var4 += 4;
      var5[var4] = 12;
      var5[var4 + 1] = 0;
      var5[var4 + 2] = 0;
      var5[var4 + 3] = 0;
      var4 += 4;
      var5[var4] = 4;
      var5[var4 + 1] = 0;
      var5[var4 + 2] = 0;
      var5[var4 + 3] = 0;
      var4 += 4;

      for(int var35 = 0; var35 < 12; ++var35) {
         for(int var33 = 0; var33 < 4; ++var33) {
            var1 = this.planes[var35][var33];
            var5[var4] = (byte)(var1 & 255);
            var5[var4 + 1] = (byte)(var1 >>> 8 & 255);
            var5[var4 + 2] = (byte)(var1 >>> 16 & 255);
            var5[var4 + 3] = (byte)(var1 >>> 24 & 255);
            var4 += 4;
         }
      }

      this.A((byte[])var5, 10);
      return 0;
   }

   public void KA() {
      long var1 = this.eA;
      this.bc = false;
      switch (this.za) {
         case 1:
            if ((long)this.players[0][2] >= var1) {
               this.bc = true;
            } else {
               boolean var2 = false;

               for(int var3 = 0; var3 < this.entities.length; ++var3) {
                  if (this.entities[var3][0] == 18) {
                     var2 = true;
                     break;
                  }
               }

               if (!var2) {
                  this.L(3);
               }
            }
            break;
         case 2:
            if ((long)(this.stats[0][3] + this.stats[0][4] + this.stats[0][5] + this.stats[0][6] + this.stats[0][7] + this.stats[0][8] + this.stats[0][9]) >= var1) {
               this.bc = true;
            }
            break;
         case 3:
            if ((long)this.stats[0][1] >= var1) {
               this.bc = true;
            }
            break;
         case 4:
            if ((long)this.players[0][3] >= var1) {
               this.bc = true;
            }
            break;
         case 5:
            if (this.HA() == 0) {
               this.bc = true;
            }
            break;
         case 6:
            if (this.dA >= this.eA) {
               this.bc = true;
            }
      }

      if (this.bc) {
         this.L(3);
      }

   }

   // ============================================================
   // SOUND EVENTS
   // ============================================================

   /** Plays the splash sound (Config.SPLASH_FILE) when enabled in Config. */
   private void playSplash() {
      q.A(Config.SPLASH_SOUND_ID);
   }

   /** Maps a game event code to a sound id and plays it. */
   private void playSoundEvent(int var1) {
      switch (var1) {
         case 4:
         case 5:
         case 6:
         case 7:
            q.A(11);
            break;
         case 8:
         case 9:
            q.A(12);
         case 10:
         case 11:
         default:
            break;
         case 12:
            q.A(3);
            break;
         case 13:
            q.A(4);
            break;
         case 14:
            q.A(5);
            break;
         case 15:
            q.A(6);
            break;
         case 16:
            q.A(7);
            break;
         case 17:
            q.A(8);
            break;
         case 18:
            q.A(9);
      }

   }

   public static String[] A(String var0, Font var1, int var2) {
      int var4 = B(var0, var1);
      int var3 = A(var0, var1);
      if (var2 >= var3 && var4 != 0) {
         char[] var13 = new char[]{'\n', ' ', ',', '?', '-', ':', ';', '/', '.', '"', '!'};
         String var12 = "";
         int var11 = 0;
         int var10 = 0;
         int var9 = -1;
         int var8 = 0;
         int var7 = 0;
         int var6 = 0;
         var3 = -1;

         for(int var5 = 0; var11 < var0.length(); ++var11) {
            var4 = var0.charAt(var11);
            if (var4 == 10 && var11 != var0.length() - 1 && var10 <= var2) {
               String var22 = var12 + var0.substring(var8, var11);
               var12 = var22 + "\n";
               ++var7;
               var8 = var11 + 1;
               if (var0.charAt(var11 + 1) == ' ' && var11 + 1 != var0.length() - 1) {
                  var11 += 2;
                  var8 = var11;
               }

               var9 = -1;
               var10 = var1.charWidth(var0.charAt(var11));
               if (var10 <= var2 && var3 == -1) {
                  var5 = var11;
               }
            } else {
               var10 += var1.charWidth((char)var4);
               if (var3 == -1) {
                  var6 += var1.charWidth((char)var4);
               }

               if (var10 <= var2 && var3 == -1) {
                  var5 = var11;
               }

               if (var10 > var2 && var11 == var0.length() - 1) {
                  var3 = var11;
               }

               if (var10 > var2 * 2 || var10 > var2 && var9 == -1 || var3 != -1) {
                  String var21;
                  if (var9 != -1) {
                     if (var8 == var9) {
                        ++var5;
                        var21 = var12 + var0.substring(var8, var5);
                        var8 = var5;
                        var11 = var5;
                     } else if (var9 < var8) {
                        var21 = var12 + var0.substring(var9, var8);
                        ++var9;
                     } else {
                        if (var3 != -1 && var0.charAt(var3) == ' ' && var6 - var1.charWidth(' ') <= var2) {
                           var6 -= var1.charWidth(' ');
                        }

                        if (var6 <= var2) {
                           ++var9;
                           var21 = var12 + var0.substring(var8, var9);
                           var8 = var9;
                           var11 = var9;
                        } else {
                           ++var5;
                           var21 = var12 + var0.substring(var8, var5);
                           var8 = var5;
                           var11 = var5;
                        }
                     }

                     var9 = -1;
                     var3 = -1;
                     var5 = 0;
                     var6 = 0;
                  } else {
                     var21 = var12 + var0.substring(var8, var11);
                     var8 = var11;
                  }

                  if (var0.charAt(var11) == ' ' && var11 != var0.length() - 1) {
                     ++var11;
                     var8 = var11;
                  }

                  var10 = var1.charWidth(var0.charAt(var11));
                  if (var10 <= var2 && var3 == -1) {
                     var5 = var11;
                  }

                  var12 = var21 + "\n";
                  ++var7;
               }
            }

            var4 = 0;
            if (var11 != var0.length() - 1) {
               for(; var4 < var13.length; ++var4) {
                  if (var0.charAt(var11) == var13[var4]) {
                     if (var10 <= var2) {
                        if (var0.charAt(var11) == '\n') {
                           var9 = var11 + 1;
                        } else {
                           var9 = var11;
                        }

                        var6 = 0;
                        var3 = -1;
                     } else if (var9 != -1) {
                        var3 = var11;
                     }
                  }
               }
            }

            if (var11 == var0.length() - 1) {
               String var24 = var12 + var0.substring(var8, var11 + 1);
               ++var7;
               var12 = var24 + "\n";
            }
         }

         String[] var25 = new String[var7];
         var3 = 0;
         var2 = 0;

         for(int var16 = 0; var3 < var12.length(); ++var3) {
            char var15 = var12.charAt(var3);
            if (var15 == '\n' && var2 < var25.length) {
               var25[var2] = var12.substring(var16, var3);
               var16 = var3 + 1;
               ++var2;
            }
         }

         return var25;
      } else {
         return new String[]{"foobar"};
      }
   }

   public static int A(String var0, Font var1) {
      int var3 = 0;
      if (var0 == null) {
         return 0;
      } else {
         for(int var2 = 0; var2 < var0.length(); ++var2) {
            if (var3 < var1.charWidth(var0.charAt(var2))) {
               var3 = var1.charWidth(var0.charAt(var2));
            }
         }

         return var3;
      }
   }

   public static int B(String var0, Font var1) {
      int var3 = 0;
      if (var0 == null) {
         return 0;
      } else {
         for(int var2 = 0; var2 < var0.length(); ++var2) {
            var3 += var1.charWidth(var0.charAt(var2));
         }

         return var3;
      }
   }

   // $FF: synthetic method
   static String[][] A(StackAttack var0) {
      return var0.c;
   }

   // $FF: synthetic method
   static int B(StackAttack var0) {
      return var0.m;
   }

   // $FF: synthetic method
   static void C(StackAttack var0) {
      var0.GA();
   }

   // $FF: synthetic method
   static void D(StackAttack var0) {
      var0.T();
   }

   // $FF: synthetic method
   static HttpClient E(StackAttack var0) {
      return var0.nB;
   }

   // $FF: synthetic method
   static void A(StackAttack var0, byte[] var1, int var2) {
      var0.A(var1, var2);
   }

   // $FF: synthetic method
   static int F(StackAttack var0) {
      return var0.oB;
   }

   // $FF: synthetic method
   static boolean A(StackAttack var0, boolean var1) {
      return var0.l = var1;
   }

   // $FF: synthetic method
   static Displayable G(StackAttack var0) {
      return var0.r;
   }

   // $FF: synthetic method
   static int A(StackAttack var0, int var1) {
      return var0.m = var1;
   }
}

class StateThread extends Thread {
   // $FF: synthetic field
   private final StackAttack a;

   StateThread(StackAttack var1) {
      this.a = var1;
   }

   public void run() {
      switch (StackAttack.B(this.a)) {
         case 11:
            this.a.rb = true;
            int var2 = this.a.players[0][1];
            int var5 = this.a.players[1][1];
            this.a.DA();
            this.a.EA();
            this.a.players[0][1] = var2;
            this.a.players[1][1] = var5;
            this.a.nA = 0;
            this.a.cA = 0L;
            if (this.a.ha != 2) {
               this.a.dA = 0L;
            }

            if ((this.a.y & 65536) == 0 && (this.a.y & 1048576) == 0) {
               if (this.a.ha == 1) {
                  if (this.a.aA == 10) {
                     this.a.IA();
                  } else {
                     this.a.FA();
                  }
               } else {
                  this.a.A("/m.p", this.a.pb, true);
               }
            } else if (this.a.ha == 0) {
               this.a.A("/s.p", this.a.pb, true);
            } else if (this.a.ha == 1) {
               this.a.FA();
            } else if (this.a.ha == 2) {
               this.a.players[0][0] = -1;
               StackAttack.C(this.a);
               this.a.maxPlanes = 0;
               this.a.players[1][2] = 1;
               this.a.dA = 0L;
            }

            System.gc();
            this.a.sprites.A(this.a.sA[0]);
            this.a.sA[0] = -1;
            this.a.sprites.B(this.a.uA[0]);
            this.a.uA[0] = -1;
            this.a.sprites.A(this.a.sA[5]);
            this.a.sA[5] = -1;
            this.a.sprites.B(this.a.xA);
            this.a.xA = -1;
            this.a.sprites.A(this.a.sA[1]);
            this.a.sA[1] = -1;
            this.a.sprites.B(this.a.yA);
            this.a.yA = -1;
            this.a.sprites.B(this.a.zA);
            this.a.zA = -1;
            this.a.sprites.A(this.a.sA[2]);
            this.a.sA[2] = -1;
            this.a.sprites.A(this.a.sA[3]);
            this.a.sA[3] = -1;
            this.a.sprites.B(this.a.tA[0]);
            this.a.tA[0] = -1;
            this.a.sprites.B(this.a.tA[1]);
            this.a.tA[1] = -1;
            this.a.sprites.B(this.a.tA[2]);
            this.a.tA[2] = -1;
            this.a.sprites.B(this.a.tA[3]);
            this.a.tA[3] = -1;
            this.a.sprites.A(this.a.sA[7]);
            this.a.sA[7] = -1;
            this.a.sprites.B(this.a.tA[4]);
            this.a.tA[4] = -1;
            this.a.sprites.B(this.a.tA[5]);
            this.a.tA[5] = -1;
            this.a.sprites.A(this.a.sA[4]);
            this.a.sA[4] = -1;
            this.a.sprites.B(this.a.tA[6]);
            this.a.tA[6] = -1;
            this.a.sprites.A(this.a.sA[9]);
            this.a.sA[9] = -1;
            this.a.sprites.B(this.a.tA[8]);
            this.a.tA[8] = -1;
            this.a.sprites.A(this.a.vA[0]);
            this.a.vA[0] = -1;
            this.a.sprites.B(this.a.wA[0]);
            this.a.wA[0] = -1;
            this.a.sprites.A(this.a.vA[1]);
            this.a.vA[1] = -1;
            this.a.sprites.B(this.a.wA[1]);
            this.a.wA[1] = -1;
            this.a.sprites.A(this.a.vA[2]);
            this.a.vA[2] = -1;
            this.a.sprites.B(this.a.wA[2]);
            this.a.wA[2] = -1;
            this.a.sprites.A(this.a.vA[3]);
            this.a.vA[3] = -1;
            this.a.sprites.B(this.a.wA[3]);
            this.a.wA[3] = -1;
            this.a.sprites.A(this.a.vA[5]);
            this.a.vA[5] = -1;
            this.a.sprites.B(this.a.wA[4]);
            this.a.wA[4] = -1;
            this.a.sprites.B(this.a.wA[5]);
            this.a.wA[5] = -1;
            this.a.sprites.A(this.a.vA[6]);
            this.a.sprites.B(this.a.wA[6]);
            this.a.wA[6] = -1;
            this.a.sprites.A(this.a.vA[7]);
            this.a.vA[7] = -1;
            this.a.sprites.B(this.a.wA[7]);
            this.a.wA[7] = -1;
            System.gc();
            int[][] var10000 = (int[][])null;
            SpriteSheet var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 3);
            if (this.a.players[0][1] == 0 || this.a.players[1][1] == 0) {
               this.a.sprites.A(var40, 0, 0, 1, this.a.B("/" + this.a.oa, "i.p", 14));
            }

            if (this.a.players[0][1] == 1 || this.a.players[1][1] == 1) {
               this.a.sprites.A(var40, 1, 1, 0, this.a.B("/" + this.a.oa, "i.p", 12));
            }

            if (this.a.players[0][1] == 2 || this.a.players[1][1] == 2) {
               this.a.sprites.A(var40, 2, 2, 0, this.a.B("/" + this.a.oa, "i.p", 13));
            }

            int[][] var6 = new int[][]{{0, 7, 1, 3}, {0, 3, 2, 1}, {0, 3, 2, 1}, {0, 3, 2, 2}, {0, 7, 1, 1}};
            this.a.sprites.A(var40, var6);
            this.a.sprites.C(var40);
            this.a.sA[0] = this.a.sprites.A(var40);
            SpriteState var7 = this.a.sprites.C();
            var7.a = this.a.sA[0];
            var7.d = this.a.players[0][1];
            var7.h |= 1;
            var7.h |= 4;
            this.a.uA[0] = this.a.sprites.A(var7);
            var7 = this.a.sprites.C();
            var7.a = this.a.sA[0];
            var7.d = this.a.players[1][1];
            var7.h |= 1;
            var7.h |= 4;
            this.a.uA[1] = this.a.sprites.A(var7);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 5, 0, this.a.B("/" + this.a.oa, "i.p", 15));
            int[][] var9 = new int[][]{{0, 2, 1, 1}};
            this.a.sprites.A(var40, var9);
            this.a.sprites.C(var40);
            this.a.sA[5] = this.a.sprites.A(var40);
            SpriteState var10 = this.a.sprites.C();
            var10.a = this.a.sA[5];
            var10.c = 49;
            var10.h |= 1;
            var10.h |= 4;
            this.a.xA = this.a.sprites.A(var10);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 17);
            this.a.sprites.A(var40, 0, 0, 0, this.a.B("/" + this.a.oa, "i.p", 34));
            this.a.sprites.A(var40, 1, 1, 0, this.a.B("/" + this.a.oa, "i.p", 16));
            this.a.sprites.A(var40, 2, 2, 0, this.a.B("/" + this.a.oa, "i.p", 17));
            this.a.sprites.A(var40, 3, 3, 0, this.a.B("/" + this.a.oa, "i.p", 18));
            this.a.sprites.A(var40, 4, 4, 0, this.a.B("/" + this.a.oa, "i.p", 19));
            this.a.sprites.A(var40, 5, 5, 0, this.a.B("/" + this.a.oa, "i.p", 20));
            this.a.sprites.A(var40, 6, 6, 0, this.a.B("/" + this.a.oa, "i.p", 2));
            this.a.sprites.A(var40, 7, 7, 0, this.a.B("/" + this.a.oa, "i.p", 3));
            this.a.sprites.A(var40, 8, 8, 0, this.a.B("/" + this.a.oa, "i.p", 4));
            this.a.sprites.A(var40, 9, 9, 0, this.a.B("/" + this.a.oa, "i.p", 5));
            this.a.sprites.A(var40, 10, 10, 0, this.a.B("/" + this.a.oa, "i.p", 6));
            this.a.sprites.A(var40, 11, 11, 0, this.a.B("/" + this.a.oa, "i.p", 36));
            this.a.sprites.A(var40, 12, 12, 0, this.a.B("/" + this.a.oa, "i.p", 37));
            this.a.sprites.A(var40, 13, 13, 0, this.a.B("/" + this.a.oa, "i.p", 38));
            this.a.sprites.A(var40, 14, 14, 0, this.a.B("/" + this.a.oa, "i.p", 39));
            this.a.sprites.A(var40, 15, 15, 0, this.a.B("/" + this.a.oa, "i.p", 40));
            this.a.sprites.A(var40, 16, 16, 0, this.a.B("/" + this.a.oa, "i.p", 41));
            int[][] var11 = new int[][]{{0, 1, 1, 1}};
            this.a.sprites.A(var40, var11);
            this.a.sprites.C(var40);
            this.a.sA[1] = this.a.sprites.A(var40);
            SpriteState var12 = this.a.sprites.C();
            var12.a = this.a.sA[1];
            var12.c = 80;
            var12.h |= 1;
            var12.h |= 4;
            this.a.yA = this.a.sprites.A(var12);
            var12 = this.a.sprites.C();
            var12.a = this.a.sA[1];
            this.a.zA = this.a.sprites.A(var12);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 5);
            this.a.sprites.A(var40, 0, 51, 0, this.a.B("/" + this.a.oa, "i.p", 22));
            this.a.sprites.A(var40, 1, 52, 0, this.a.B("/" + this.a.oa, "i.p", 23));
            this.a.sprites.A(var40, 2, 53, 0, this.a.B("/" + this.a.oa, "i.p", 24));
            this.a.sprites.A(var40, 3, 54, 0, this.a.B("/" + this.a.oa, "i.p", 25));
            this.a.sprites.A(var40, 4, 55, 0, this.a.B("/" + this.a.oa, "i.p", 26));
            int[][] var14 = new int[][]{{0, 4, 1, 2}};
            this.a.sprites.A(var40, var14);
            this.a.sprites.C(var40);
            this.a.sA[2] = this.a.sprites.A(var40);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 4);
            Image var15 = this.a.B("/" + this.a.oa, "i.p", 1);
            this.a.sprites.A(var40, 0, 1, 0, var15);
            int[][] var16 = new int[][]{{0, 1, 1, 1}};
            this.a.sprites.A(var40, var16);
            this.a.sprites.C(var40);
            this.a.sA[3] = this.a.sprites.A(var40);
            SpriteState var17 = this.a.sprites.C();
            var17.a = this.a.sA[3];
            var17.b = 0;
            var17.c = this.a.ua;
            var17.h |= 1;
            this.a.tA[0] = this.a.sprites.A(var17);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 2);
            this.a.sprites.A(var40, 0, 14, 0, this.a.B("/" + this.a.oa, "i.p", 43));
            this.a.sprites.A(var40, 1, 15, 0, this.a.B("/" + this.a.oa, "i.p", 44));
            int[][] var18 = new int[][]{{0, 1, 1, 1}};
            this.a.sprites.A(var40, var18);
            this.a.sprites.C(var40);
            this.a.sA[7] = this.a.sprites.A(var40);
            SpriteState var19 = this.a.sprites.C();
            var19.a = this.a.sA[7];
            var19.d = 0;
            var19.c = this.a.wa - this.a.sprites.E(var40);
            var19.h |= 1;
            var19.h |= 4;
            this.a.tA[4] = this.a.sprites.A(var19);
            var19 = this.a.sprites.C();
            var19.a = this.a.sA[7];
            var19.b = this.a.sa - this.a.sprites.D(var40);
            var19.c = this.a.wa - this.a.sprites.E(var40);
            var19.d = 1;
            var19.h |= 1;
            var19.h |= 4;
            this.a.tA[5] = this.a.sprites.A(var19);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 12, 0, this.a.B("/" + this.a.oa, "i.p", 35));
            int[][] var21 = new int[][]{{0, 1, 1, 1}};
            this.a.sprites.A(var40, var21);
            this.a.sprites.C(var40);
            this.a.sA[4] = this.a.sprites.A(var40);
            SpriteState var22 = this.a.sprites.C();
            var22.a = this.a.sA[4];
            var22.b = 0;
            var22.c = 41;
            var22.h |= 1;
            var22.h |= 4;
            this.a.tA[6] = this.a.sprites.A(var22);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 17, 0, this.a.B("/" + this.a.oa, "i.p", 0));
            int[][] var23 = new int[][]{{0, 1, 1, 1}};
            this.a.sprites.A(var40, var23);
            this.a.sprites.C(var40);
            this.a.sA[9] = this.a.sprites.A(var40);
            SpriteState var24 = this.a.sprites.C();
            var24.a = this.a.sA[9];
            var24.h |= 1;
            var24.h |= 4;
            this.a.tA[8] = this.a.sprites.A(var24);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 8, 0, this.a.B("/", "i.p", 9));
            int[][] var25 = new int[][]{{0, 11, 1, 1}};
            this.a.sprites.A(var40, var25);
            this.a.sprites.C(var40);
            this.a.vA[0] = this.a.sprites.A(var40);
            SpriteState var26 = this.a.sprites.C();
            var26.a = this.a.vA[0];
            var26.c = 11;
            this.a.wA[0] = this.a.sprites.A(var26);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 10, 0, this.a.B("/", "i.p", 12));
            int[][] var27 = new int[][]{{0, 2, 1, 1}};
            this.a.sprites.A(var40, var27);
            this.a.sprites.C(var40);
            this.a.vA[1] = this.a.sprites.A(var40);
            SpriteState var28 = this.a.sprites.C();
            var28.a = this.a.vA[1];
            var28.c = 0;
            this.a.wA[1] = this.a.sprites.A(var28);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 11, 0, this.a.B("/", "i.p", 14));
            int[][] var29 = new int[][]{{0, 3, 1, 1}};
            this.a.sprites.A(var40, var29);
            this.a.sprites.C(var40);
            this.a.vA[2] = this.a.sprites.A(var40);
            SpriteState var30 = this.a.sprites.C();
            var30.a = this.a.vA[2];
            var30.c = 0;
            this.a.wA[2] = this.a.sprites.A(var30);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 9, 0, this.a.B("/", "i.p", 13));
            int[][] var31 = new int[][]{{0, 1, 1, 1}};
            this.a.sprites.A(var40, var31);
            this.a.sprites.C(var40);
            this.a.vA[3] = this.a.sprites.A(var40);
            SpriteState var32 = this.a.sprites.C();
            var32.a = this.a.vA[3];
            this.a.wA[3] = this.a.sprites.A(var32);
            var40 = new SpriteSheet();
            this.a.sprites.B(var40, 0, 1);
            this.a.sprites.A(var40, 0, 15, 0, this.a.B("/", "i.p", 11));
            int[][] var33 = new int[][]{{0, 5, 1, 3}};
            this.a.sprites.A(var40, var33);
            this.a.sprites.C(var40);
            this.a.vA[5] = this.a.sprites.A(var40);
            SpriteState var34 = this.a.sprites.C();
            var34.a = this.a.vA[5];
            var34.b = 120 - this.a.sprites.D(this.a.sprites.c[this.a.vA[5]]) / 2;
            var34.c = 160 - this.a.sprites.E(this.a.sprites.c[this.a.vA[5]]) / 2;
            var34.g = 15;
            this.a.wA[4] = this.a.sprites.A(var34);
            int var53 = this.a.sA[1];
            var34 = this.a.sprites.C();
            var34.a = var53;
            var34.b = 8;
            var34.c = 17;
            this.a.wA[5] = this.a.sprites.A(var34);
            SpriteSheet var54 = new SpriteSheet();
            this.a.sprites.B(var54, 0, 1);
            this.a.sprites.A(var54, 0, 17, 0, this.a.B("/", "i.p", 8));
            int[][] var36 = new int[][]{{0, 4, 1, 2}};
            this.a.sprites.A(var54, var36);
            this.a.sprites.C(var54);
            this.a.vA[6] = this.a.sprites.A(var54);
            SpriteState var37 = this.a.sprites.C();
            var37.a = this.a.vA[6];
            var37.b = 120 - this.a.sprites.D(this.a.sprites.c[this.a.vA[6]]) / 2;
            var37.c = 30;
            var37.g = 8;
            this.a.wA[6] = this.a.sprites.A(var37);
            var54 = new SpriteSheet();
            this.a.sprites.B(var54, 0, 1);
            this.a.sprites.A(var54, 0, 16, 0, this.a.B("/", "i.p", 15));
            int[][] var38 = new int[][]{{0, 10, 1, 1}};
            this.a.sprites.A(var54, var38);
            this.a.sprites.C(var54);
            this.a.vA[7] = this.a.sprites.A(var54);
            SpriteState var39 = this.a.sprites.C();
            var39.a = this.a.vA[7];
            var39.c = 11;
            this.a.wA[7] = this.a.sprites.A(var39);
            this.a.I();
            this.a.sprites.C(25);
            System.gc();
            StackAttack.D(this.a);
            if (this.a.ha == 2) {
               this.a.hA = 4000L;
               this.a.iA = this.a.hA;
            }

            this.a.matchPending = true;
            if ((this.a.y & 1048576) != 0 || (this.a.y & 65536) != 0) {
               this.a.x.A(0, this.a.x.j, 1012, 0, (byte[])null);
               this.a.L(5);
               if ((this.a.y & 65536) != 0) {
                  this.a.nA = 1;
               }
            }
            break;
         case 23:
            this.a.x.A(65794);
            break;
         case 27:
            this.a.x.A(1048833);
            break;
         case 802:
            try {
               StackAttack.E(this.a).A(this.a.lb);
               int var4 = StackAttack.E(this.a).E();
               if (var4 != 0 && var4 < 0) {
                  this.a.A(StackAttack.F(this.a), StackAttack.E(80), StackAttack.E(81));
               }
            } catch (Exception var3) {
               this.a.K(StackAttack.F(this.a));
            }
            break;
         case 806:
            if (this.a.qB[0].length() != 0) {
               StackAttack.E(this.a).A(this.a.qB[0]);
               int var1 = StackAttack.E(this.a).D();
               if (var1 > 0) {
                  this.a.pB = StackAttack.E(this.a).B();
                  this.a.K(805);
               } else if (var1 == 0) {
                  this.a.qB[0] = StackAttack.E(this.a).B();
                  this.a.pB = StackAttack.E(this.a).B();
                  StackAttack.A((StackAttack)this.a, (byte[])this.a.pB.getBytes(), 80);
                  this.a.K(801);
               } else if (var1 < 0) {
                  this.a.K(804);
               }
            }
            break;
         case 906:
            if (this.a.kB.A() == 1) {
               this.a.kB.B(this.a.mB[0]);
            } else {
               this.a.kB.A(0, this.a.mB[0]);
            }

            if (this.a.mB[1].length() > 0) {
               this.a.kB.A(2, this.a.mB[1]);
            }

            if (this.a.mB[3].length() > 0) {
               this.a.kB.C(this.a.mB[3]);
            }

            if (this.a.mB[2].length() > 0) {
               this.a.kB.C(this.a.mB[2]);
            }

            this.a.kB.F();
      }

      this.a.jB = 2;
      StackAttack.A(this.a, false);
      ((GameCanvasLoop)StackAttack.G(this.a)).e = false;
      ((GameCanvasLoop)StackAttack.G(this.a)).d = false;
      this.a.K(StackAttack.B(this.a));
      StackAttack.B(this.a);
      StackAttack.A((StackAttack)this.a, -1);
   }
}
