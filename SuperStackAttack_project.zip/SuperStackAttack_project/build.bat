@echo off
rem Builds dist\SuperStackAttack.jar from src\ + res\. Needs a JDK (8+) on PATH.
rem Optional preverification (real phones): set PROGUARD_JAR=C:\path\proguard.jar before running.
cd /d "%~dp0"
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
mkdir build\classes build\stage\META-INF dist
javac -nowarn --release 8 -encoding UTF-8 -cp lib\j2me-stubs.jar -d build\classes src\*.java || exit /b 1
xcopy /e /i /q res build\stage >nul
copy /y build\classes\*.class build\stage >nul
copy /y MANIFEST.MF build\stage\META-INF >nul
jar cfm dist\SuperStackAttack_unpreverified.jar build\stage\META-INF\MANIFEST.MF -C build\stage . || exit /b 1
echo built dist\SuperStackAttack_unpreverified.jar
if "%PROGUARD_JAR%"=="" (echo PROGUARD_JAR not set: skipped preverification & exit /b 0)
if exist "%JAVA_HOME%\jmods\java.base.jmod" (set RT=%JAVA_HOME%\jmods\java.base.jmod^(!**.jar;!module-info.class^)) else (set RT=%JAVA_HOME%\jre\lib\rt.jar)
(
echo -injars %CD%/dist/SuperStackAttack_unpreverified.jar
echo -outjars %CD%/dist/SuperStackAttack.jar
echo -libraryjars %CD%/lib/j2me-stubs.jar
echo -libraryjars %RT%
echo -microedition
echo -target 1.3
echo -dontshrink
echo -dontoptimize
echo -dontobfuscate
echo -ignorewarnings
echo -keep public class StackAttack
) > build\pg.conf
java -jar "%PROGUARD_JAR%" @build\pg.conf && echo built dist\SuperStackAttack.jar (preverified)
